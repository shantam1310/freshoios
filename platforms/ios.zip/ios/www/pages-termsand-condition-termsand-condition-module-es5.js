(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-termsand-condition-termsand-condition-module"], {
    /***/
    "Mlt5":
    /*!***********************************************************************!*\
      !*** ./src/app/pages/termsand-condition/termsand-condition.module.ts ***!
      \***********************************************************************/

    /*! exports provided: TermsandConditionPageModule */

    /***/
    function Mlt5(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TermsandConditionPageModule", function () {
        return TermsandConditionPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _termsand_condition_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./termsand-condition-routing.module */
      "tHjD");
      /* harmony import */


      var _termsand_condition_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./termsand-condition.page */
      "ntAT");

      var TermsandConditionPageModule = function TermsandConditionPageModule() {
        _classCallCheck(this, TermsandConditionPageModule);
      };

      TermsandConditionPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _termsand_condition_routing_module__WEBPACK_IMPORTED_MODULE_5__["TermsandConditionPageRoutingModule"]],
        declarations: [_termsand_condition_page__WEBPACK_IMPORTED_MODULE_6__["TermsandConditionPage"]]
      })], TermsandConditionPageModule);
      /***/
    },

    /***/
    "PkJ4":
    /*!***********************************************************************!*\
      !*** ./src/app/pages/termsand-condition/termsand-condition.page.scss ***!
      \***********************************************************************/

    /*! exports provided: default */

    /***/
    function PkJ4(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-toolbar {\n  --background: #60be74;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3Rlcm1zYW5kLWNvbmRpdGlvbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQkFBQTtBQUNGIiwiZmlsZSI6InRlcm1zYW5kLWNvbmRpdGlvbi5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tdG9vbGJhciB7XG4gIC0tYmFja2dyb3VuZDogIzYwYmU3NDtcbn1cbiJdfQ== */";
      /***/
    },

    /***/
    "ZXT0":
    /*!*************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/termsand-condition/termsand-condition.page.html ***!
      \*************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function ZXT0(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-menu-toggle slot=\"start\">\n      <ion-icon\n        name=\"menu-outline\"\n        style=\"font-size: 170%; font-weight: bold; margin-left: 11%\"\n      ></ion-icon>\n    </ion-menu-toggle>\n    <ion-title style=\"font-size: 100%; font-family: revert\"\n      ><ion-img src=\"assets/logo.png\" alt=\"Freshofast\" style=\"width: 59%\">\n      </ion-img\n    ></ion-title>\n    <!-- <ion-buttons slot=\"end\" style=\"margin-right: 2%\">\n      <ion-icon slot=\"end\" name=\"search-outline\"></ion-icon>\n    </ion-buttons> -->\n    <ion-buttons\n      slot=\"end\"\n      style=\"margin-right: 4%\"\n      [routerLink]=\"['/checkout-page']\"\n    >\n      <ion-icon name=\"cart-outline\" style=\"font-size: 144%\"></ion-icon>\n      <!-- <span>{{cartlist.length}}</span> -->\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n  <div style=\"padding: 10px; text-align: center\">\n    <h3>Terms</h3>\n    By accessing this web site, you are agreeing to be bound by these web site\n    Terms and Conditions of Use, all applicable laws and regulations, and agree\n    that you are responsible for compliance with any applicable local laws. If\n    you do not agree with any of these terms, you are prohibited from using or\n    accessing this site. The materials contained in this web site are protected\n    by applicable copyright and trade mark law.\n    <h3>Use License</h3>\n    Permission is granted to temporarily download one copy of the materials\n    (information or software) on Freshofast web site for personal,\n    non-commercial transitory viewing only. This is the grant of a license, not\n    a transfer of title, and under this license you may not: i. modify or copy\n    the materials. ii. use the materials for any commercial purpose, or for any\n    public display (commercial or non-commercial). iii. attempt to decompile or\n    reverse engineer any software contained on Freshofast web site. iv. remove\n    any copyright or other proprietary notations from the materials; or v.\n    transfer the materials to another person or \"mirror\" the materials on any\n    other server. This license shall automatically terminate if you violate any\n    of these restrictions and may be terminated by Freshofast at any time. Upon\n    terminating your viewing of these materials or upon the termination of this\n    license, you must destroy any downloaded materials in your possession\n    whether in electronic or printed format.\n    <h3>Disclaimer</h3>\n    The materials on Freshofast web site are provided \"as is\". Freshofast makes\n    no warranties, expressed or implied, and hereby disclaims and negates all\n    other warranties, including without limitation, implied warranties or\n    conditions of merchantability, fitness for a particular purpose, or\n    non-infringement of intellectual property or other violation of rights.\n    Further, Freshofast does not warrant or make any representations concerning\n    the accuracy, likely results, or reliability of the use of the materials on\n    its Internet web site or otherwise relating to such materials or on any\n    sites linked to this site.\n    <h3>Limitations</h3>\n    In no event shall Freshofast or its suppliers be liable for any damages\n    (including, without limitation, damages for loss of data or profit, or due\n    to business interruption,) arising out of the use or inability to use the\n    materials on Freshofast Internet site, even if Freshofast or a Freshofast\n    authorized representative has been notified orally or in writing of the\n    possibility of such damage. Because some jurisdictions do not allow\n    limitations on implied warranties, or limitations of liability for\n    consequential or incidental damages, these limitations may not apply to you.\n    <h3>Revisions</h3>\n    The materials appearing on Freshofast web site could include technical,\n    typographical, or photographic errors. Freshofast does not warrant that any\n    of the materials on its web site are accurate, complete, or current.\n    Freshofast may make changes to the materials contained on its web site at\n    any time without notice. Freshofast does not, however, make any commitment\n    to update the materials.\n    <h3>Links</h3>\n    Freshofast has not reviewed all of the sites linked to its Internet web site\n    and is not responsible for the contents of any such linked site. The\n    inclusion of any link does not imply endorsement by freshofast of the site.\n    Use of any such linked web site is at the user's own risk.\n    <h3>Site Terms of Use Modifications</h3>\n    Freshofast may revise these terms of use for its web site at any time\n    without notice. By using this web site you are agreeing to be bound by the\n    then current version of these Terms and Conditions of Use.\n  </div>\n</ion-content>\n";
      /***/
    },

    /***/
    "ntAT":
    /*!*********************************************************************!*\
      !*** ./src/app/pages/termsand-condition/termsand-condition.page.ts ***!
      \*********************************************************************/

    /*! exports provided: TermsandConditionPage */

    /***/
    function ntAT(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TermsandConditionPage", function () {
        return TermsandConditionPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_termsand_condition_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./termsand-condition.page.html */
      "ZXT0");
      /* harmony import */


      var _termsand_condition_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./termsand-condition.page.scss */
      "PkJ4");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var TermsandConditionPage = /*#__PURE__*/function () {
        function TermsandConditionPage() {
          _classCallCheck(this, TermsandConditionPage);
        }

        _createClass(TermsandConditionPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return TermsandConditionPage;
      }();

      TermsandConditionPage.ctorParameters = function () {
        return [];
      };

      TermsandConditionPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-termsand-condition',
        template: _raw_loader_termsand_condition_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_termsand_condition_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], TermsandConditionPage);
      /***/
    },

    /***/
    "tHjD":
    /*!*******************************************************************************!*\
      !*** ./src/app/pages/termsand-condition/termsand-condition-routing.module.ts ***!
      \*******************************************************************************/

    /*! exports provided: TermsandConditionPageRoutingModule */

    /***/
    function tHjD(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "TermsandConditionPageRoutingModule", function () {
        return TermsandConditionPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _termsand_condition_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./termsand-condition.page */
      "ntAT");

      var routes = [{
        path: '',
        component: _termsand_condition_page__WEBPACK_IMPORTED_MODULE_3__["TermsandConditionPage"]
      }];

      var TermsandConditionPageRoutingModule = function TermsandConditionPageRoutingModule() {
        _classCallCheck(this, TermsandConditionPageRoutingModule);
      };

      TermsandConditionPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], TermsandConditionPageRoutingModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-termsand-condition-termsand-condition-module-es5.js.map