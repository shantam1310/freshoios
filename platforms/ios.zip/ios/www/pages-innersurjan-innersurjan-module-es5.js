(function () {
  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-innersurjan-innersurjan-module"], {
    /***/
    "KEZW":
    /*!*******************************************************!*\
      !*** ./src/app/pages/innersurjan/innersurjan.page.ts ***!
      \*******************************************************/

    /*! exports provided: InnersurjanPage */

    /***/
    function KEZW(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "InnersurjanPage", function () {
        return InnersurjanPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_innersurjan_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./innersurjan.page.html */
      "bXgu");
      /* harmony import */


      var _innersurjan_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./innersurjan.page.scss */
      "Xofc");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var InnersurjanPage = /*#__PURE__*/function () {
        //dateNow = Date();
        //date = new Date(new Date(this.dateNow).getTime() - 1000 * 60 * 60 * 8);
        function InnersurjanPage() {// slider.startAutoplay();

          _classCallCheck(this, InnersurjanPage);
        }

        _createClass(InnersurjanPage, [{
          key: "slidesDidLoad",
          value: function slidesDidLoad(slides) {
            slides.startAutoplay();
          }
        }]);

        return InnersurjanPage;
      }();

      InnersurjanPage.ctorParameters = function () {
        return [];
      };

      InnersurjanPage.propDecorators = {
        slider: [{
          type: _angular_core__WEBPACK_IMPORTED_MODULE_3__["ViewChild"],
          args: ["mySlider"]
        }]
      };
      InnersurjanPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: "app-innersurjan",
        template: _raw_loader_innersurjan_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_innersurjan_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], InnersurjanPage);
      /***/
    },

    /***/
    "OxXw":
    /*!*********************************************************!*\
      !*** ./src/app/pages/innersurjan/innersurjan.module.ts ***!
      \*********************************************************/

    /*! exports provided: InnersurjanPageModule */

    /***/
    function OxXw(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "InnersurjanPageModule", function () {
        return InnersurjanPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _innersurjan_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./innersurjan-routing.module */
      "ogiI");
      /* harmony import */


      var _innersurjan_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./innersurjan.page */
      "KEZW");

      var InnersurjanPageModule = function InnersurjanPageModule() {
        _classCallCheck(this, InnersurjanPageModule);
      };

      InnersurjanPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _innersurjan_routing_module__WEBPACK_IMPORTED_MODULE_5__["InnersurjanPageRoutingModule"]],
        declarations: [_innersurjan_page__WEBPACK_IMPORTED_MODULE_6__["InnersurjanPage"]]
      })], InnersurjanPageModule);
      /***/
    },

    /***/
    "Xofc":
    /*!*********************************************************!*\
      !*** ./src/app/pages/innersurjan/innersurjan.page.scss ***!
      \*********************************************************/

    /*! exports provided: default */

    /***/
    function Xofc(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJpbm5lcnN1cmphbi5wYWdlLnNjc3MifQ== */";
      /***/
    },

    /***/
    "bXgu":
    /*!***********************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/innersurjan/innersurjan.page.html ***!
      \***********************************************************************************************/

    /*! exports provided: default */

    /***/
    function bXgu(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header mode=\"md\">\n  <ion-toolbar>\n    <ion-icon\n      slot=\"start\"\n      name=\"arrow-back-outline\"\n      style=\"font-size: 2em; font-weight: bold; margin-left: 3%\"\n    ></ion-icon>\n\n    <ion-title style=\"font-size: 100%; font-family: revert\"\n      >Surjan Times</ion-title\n    >\n    <ion-buttons slot=\"end\" style=\"margin-right: 2%\">\n      <ion-icon slot=\"end\" name=\"search-outline\"></ion-icon>\n    </ion-buttons>\n    <ion-buttons slot=\"end\" style=\"margin-right: 4%\">\n      <ion-icon name=\"cart-outline\" style=\"font-size: 144%\"></ion-icon>\n    </ion-buttons>\n  </ion-toolbar>\n</ion-header>\n<ion-content>\n  <ion-slides\n    #mySlider\n    (ionSlidesDidLoad)=\"slidesDidLoad(mySlider)\"\n    pager=\"false\"\n    style=\"height: 30%\"\n  >\n    <!-- <ion-slide class=\"first-slide\">\n  </ion-slide> -->\n    <ion-slide style=\"background-color: green\">\n      <ion-img src=\"assets/slider1.jpeg\" style=\"width: 100%\"> </ion-img>\n    </ion-slide>\n    <ion-slide style=\"background-color: blue\">\n      <ion-img src=\"assets/slider2.jpeg\" style=\"width: 100%\"> </ion-img>\n    </ion-slide>\n    <!-- <ion-slide style=\"background-color: red\">\n      <h2>Slide 3</h2>\n    </ion-slide> -->\n  </ion-slides>\n  <div style=\"font-size: 1.3em; font-weight: 500; padding: 5%\">\n    <label>\n      We can help you improve your writing, and your writing skills. From blog\n      writing to story writing\n    </label>\n  </div>\n  <ion-icon name=\"calendar-outline\" style=\"margin-left: 5%\"></ion-icon>\n  <div style=\"background-color: blue; height: 8%; text-align: center\">\n    Advertisement here\n  </div>\n  <div style=\"padding: 12px; font-size: 1em\">\n    The Paragraphs module allows content creators to choose which kinds of\n    paragraphs they want to place on the page, and the order in which they want\n    to place them. They can do all of this through the familiar node edit\n    screen. There is no need to resort to code, the dreaded block placement\n    config screen or Panelizer overrides. They just use node edit form where all\n    content is available to them in one place.\n  </div>\n  <div>\n    <ion-img src=\"assets/slider1.jpeg\"> </ion-img>\n  </div>\n  <div style=\"padding: 12px; font-size: 1em\">\n    The Paragraphs module allows content creators to choose which kinds of\n    paragraphs they want to place on the page, and the order in which they want\n    to place them. They can do all of this through the familiar node edit\n    screen. There is no need to resort to code, the dreaded block placement\n    config screen or Panelizer overrides. They just use node edit form where all\n    content is available to them in one place.\n  </div>\n  <div style=\"color: red; text-align: center; color: red; font-size: 1.2em\">\n    You may like this News\n  </div>\n  <ion-card>\n    <ion-item>\n      <ion-img slot=\"start\" src=\"assets/frozen2.png\" style=\"width: 23%\">\n      </ion-img>\n\n      <ion-label>\n        <p>\n          They just use node edit form where all content is available to them in\n          one place\n        </p>\n      </ion-label>\n    </ion-item>\n  </ion-card>\n</ion-content>\n";
      /***/
    },

    /***/
    "ogiI":
    /*!*****************************************************************!*\
      !*** ./src/app/pages/innersurjan/innersurjan-routing.module.ts ***!
      \*****************************************************************/

    /*! exports provided: InnersurjanPageRoutingModule */

    /***/
    function ogiI(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "InnersurjanPageRoutingModule", function () {
        return InnersurjanPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _innersurjan_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./innersurjan.page */
      "KEZW");

      var routes = [{
        path: '',
        component: _innersurjan_page__WEBPACK_IMPORTED_MODULE_3__["InnersurjanPage"]
      }];

      var InnersurjanPageRoutingModule = function InnersurjanPageRoutingModule() {
        _classCallCheck(this, InnersurjanPageRoutingModule);
      };

      InnersurjanPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], InnersurjanPageRoutingModule);
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-innersurjan-innersurjan-module-es5.js.map