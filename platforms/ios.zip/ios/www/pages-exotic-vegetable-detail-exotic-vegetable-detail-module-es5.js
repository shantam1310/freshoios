(function () {
  function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

  function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

  function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

  (window["webpackJsonp"] = window["webpackJsonp"] || []).push([["pages-exotic-vegetable-detail-exotic-vegetable-detail-module"], {
    /***/
    "4w6b":
    /*!*********************************************************************************!*\
      !*** ./src/app/pages/exotic-vegetable-detail/exotic-vegetable-detail.module.ts ***!
      \*********************************************************************************/

    /*! exports provided: ExoticVegetableDetailPageModule */

    /***/
    function w6b(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ExoticVegetableDetailPageModule", function () {
        return ExoticVegetableDetailPageModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/common */
      "ofXK");
      /* harmony import */


      var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/forms */
      "3Pt+");
      /* harmony import */


      var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
      /*! @ionic/angular */
      "TEn/");
      /* harmony import */


      var _exotic_vegetable_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
      /*! ./exotic-vegetable-detail-routing.module */
      "Do7g");
      /* harmony import */


      var _exotic_vegetable_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
      /*! ./exotic-vegetable-detail.page */
      "mW3a");

      var ExoticVegetableDetailPageModule = function ExoticVegetableDetailPageModule() {
        _classCallCheck(this, ExoticVegetableDetailPageModule);
      };

      ExoticVegetableDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _exotic_vegetable_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["ExoticVegetableDetailPageRoutingModule"]],
        declarations: [_exotic_vegetable_detail_page__WEBPACK_IMPORTED_MODULE_6__["ExoticVegetableDetailPage"]]
      })], ExoticVegetableDetailPageModule);
      /***/
    },

    /***/
    "Do7g":
    /*!*****************************************************************************************!*\
      !*** ./src/app/pages/exotic-vegetable-detail/exotic-vegetable-detail-routing.module.ts ***!
      \*****************************************************************************************/

    /*! exports provided: ExoticVegetableDetailPageRoutingModule */

    /***/
    function Do7g(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ExoticVegetableDetailPageRoutingModule", function () {
        return ExoticVegetableDetailPageRoutingModule;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");
      /* harmony import */


      var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! @angular/router */
      "tyNb");
      /* harmony import */


      var _exotic_vegetable_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! ./exotic-vegetable-detail.page */
      "mW3a");

      var routes = [{
        path: '',
        component: _exotic_vegetable_detail_page__WEBPACK_IMPORTED_MODULE_3__["ExoticVegetableDetailPage"]
      }];

      var ExoticVegetableDetailPageRoutingModule = function ExoticVegetableDetailPageRoutingModule() {
        _classCallCheck(this, ExoticVegetableDetailPageRoutingModule);
      };

      ExoticVegetableDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
      })], ExoticVegetableDetailPageRoutingModule);
      /***/
    },

    /***/
    "mW3a":
    /*!*******************************************************************************!*\
      !*** ./src/app/pages/exotic-vegetable-detail/exotic-vegetable-detail.page.ts ***!
      \*******************************************************************************/

    /*! exports provided: ExoticVegetableDetailPage */

    /***/
    function mW3a(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony export (binding) */


      __webpack_require__.d(__webpack_exports__, "ExoticVegetableDetailPage", function () {
        return ExoticVegetableDetailPage;
      });
      /* harmony import */


      var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
      /*! tslib */
      "mrSG");
      /* harmony import */


      var _raw_loader_exotic_vegetable_detail_page_html__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
      /*! raw-loader!./exotic-vegetable-detail.page.html */
      "zBtI");
      /* harmony import */


      var _exotic_vegetable_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
      /*! ./exotic-vegetable-detail.page.scss */
      "wvWp");
      /* harmony import */


      var _angular_core__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
      /*! @angular/core */
      "fXoL");

      var ExoticVegetableDetailPage = /*#__PURE__*/function () {
        function ExoticVegetableDetailPage() {
          _classCallCheck(this, ExoticVegetableDetailPage);
        }

        _createClass(ExoticVegetableDetailPage, [{
          key: "ngOnInit",
          value: function ngOnInit() {}
        }]);

        return ExoticVegetableDetailPage;
      }();

      ExoticVegetableDetailPage.ctorParameters = function () {
        return [];
      };

      ExoticVegetableDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_3__["Component"])({
        selector: 'app-exotic-vegetable-detail',
        template: _raw_loader_exotic_vegetable_detail_page_html__WEBPACK_IMPORTED_MODULE_1__["default"],
        styles: [_exotic_vegetable_detail_page_scss__WEBPACK_IMPORTED_MODULE_2__["default"]]
      })], ExoticVegetableDetailPage);
      /***/
    },

    /***/
    "wvWp":
    /*!*********************************************************************************!*\
      !*** ./src/app/pages/exotic-vegetable-detail/exotic-vegetable-detail.page.scss ***!
      \*********************************************************************************/

    /*! exports provided: default */

    /***/
    function wvWp(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "ion-toolbar {\n  --background: #60be74;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL2V4b3RpYy12ZWdldGFibGUtZGV0YWlsLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUNFLHFCQUFBO0FBQ0YiLCJmaWxlIjoiZXhvdGljLXZlZ2V0YWJsZS1kZXRhaWwucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiaW9uLXRvb2xiYXIge1xuICAtLWJhY2tncm91bmQ6ICM2MGJlNzQ7XG59XG4iXX0= */";
      /***/
    },

    /***/
    "zBtI":
    /*!***********************************************************************************************************************!*\
      !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/pages/exotic-vegetable-detail/exotic-vegetable-detail.page.html ***!
      \***********************************************************************************************************************/

    /*! exports provided: default */

    /***/
    function zBtI(module, __webpack_exports__, __webpack_require__) {
      "use strict";

      __webpack_require__.r(__webpack_exports__);
      /* harmony default export */


      __webpack_exports__["default"] = "<ion-header>\n  <ion-toolbar>\n    <ion-title>exoticVegetableDetail</ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content>\n\n</ion-content>\n";
      /***/
    }
  }]);
})();
//# sourceMappingURL=pages-exotic-vegetable-detail-exotic-vegetable-detail-module-es5.js.map