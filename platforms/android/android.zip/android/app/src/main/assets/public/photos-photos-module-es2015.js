(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["photos-photos-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/photos/photos.page.html":
/*!*******************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/photos/photos.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-back-button></ion-back-button>\n        </ion-buttons>\n        <ion-title>My Photos</ion-title>\n        <ion-buttons slot=\"end\">\n            <ion-button (click)=\"TriggerFileInput();\">add</ion-button>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <ion-card class=\"decorative-card\">\n        <ion-card-content>\n            <ion-list>\n                <ion-item style=\"width:1px; height:1px; overflow:hidden; \n                                 position:relative; left:-1000px;\">\n                    <ion-label id=\"profile_image\" color=\"primary\" stacked>\n                        Add Image\n                    </ion-label>\n                    <input type=\"file\" accept=\"image/*\" name=\"file\" #file id=\"file\" \n                           (change)=\"ChangeListener($event)\" />\n                </ion-item>\n            </ion-list>\n            <div class=\"my-photos-image\" *ngFor=\"let this_image of image_data\">\n                <ion-img [src]=\"this_image.media_url\"></ion-img>\n                <ion-button class=\"my-photos-image-manipulator\" color=\"light\"\n                            (click)=\"DisplayActions(this_image);\">\n                    <ion-icon [name]=\"'md-more'\"></ion-icon>\n                </ion-button>\n            </div>\n        </ion-card-content>\n    </ion-card>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/photos/photos.module.ts":
/*!*****************************************!*\
  !*** ./src/app/photos/photos.module.ts ***!
  \*****************************************/
/*! exports provided: PhotosPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PhotosPageModule", function() { return PhotosPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _photos_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./photos.page */ "./src/app/photos/photos.page.ts");







const routes = [
    {
        path: '',
        component: _photos_page__WEBPACK_IMPORTED_MODULE_6__["PhotosPage"]
    }
];
let PhotosPageModule = class PhotosPageModule {
};
PhotosPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_photos_page__WEBPACK_IMPORTED_MODULE_6__["PhotosPage"]]
    })
], PhotosPageModule);



/***/ }),

/***/ "./src/app/photos/photos.page.scss":
/*!*****************************************!*\
  !*** ./src/app/photos/photos.page.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".my-photos-image {\n  position: relative;\n}\n.my-photos-image ion-img {\n  width: calc(100% - 36px - 30px - 8px - 8px);\n  margin-left: 8px;\n  box-shadow: rgba(0, 0, 0, 0.2) 0px 3px 1px -2px;\n  border-radius: 3px;\n  overflow: hidden;\n}\n.my-photos-image .my-photos-image-manipulator {\n  position: absolute;\n  top: -4px;\n  right: 8px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zaGFudGFtc2hhcm1hL0Rvd25sb2Fkcy93aG95b3Uvc3JjL2FwcC9waG90b3MvcGhvdG9zLnBhZ2Uuc2NzcyIsInNyYy9hcHAvcGhvdG9zL3Bob3Rvcy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyxrQkFBQTtBQ0NEO0FEQUM7RUFDQywyQ0FBQTtFQUNBLGdCQUFBO0VBQ0EsK0NBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FDRUY7QURBQztFQUNDLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7QUNFRiIsImZpbGUiOiJzcmMvYXBwL3Bob3Rvcy9waG90b3MucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiLm15LXBob3Rvcy1pbWFnZSB7XG5cdHBvc2l0aW9uOiByZWxhdGl2ZTtcblx0aW9uLWltZyB7XG5cdFx0d2lkdGg6IGNhbGMoMTAwJSAtIDM2cHggLSAzMHB4IC0gOHB4IC0gOHB4KTtcblx0XHRtYXJnaW4tbGVmdDogOHB4O1xuXHRcdGJveC1zaGFkb3c6IHJnYmEoMCwwLDAsMC4yKSAwcHggM3B4IDFweCAtMnB4O1xuXHRcdGJvcmRlci1yYWRpdXM6IDNweDtcblx0XHRvdmVyZmxvdzogaGlkZGVuO1xuXHR9XG5cdC5teS1waG90b3MtaW1hZ2UtbWFuaXB1bGF0b3Ige1xuXHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcblx0XHR0b3A6IC00cHg7XG5cdFx0cmlnaHQ6IDhweDtcblx0fVxufSIsIi5teS1waG90b3MtaW1hZ2Uge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4ubXktcGhvdG9zLWltYWdlIGlvbi1pbWcge1xuICB3aWR0aDogY2FsYygxMDAlIC0gMzZweCAtIDMwcHggLSA4cHggLSA4cHgpO1xuICBtYXJnaW4tbGVmdDogOHB4O1xuICBib3gtc2hhZG93OiByZ2JhKDAsIDAsIDAsIDAuMikgMHB4IDNweCAxcHggLTJweDtcbiAgYm9yZGVyLXJhZGl1czogM3B4O1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuLm15LXBob3Rvcy1pbWFnZSAubXktcGhvdG9zLWltYWdlLW1hbmlwdWxhdG9yIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IC00cHg7XG4gIHJpZ2h0OiA4cHg7XG59Il19 */"

/***/ }),

/***/ "./src/app/photos/photos.page.ts":
/*!***************************************!*\
  !*** ./src/app/photos/photos.page.ts ***!
  \***************************************/
/*! exports provided: PhotosPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PhotosPage", function() { return PhotosPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/toast.service */ "./src/app/services/toast.service.ts");
/* harmony import */ var _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/navigation.service */ "./src/app/services/navigation.service.ts");
/* harmony import */ var _services_query_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/query.service */ "./src/app/services/query.service.ts");
/* harmony import */ var _services_bucket_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/bucket.service */ "./src/app/services/bucket.service.ts");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");








const { Modals } = _capacitor_core__WEBPACK_IMPORTED_MODULE_7__["Plugins"];
let PhotosPage = class PhotosPage {
    constructor(authentication, toast, nav, query, bucket) {
        this.authentication = authentication;
        this.toast = toast;
        this.nav = nav;
        this.query = query;
        this.bucket = bucket;
        this.image_data = [];
        this.LoadImageList();
    }
    ngOnInit() {
    }
    TriggerFileInput() {
        this.file_input.nativeElement.click();
    }
    LoadImageList() {
        this.query.request('profile/photos', 'GET', {
            "user": this.authentication.user.id
        }).subscribe(results => {
            this.image_data = results['data'];
            // TODO - Remove this console statement.
            console.log('this.image_data', this.image_data);
        }, error => {
            this.toast.DisplaySimpleToast("Unable to load photos.");
        });
    }
    DisplayActions(image) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            let promptRet = yield Modals.showActions({
                title: 'Photo Options',
                message: 'Select an option to perform',
                options: [
                    {
                        title: 'Make Featured'
                    },
                    {
                        title: 'Delete'
                    }
                ]
            });
            console.log('promptRet', promptRet);
            if (promptRet.index == 0 /*Feature*/) {
                this.FeatureImage(image);
            }
            if (promptRet.index == 1 /*Delete*/) {
                this.DeleteImage(image);
            }
        });
    }
    DeleteImage(image) {
        this.query.request('profile/photos/'.concat(image.id), 'DELETE', {}).subscribe(results => {
            this.toast.DisplaySimpleToast("Photo has been deleted. Refreshing...");
            this.LoadImageList();
        }, error => {
            this.toast.DisplaySimpleToast("Unable to delete photo.");
        });
    }
    FeatureImage(image) {
        this.query.request('profile/photos/'.concat(image.id), 'PATCH', {}, { is_featured: true }).subscribe(results => {
            this.toast.DisplaySimpleToast("Photo has been featured. Refreshing...");
            this.LoadImageList();
        }, error => {
            this.toast.DisplaySimpleToast("Unable to update photo.");
        });
    }
    UploadFiles() {
        this.bucket.UploadAndGetRemoteFileURL(this.files, 'profiles').then(image_url => {
            // this.files = undefined;
            this.SubmitProfilePhoto(image_url);
        });
    }
    SubmitProfilePhoto(image_url) {
        var body = {
            "media_url": image_url,
            "user": this.authentication.user.id
        };
        this.query.request('profile/photos', 'POST', {}, body).subscribe(results => {
            this.toast.DisplaySimpleToast("Photo has been uploaded. Refreshing...");
            this.LoadImageList();
        }, error => {
            this.toast.DisplaySimpleToast("Unable to upload photo.");
        });
    }
    ChangeListener($event) {
        this.files = $event.target.files[0];
        this.UploadFiles();
    }
};
PhotosPage.ctorParameters = () => [
    { type: _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"] },
    { type: _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"] },
    { type: _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"] },
    { type: _services_bucket_service__WEBPACK_IMPORTED_MODULE_6__["BucketService"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("file", { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], PhotosPage.prototype, "file_input", void 0);
PhotosPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-photos',
        template: __webpack_require__(/*! raw-loader!./photos.page.html */ "./node_modules/raw-loader/index.js!./src/app/photos/photos.page.html"),
        styles: [__webpack_require__(/*! ./photos.page.scss */ "./src/app/photos/photos.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"],
        _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"],
        _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"],
        _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"],
        _services_bucket_service__WEBPACK_IMPORTED_MODULE_6__["BucketService"]])
], PhotosPage);



/***/ })

}]);
//# sourceMappingURL=photos-photos-module-es2015.js.map