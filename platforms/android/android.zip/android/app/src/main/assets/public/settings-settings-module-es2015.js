(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["settings-settings-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/settings/settings.page.html":
/*!***********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/settings/settings.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content class=\"settings-page\">\n    <div class=\"common-header-spacer\"></div>\n    <div class=\"common-header\">\n        <div class=\"common-header-icon\">\n            <ion-icon name=\"md-arrow-back\" slot=\"end\" (click)=\"nav.PopView();\"> \n            </ion-icon>\n        </div>\n        <div class=\"common-header-title\">\n            Settings\n        </div>\n    </div>\n\n    <div class=\"settings-page-block\">\n        <div class=\"settings-page-block-title\">\n            Recieve Pictures\n        </div>\n        <div class=\"settings-page-block-toggle\">\n            <div class=\"settings-page-block-toggle-input\">\n                <ion-toggle [(ngModel)]=\"form.settings.hide_image_content\"\n                            (ionChange)=\"Submit();\"></ion-toggle>\n            </div>\n            <div class=\"settings-page-block-toggle-label\">\n                Allow other WhoYou users to send you pictures in their messages.\n            </div>\n        </div>\n\n        <div class=\"settings-page-block-title\">\n            Show Search History On Profile\n        </div>\n        <div class=\"settings-page-block-toggle\">\n            <div class=\"settings-page-block-toggle-input\">\n                <ion-toggle [(ngModel)]=\"form.settings.hide_past_searches\"\n                            (ionChange)=\"Submit();\"></ion-toggle>\n            </div>\n            <div class=\"settings-page-block-toggle-label\">\n                Allow other users to see your search history.\n            </div>\n        </div>\n\n        <div class=\"settings-page-block-title\">\n            Hide Users Who Have Been Flagged\n        </div>\n        <div class=\"settings-page-block-toggle\">\n            <div class=\"settings-page-block-toggle-input\">\n                <ion-toggle [(ngModel)]=\"form.settings.hide_flagged_content\"\n                            (ionChange)=\"Submit();\"></ion-toggle>\n            </div>\n            <div class=\"settings-page-block-toggle-label\">\n                Don't show me users in search results that other users have flagged.\n            </div>\n        </div>\n\n        <div class=\"settings-page-block-title\">\n            Geographic Range (Miles)\n        </div>\n        <div class=\"settings-page-block-slider\">\n            <ion-range min=\"1\" max=\"250\" color=\"secondary\" (ionChange)=\"Submit();\" pin\n                       [(ngModel)]=\"form.settings.discovery_radius_in_miles\">\n                <ion-label slot=\"start\">1</ion-label>\n                <ion-label slot=\"end\">250</ion-label>\n            </ion-range>\n        </div>\n\n        <div class=\"settings-page-block-title\">\n            Go Premium\n        </div>\n        <div class=\"settings-page-block-paragraph\">\n            Become a Premium user for special perks and features.&nbsp; \n            <a (click)=\"PerformPremium();\">Learn More</a>\n        </div>\n\n        <div class=\"settings-page-block-title\">\n            Gender Identity\n        </div>\n        <div class=\"settings-page-block-radio\">\n            <div class=\"settings-page-block-radio-item\">\n                <input type=\"radio\" value=\"male\" name=\"group1\"\n                       [(ngModel)]=\"form.settings.gender\" (ionChange)=\"Submit();\" />\n                <label>Male</label>\n            </div>\n            <div class=\"settings-page-block-radio-item\">\n                <input type=\"radio\" value=\"female\"  name=\"group1\"\n                       [(ngModel)]=\"form.settings.gender\" (ionChange)=\"Submit();\" />\n                <label>Female</label>\n            </div>\n            <div class=\"settings-page-block-radio-item\">\n                <input type=\"radio\" value=\"non-binary\"  name=\"group1\"\n                       [(ngModel)]=\"form.settings.gender\" (ionChange)=\"Submit();\" />\n                <label>Non-Binary</label>\n            </div>\n            <div class=\"settings-page-block-radio-item\">\n                <input type=\"radio\" value=\"\"  name=\"group1\"\n                       [(ngModel)]=\"form.settings.gender\" (ionChange)=\"Submit();\" />\n                <label>Rather Not Say</label>\n            </div>\n        </div>\n\n        <div class=\"settings-page-block-title\">\n            Gender Messaging Preferences\n        </div>\n        <div class=\"settings-page-block-paragraph\">\n            Choose who can message you based on their self-identified gender identity.\n        </div>\n        <div class=\"settings-page-block-radio\">\n            <div class=\"settings-page-block-radio-item\">\n                <input type=\"radio\" value=\"\"  name=\"group2\"\n                       [(ngModel)]=\"form.settings.preferred_gender\" (ionChange)=\"Submit();\" />\n                <label>Any</label>\n            </div>\n            <div class=\"settings-page-block-radio-item\">\n                <input type=\"radio\" value=\"male\"  name=\"group2\"\n                       [(ngModel)]=\"form.settings.preferred_gender\" (ionChange)=\"Submit();\" />\n                <label>Male</label>\n            </div>\n            <div class=\"settings-page-block-radio-item\">\n                <input type=\"radio\" value=\"female\"  name=\"group2\"\n                       [(ngModel)]=\"form.settings.preferred_gender\" (ionChange)=\"Submit();\" />\n                <label>Female</label>\n            </div>\n            <div class=\"settings-page-block-radio-item\">\n                <input type=\"radio\" value=\"non-binary\"  name=\"group2\"\n                       [(ngModel)]=\"form.settings.preferred_gender\" (ionChange)=\"Submit();\" />\n                <label>Non-Binary</label>\n            </div>\n        </div>\n\n        <div class=\"settings-page-big-button\" (click)=\"PerformLogout();\">\n            Log Out\n        </div>\n        <div class=\"settings-page-big-button\" (click)=\"GoToAdmin();\"\n             *ngIf=\"authentication.user && authentication.user['email'].includes('@whoyouapp.com')\">\n            Admin Panel\n        </div>\n    </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/settings/settings.module.ts":
/*!*********************************************!*\
  !*** ./src/app/settings/settings.module.ts ***!
  \*********************************************/
/*! exports provided: SettingsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsPageModule", function() { return SettingsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _settings_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./settings.page */ "./src/app/settings/settings.page.ts");







const routes = [
    {
        path: '',
        component: _settings_page__WEBPACK_IMPORTED_MODULE_6__["SettingsPage"]
    }
];
let SettingsPageModule = class SettingsPageModule {
};
SettingsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_settings_page__WEBPACK_IMPORTED_MODULE_6__["SettingsPage"]]
    })
], SettingsPageModule);



/***/ }),

/***/ "./src/app/settings/settings.page.scss":
/*!*********************************************!*\
  !*** ./src/app/settings/settings.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".settings-page-big-button {\n  border-radius: 27px;\n  border: solid 3px #9a46bb;\n  font-size: 16px;\n  font-weight: bold;\n  color: #9a46bb;\n  padding: 15px;\n  text-align: center;\n}\n.settings-page-block {\n  padding: 24px;\n}\n.settings-page-block-title {\n  font-size: 16px;\n  font-weight: bold;\n  text-transform: uppercase;\n  margin-bottom: 15px;\n}\n.settings-page-block-toggle {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n          flex-direction: row;\n  margin-bottom: 32px;\n}\n.settings-page-block-toggle-input ion-toggle {\n  --background-checked: rgb(154, 70, 187);\n}\n.settings-page-block-toggle-label {\n  font-size: 14px;\n}\n.settings-page-block-slider ion-range {\n  padding-top: 0px;\n}\n.settings-page-block-paragraph {\n  font-size: 16px;\n  line-height: 24px;\n  margin-bottom: 32px;\n}\n.settings-page-block-paragraph a {\n  font-weight: bold;\n  color: #9a46bb;\n}\n.settings-page-block-radio {\n  margin-bottom: 32px;\n}\n.settings-page-block-radio-item {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n          flex-direction: row;\n}\n.settings-page-block-radio-item input {\n  height: 32px;\n  width: 32px;\n  margin-right: 12px;\n  margin-bottom: 16px;\n}\n.settings-page-block-radio-item label {\n  font-size: 16px;\n  line-height: 32px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zaGFudGFtc2hhcm1hL0Rvd25sb2Fkcy93aG95b3Uvc3JjL2FwcC9zZXR0aW5ncy9zZXR0aW5ncy5wYWdlLnNjc3MiLCJzcmMvYXBwL3NldHRpbmdzL3NldHRpbmdzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFDQztFQUNDLG1CQUFBO0VBQ0EseUJBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxjQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0FDQUY7QURHQztFQUNDLGFBQUE7QUNERjtBREdFO0VBQ0MsZUFBQTtFQUNBLGlCQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQ0RIO0FESUU7RUFDQyxvQkFBQTtFQUFBLGFBQUE7RUFDQSw4QkFBQTtFQUFBLDZCQUFBO1VBQUEsbUJBQUE7RUFDQSxtQkFBQTtBQ0ZIO0FES0k7RUFDQyx1Q0FBQTtBQ0hMO0FET0c7RUFDQyxlQUFBO0FDTEo7QURVRztFQUNDLGdCQUFBO0FDUko7QURZRTtFQUNDLGVBQUE7RUFDQSxpQkFBQTtFQUNBLG1CQUFBO0FDVkg7QURZRztFQUNDLGlCQUFBO0VBQ0EsY0FBQTtBQ1ZKO0FEY0U7RUFDQyxtQkFBQTtBQ1pIO0FEY0c7RUFDQyxvQkFBQTtFQUFBLGFBQUE7RUFDQSw4QkFBQTtFQUFBLDZCQUFBO1VBQUEsbUJBQUE7QUNaSjtBRGNJO0VBQ0MsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0FDWkw7QURtQkk7RUFDQyxlQUFBO0VBQ0EsaUJBQUE7QUNqQkwiLCJmaWxlIjoic3JjL2FwcC9zZXR0aW5ncy9zZXR0aW5ncy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc2V0dGluZ3MtcGFnZSB7XG5cdCYtYmlnLWJ1dHRvbiB7XG5cdFx0Ym9yZGVyLXJhZGl1czogMjdweDtcblx0XHRib3JkZXI6IHNvbGlkIDNweCByZ2IoMTU0LCA3MCwgMTg3KTtcblx0XHRmb250LXNpemU6IDE2cHg7XG5cdFx0Zm9udC13ZWlnaHQ6IGJvbGQ7XG5cdFx0Y29sb3I6IHJnYigxNTQsIDcwLCAxODcpO1xuXHRcdHBhZGRpbmc6IDE1cHg7XG5cdFx0dGV4dC1hbGlnbjogY2VudGVyO1xuXHR9XG5cblx0Ji1ibG9jayB7XG5cdFx0cGFkZGluZzogMjRweDtcblxuXHRcdCYtdGl0bGUge1xuXHRcdFx0Zm9udC1zaXplOiAxNnB4O1xuXHRcdFx0Zm9udC13ZWlnaHQ6IGJvbGQ7XG5cdFx0XHR0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuXHRcdFx0bWFyZ2luLWJvdHRvbTogMTVweDtcblx0XHR9XG5cblx0XHQmLXRvZ2dsZSB7XG5cdFx0XHRkaXNwbGF5OiBmbGV4O1xuXHRcdFx0ZmxleC1kaXJlY3Rpb246IHJvdztcblx0XHRcdG1hcmdpbi1ib3R0b206IDMycHg7XG5cblx0XHRcdCYtaW5wdXQge1xuXHRcdFx0XHRpb24tdG9nZ2xlIHtcblx0XHRcdFx0XHQtLWJhY2tncm91bmQtY2hlY2tlZDogcmdiKDE1NCwgNzAsIDE4Nyk7XG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0Ji1sYWJlbCB7XG5cdFx0XHRcdGZvbnQtc2l6ZTogMTRweDtcblx0XHRcdH1cblx0XHR9XG5cblx0XHQmLXNsaWRlciB7XG5cdFx0XHRpb24tcmFuZ2Uge1xuXHRcdFx0XHRwYWRkaW5nLXRvcDogMHB4O1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdCYtcGFyYWdyYXBoIHtcblx0XHRcdGZvbnQtc2l6ZTogMTZweDtcblx0XHRcdGxpbmUtaGVpZ2h0OiAyNHB4O1xuXHRcdFx0bWFyZ2luLWJvdHRvbTogMzJweDtcblxuXHRcdFx0YSB7XG5cdFx0XHRcdGZvbnQtd2VpZ2h0OiBib2xkO1xuXHRcdFx0XHRjb2xvcjogcmdiKDE1NCwgNzAsIDE4Nyk7XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ji1yYWRpbyB7XG5cdFx0XHRtYXJnaW4tYm90dG9tOiAzMnB4O1xuXG5cdFx0XHQmLWl0ZW0ge1xuXHRcdFx0XHRkaXNwbGF5OiBmbGV4O1xuXHRcdFx0XHRmbGV4LWRpcmVjdGlvbjogcm93O1xuXG5cdFx0XHRcdGlucHV0IHtcblx0XHRcdFx0XHRoZWlnaHQ6IDMycHg7XG5cdFx0XHRcdFx0d2lkdGg6IDMycHg7XG5cdFx0XHRcdFx0bWFyZ2luLXJpZ2h0OiAxMnB4O1xuXHRcdFx0XHRcdG1hcmdpbi1ib3R0b206IDE2cHg7XG5cblx0XHRcdFx0XHQmOmNoZWNrZWQge1xuXHRcdFx0XHRcdFx0Ly8gYmFja2dyb3VuZDogcmdiKDE1NCwgNzAsIDE4Nyk7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cblx0XHRcdFx0bGFiZWwge1xuXHRcdFx0XHRcdGZvbnQtc2l6ZTogMTZweDtcblx0XHRcdFx0XHRsaW5lLWhlaWdodDogMzJweDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fVxufVxuXG5cblxuXG5cblxuIiwiLnNldHRpbmdzLXBhZ2UtYmlnLWJ1dHRvbiB7XG4gIGJvcmRlci1yYWRpdXM6IDI3cHg7XG4gIGJvcmRlcjogc29saWQgM3B4ICM5YTQ2YmI7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGNvbG9yOiAjOWE0NmJiO1xuICBwYWRkaW5nOiAxNXB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4uc2V0dGluZ3MtcGFnZS1ibG9jayB7XG4gIHBhZGRpbmc6IDI0cHg7XG59XG4uc2V0dGluZ3MtcGFnZS1ibG9jay10aXRsZSB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIG1hcmdpbi1ib3R0b206IDE1cHg7XG59XG4uc2V0dGluZ3MtcGFnZS1ibG9jay10b2dnbGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBtYXJnaW4tYm90dG9tOiAzMnB4O1xufVxuLnNldHRpbmdzLXBhZ2UtYmxvY2stdG9nZ2xlLWlucHV0IGlvbi10b2dnbGUge1xuICAtLWJhY2tncm91bmQtY2hlY2tlZDogcmdiKDE1NCwgNzAsIDE4Nyk7XG59XG4uc2V0dGluZ3MtcGFnZS1ibG9jay10b2dnbGUtbGFiZWwge1xuICBmb250LXNpemU6IDE0cHg7XG59XG4uc2V0dGluZ3MtcGFnZS1ibG9jay1zbGlkZXIgaW9uLXJhbmdlIHtcbiAgcGFkZGluZy10b3A6IDBweDtcbn1cbi5zZXR0aW5ncy1wYWdlLWJsb2NrLXBhcmFncmFwaCB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgbGluZS1oZWlnaHQ6IDI0cHg7XG4gIG1hcmdpbi1ib3R0b206IDMycHg7XG59XG4uc2V0dGluZ3MtcGFnZS1ibG9jay1wYXJhZ3JhcGggYSB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBjb2xvcjogIzlhNDZiYjtcbn1cbi5zZXR0aW5ncy1wYWdlLWJsb2NrLXJhZGlvIHtcbiAgbWFyZ2luLWJvdHRvbTogMzJweDtcbn1cbi5zZXR0aW5ncy1wYWdlLWJsb2NrLXJhZGlvLWl0ZW0ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xufVxuLnNldHRpbmdzLXBhZ2UtYmxvY2stcmFkaW8taXRlbSBpbnB1dCB7XG4gIGhlaWdodDogMzJweDtcbiAgd2lkdGg6IDMycHg7XG4gIG1hcmdpbi1yaWdodDogMTJweDtcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcbn1cbi5zZXR0aW5ncy1wYWdlLWJsb2NrLXJhZGlvLWl0ZW0gbGFiZWwge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGxpbmUtaGVpZ2h0OiAzMnB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/settings/settings.page.ts":
/*!*******************************************!*\
  !*** ./src/app/settings/settings.page.ts ***!
  \*******************************************/
/*! exports provided: SettingsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SettingsPage", function() { return SettingsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/toast.service */ "./src/app/services/toast.service.ts");
/* harmony import */ var _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/navigation.service */ "./src/app/services/navigation.service.ts");
/* harmony import */ var _services_query_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/query.service */ "./src/app/services/query.service.ts");
/* harmony import */ var _services_bucket_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/bucket.service */ "./src/app/services/bucket.service.ts");
/* harmony import */ var _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/photo-viewer/ngx */ "./node_modules/@ionic-native/photo-viewer/ngx/index.js");








let SettingsPage = class SettingsPage {
    constructor(authentication, toast, nav, query, bucket, photos) {
        this.authentication = authentication;
        this.toast = toast;
        this.nav = nav;
        this.query = query;
        this.bucket = bucket;
        this.photos = photos;
        this.form = {};
        this.form = {
            "settings": authentication.user.settings
        };
    }
    PerformLogout() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            yield this.authentication.ClearUser();
            this.nav.NavigateRoot('home', {});
        });
    }
    PerformPremium() {
        alert('Premium is coming soon!');
    }
    GoToAdmin() {
        this.nav.NavigateForward('admin-menu', {});
        //this.nav.NavigateForward('admin', {});
    }
    ngOnInit() {
    }
    ionViewWillLeave() {
        this.Submit();
    }
    compareFn(e1, e2) {
        return parseInt(e1) == parseInt(e2);
    }
    Submit() {
        console.log('this.form', this.form);
        this.query.request('users/'.concat(this.authentication.user.id), 'PATCH', {}, this.form).subscribe(user => {
            var user_data = user['data'];
            this.authentication.SetUser(user_data);
            // this.toast.DisplaySimpleToast(
            //         "Profile successfully updated."
            //     );
        }, error => {
            this.toast.DisplaySimpleToast("Unable to update profile.");
        });
    }
};
SettingsPage.ctorParameters = () => [
    { type: _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"] },
    { type: _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"] },
    { type: _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"] },
    { type: _services_bucket_service__WEBPACK_IMPORTED_MODULE_6__["BucketService"] },
    { type: _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_7__["PhotoViewer"] }
];
SettingsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-settings',
        template: __webpack_require__(/*! raw-loader!./settings.page.html */ "./node_modules/raw-loader/index.js!./src/app/settings/settings.page.html"),
        styles: [__webpack_require__(/*! ./settings.page.scss */ "./src/app/settings/settings.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"],
        _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"],
        _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"],
        _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"],
        _services_bucket_service__WEBPACK_IMPORTED_MODULE_6__["BucketService"],
        _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_7__["PhotoViewer"]])
], SettingsPage);



/***/ })

}]);
//# sourceMappingURL=settings-settings-module-es2015.js.map