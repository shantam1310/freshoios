(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["advanced-search-advanced-search-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/advanced-search/advanced-search.page.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/advanced-search/advanced-search.page.html ***!
  \*************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-header>\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-back-button></ion-back-button>\n        </ion-buttons>\n        <ion-title>\n            <ion-searchbar [(ngModel)]=\"search\" placeholder=\"Search for anything\" mode=\"ios\" (search)=\"PerformSearch()\" autocomplete=\"off\" #myInput></ion-searchbar>\n        </ion-title>\n    </ion-toolbar>\n</ion-header>\n\n<ion-content>\n    <div style=\"padding: 24px;\">\n        <ng-container *ngIf=\"!search\">\n            <!-- No Messages Available -->\n            <div class=\"center-column\">\n                <div class=\"spacer\" style=\"height: 23px;\"></div>\n                <img src=\"/assets/dancing_guy.png\" class=\"graphic-image\" />\n                <h3 class=\"generic-h3\">Search for anything that interests you.</h3>\n                <p class=\"notice-paragraph\">\n                    If someone near you searches for the same thing, you can send them a message request.\n                </p>\n            </div>\n        </ng-container>\n        <ng-container *ngIf=\"search\">\n            <h1 class=\"generic-h1\">\n                Why are you searching for <strong>{{ search }}</strong>? (optional)\n            </h1>\n            <p class=\"notice-paragraph\">\n                Refining your search helps us pair you with others searching for the same reason.\n            </p>\n            <div expand=\"block\" color=\"light\" size=\"large\" class=\"whoyou-text-button\" (click)=\"PerformSearch();\">\n                <span>Skip This Step</span>\n            </div>\n            <div class=\"connotation-list\">\n                <div class=\"connotation-list-item {{ thisConnotation.clicked ? 'is-clicked' : '' }}\" *ngFor=\"let thisConnotation of availableConnotations\">\n                    <div class=\"connotation-list-item-label\">\n                        {{ thisConnotation.phrase }} <strong>{{ search }}</strong>\n                    </div>\n                    <div class=\"connotation-list-item-button\" (click)=\"PerformSearchWithConnotation(thisConnotation.phrase, thisConnotation);\">\n                        <span>Select</span>\n                    </div>\n                </div>\n            </div>\n        </ng-container>\n    </div>\n</ion-content>"

/***/ }),

/***/ "./src/app/advanced-search/advanced-search.module.ts":
/*!***********************************************************!*\
  !*** ./src/app/advanced-search/advanced-search.module.ts ***!
  \***********************************************************/
/*! exports provided: AdvancedSearchPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdvancedSearchPageModule", function() { return AdvancedSearchPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _advanced_search_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./advanced-search.page */ "./src/app/advanced-search/advanced-search.page.ts");







const routes = [
    {
        path: '',
        component: _advanced_search_page__WEBPACK_IMPORTED_MODULE_6__["AdvancedSearchPage"]
    }
];
let AdvancedSearchPageModule = class AdvancedSearchPageModule {
};
AdvancedSearchPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_advanced_search_page__WEBPACK_IMPORTED_MODULE_6__["AdvancedSearchPage"]]
    })
], AdvancedSearchPageModule);



/***/ }),

/***/ "./src/app/advanced-search/advanced-search.page.scss":
/*!***********************************************************!*\
  !*** ./src/app/advanced-search/advanced-search.page.scss ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".connotation-list-item {\n  margin-top: 40px;\n}\n.connotation-list-item-label {\n  color: #4a4a4a;\n  font-size: 16px;\n}\n.connotation-list-item-button {\n  margin-top: 8px;\n  width: 124px;\n  background: #9a46bb;\n  color: white;\n  text-transform: uppercase;\n  font-weight: bold;\n  text-align: center;\n  padding: 5px;\n  border-radius: 15px;\n  -webkit-transition: width 0.2s, margin 0.2s;\n  transition: width 0.2s, margin 0.2s;\n}\n.connotation-list-item.is-clicked .connotation-list-item-button {\n  margin: 0px 12px;\n  margin-top: 8px;\n  width: 100px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zaGFudGFtc2hhcm1hL0Rvd25sb2Fkcy93aG95b3Uvc3JjL2FwcC9hZHZhbmNlZC1zZWFyY2gvYWR2YW5jZWQtc2VhcmNoLnBhZ2Uuc2NzcyIsInNyYy9hcHAvYWR2YW5jZWQtc2VhcmNoL2FkdmFuY2VkLXNlYXJjaC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0M7RUFDQyxnQkFBQTtBQ0FGO0FERUU7RUFDQyxjQUFBO0VBQ0EsZUFBQTtBQ0FIO0FER0U7RUFDQyxlQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLHlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxrQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUVBLDJDQUFBO0VBQUEsbUNBQUE7QUNGSDtBRE1HO0VBQ0MsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsWUFBQTtBQ0pKIiwiZmlsZSI6InNyYy9hcHAvYWR2YW5jZWQtc2VhcmNoL2FkdmFuY2VkLXNlYXJjaC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuY29ubm90YXRpb24tbGlzdCB7XG5cdCYtaXRlbSB7XG5cdFx0bWFyZ2luLXRvcDogNDBweDtcblxuXHRcdCYtbGFiZWwge1xuXHRcdFx0Y29sb3I6IHJnYig3NCw3NCw3NCk7XG5cdFx0XHRmb250LXNpemU6IDE2cHg7XG5cdFx0fVxuXG5cdFx0Ji1idXR0b24ge1xuXHRcdFx0bWFyZ2luLXRvcDogOHB4O1xuXHRcdFx0d2lkdGg6IDEyNHB4O1xuXHRcdFx0YmFja2dyb3VuZDogcmdiKDE1NCwgNzAsIDE4Nyk7XG5cdFx0XHRjb2xvcjogd2hpdGU7XG5cdFx0XHR0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuXHRcdFx0Zm9udC13ZWlnaHQ6IGJvbGQ7XG5cdFx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XG5cdFx0XHRwYWRkaW5nOiA1cHg7XG5cdFx0XHRib3JkZXItcmFkaXVzOiAxNXB4O1xuXG5cdFx0XHR0cmFuc2l0aW9uOiB3aWR0aCAwLjJzLCBtYXJnaW4gMC4ycztcblx0XHR9XG5cblx0XHQmLmlzLWNsaWNrZWQge1xuXHRcdFx0LmNvbm5vdGF0aW9uLWxpc3QtaXRlbS1idXR0b24ge1xuXHRcdFx0XHRtYXJnaW46IDBweCAxMnB4O1xuXHRcdFx0XHRtYXJnaW4tdG9wOiA4cHg7XG5cdFx0XHRcdHdpZHRoOiAxMDBweDtcblx0XHRcdH1cblx0XHR9XG5cdH1cbn0iLCIuY29ubm90YXRpb24tbGlzdC1pdGVtIHtcbiAgbWFyZ2luLXRvcDogNDBweDtcbn1cbi5jb25ub3RhdGlvbi1saXN0LWl0ZW0tbGFiZWwge1xuICBjb2xvcjogIzRhNGE0YTtcbiAgZm9udC1zaXplOiAxNnB4O1xufVxuLmNvbm5vdGF0aW9uLWxpc3QtaXRlbS1idXR0b24ge1xuICBtYXJnaW4tdG9wOiA4cHg7XG4gIHdpZHRoOiAxMjRweDtcbiAgYmFja2dyb3VuZDogIzlhNDZiYjtcbiAgY29sb3I6IHdoaXRlO1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBwYWRkaW5nOiA1cHg7XG4gIGJvcmRlci1yYWRpdXM6IDE1cHg7XG4gIHRyYW5zaXRpb246IHdpZHRoIDAuMnMsIG1hcmdpbiAwLjJzO1xufVxuLmNvbm5vdGF0aW9uLWxpc3QtaXRlbS5pcy1jbGlja2VkIC5jb25ub3RhdGlvbi1saXN0LWl0ZW0tYnV0dG9uIHtcbiAgbWFyZ2luOiAwcHggMTJweDtcbiAgbWFyZ2luLXRvcDogOHB4O1xuICB3aWR0aDogMTAwcHg7XG59Il19 */"

/***/ }),

/***/ "./src/app/advanced-search/advanced-search.page.ts":
/*!*********************************************************!*\
  !*** ./src/app/advanced-search/advanced-search.page.ts ***!
  \*********************************************************/
/*! exports provided: AdvancedSearchPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AdvancedSearchPage", function() { return AdvancedSearchPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/toast.service */ "./src/app/services/toast.service.ts");
/* harmony import */ var _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/navigation.service */ "./src/app/services/navigation.service.ts");
/* harmony import */ var _services_query_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/query.service */ "./src/app/services/query.service.ts");
/* harmony import */ var _services_loading_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/loading.service */ "./src/app/services/loading.service.ts");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");









const { Modals } = _capacitor_core__WEBPACK_IMPORTED_MODULE_7__["Plugins"];
let AdvancedSearchPage = class AdvancedSearchPage {
    constructor(authentication, toast, nav, query, loading_service) {
        this.authentication = authentication;
        this.toast = toast;
        this.nav = nav;
        this.query = query;
        this.loading_service = loading_service;
        this.search_string = "";
        this.connotation = "";
        this.availableConnotations = [
            { phrase: 'I want to talk about' },
            { phrase: 'I want to visit' },
            { phrase: 'I want to learn about' },
            { phrase: 'I want to sell' },
            { phrase: 'I want to try' },
            { phrase: 'I want to buy' },
            { phrase: 'I do not like' },
            { phrase: 'I do like' },
            { phrase: 'I want to be friends with someone also into' },
            { phrase: 'I want to date someone also into' },
            { phrase: 'I want to go into business with someone about' },
        ];
    }
    ngOnInit() {
    }
    ShowInfoAlert() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            let alertRet = yield Modals.alert({
                title: 'Info',
                message: 'The different connotation options below your search allow you to be very specific on WHY you are searching for your word or phrase. If you just want to search for your word or phrase by itself, you can do that as well.'
            });
        });
    }
    ngAfterViewInit() {
        //this.myInput.setFocus();
        console.log("Set focus.");
        setTimeout(() => {
            this.myInput.setFocus();
        }, 1000);
    }
    PerformSearch() {
        // this.search_string = $event.target.value;
        this.search = this.search.replace(/[^\w\s\'\"\-]/gi, '').toLowerCase();
        this.nav.NavigateForward('search/' + this.search, {
            "search_string": this.search,
            "connotation": this.connotation
        });
    }
    PerformSearchWithConnotation(selectedConnotation, connotationObject) {
        connotationObject['clicked'] = true;
        setTimeout(() => {
            this.connotation = selectedConnotation;
            this.PerformSearch();
            connotationObject['clicked'] = false;
        }, 200);
    }
};
AdvancedSearchPage.ctorParameters = () => [
    { type: _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"] },
    { type: _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"] },
    { type: _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"] },
    { type: _services_loading_service__WEBPACK_IMPORTED_MODULE_6__["LoadingService"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('myInput', { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
], AdvancedSearchPage.prototype, "myInput", void 0);
AdvancedSearchPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-advanced-search',
        template: __webpack_require__(/*! raw-loader!./advanced-search.page.html */ "./node_modules/raw-loader/index.js!./src/app/advanced-search/advanced-search.page.html"),
        styles: [__webpack_require__(/*! ./advanced-search.page.scss */ "./src/app/advanced-search/advanced-search.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"],
        _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"],
        _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"],
        _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"],
        _services_loading_service__WEBPACK_IMPORTED_MODULE_6__["LoadingService"]])
], AdvancedSearchPage);



/***/ }),

/***/ "./src/app/services/toast.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/toast.service.ts ***!
  \*******************************************/
/*! exports provided: ToastService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToastService", function() { return ToastService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



let ToastService = class ToastService {
    constructor(toast_controller) {
        this.toast_controller = toast_controller;
    }
    DisplaySimpleToast(message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const toast = yield this.toast_controller.create({
                "message": message, "duration": 2000
            });
            toast.present();
        });
    }
};
ToastService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
], ToastService);



/***/ })

}]);
//# sourceMappingURL=advanced-search-advanced-search-module-es2015.js.map