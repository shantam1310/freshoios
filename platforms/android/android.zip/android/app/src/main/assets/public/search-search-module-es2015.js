(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["search-search-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/search/search.page.html":
/*!*******************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/search/search.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n    <div class=\"common-header-spacer\"></div>\n    <div class=\"common-header\">\n        <ion-avatar slot=\"start\" [routerLink]=\"'/profile'\" routerDirection=\"forward\" class=\"common-header-avatar\">\n            <img [src]=\"image_data ? image_data.media_url : authentication.default_avatar\">\n        </ion-avatar>\n        <div class=\"common-header-title\">\n            <ion-searchbar debounce=\"1500\" placeholder=\"Search for anything\" (click)=\"OpenAdvancedSearch();\" autocomplete=\"off\" style=\"padding: 0px;\"></ion-searchbar>\n        </div>\n    </div>\n\n    <h1 class=\"generic-h1\" *ngIf=\"search_results && search_results.length\" style=\"padding-left: 16px; font-weight: bold; font-size: 16px;\">\n        {{search_results.length}} RESULTS FOUND\n    </h1>\n    <div class=\"search-index\" *ngIf=\"mode=='SEARCHED'\">\n        <ng-container *ngFor=\"let this_result of search_results\">\n            <ion-item>\n                <div class=\"search-index-item\">\n                    <div class=\"search-index-item-row\" (click)=\"GoToUser(this_result.user);\">\n                        <div class=\"search-index-item-image\">\n                            <ion-avatar>\n                                <img [src]=\"this_result.user_details.profile_photo ? this_result.user_details.profile_photo : authentication.default_avatar\">\n                            </ion-avatar>\n                        </div>\n                        <div class=\"search-index-item-content\">\n                            <h2>{{this_result.user_details.company_name}}</h2>\n                            <p>\n                                {{this_result.distance_in_miles | number:'1.1-1'}} mi away\n                            </p>\n                            <p>\n                                \"{{this_result.connotation}}{{this_result.phrase}}\"\n                            </p>\n                        </div>\n                    </div>\n                    <div class=\"search-index-item-row\" *ngIf=\"authentication.user && authentication.user['email'].includes('@whoyouapp.com')\">\n                        <ion-button (click)=\"DeleteSearch(this_result.id, this_result.phrase);\">Delete Search: {{this_result.phrase}}</ion-button>\n                    </div>\n                </div>\n            </ion-item>\n        </ng-container>\n    </div>\n\n    <ng-container *ngIf=\"!search_results || !search_results.length\">\n        <!-- No Searches Available -->\n        <div class=\"center-column\">\n            <div class=\"spacer\" style=\"height: 35px;\"></div>\n            <img src=\"/assets/girl_laying.png\" class=\"graphic-image\" style=\"max-width: 259px; height: auto;\" />\n            <div class=\"spacer\" style=\"height: 22px;\"></div>\n            <h3 class=\"generic-h3\">No Results Found for \"{{search_string}}\"</h3>\n            <p class=\"notice-paragraph\">\n                We couldn't find anyone near you searching for this phrase.\n            </p>\n            <p class=\"notice-paragraph\">\n                Try changing your search or increasing your\n                <a [routerLink]=\"'/settings'\" routerDirection=\"forward\">\n                    geographic range.\n                </a>\n            </p>\n        </div>\n\n        <div class=\"padding-normal\">\n            <h2 class=\"generic-h2\">Trending Searches In Your Area</h2>\n\n            <div class=\"whoyou-phrase-grid\">\n                <div class=\"whoyou-phrase-grid-item\" *ngFor=\"let this_result of nearby_searches\" (click)=\"PerformSearchOfPhrase(this_result.phrase);\">\n                    {{this_result.phrase}}\n                </div>\n                <div class=\"whoyou-phrase-grid-item\" *ngIf=\"!nearby_searches.length\" (click)=\"PerformSearchOfPhrase('sports');\">\n                    Sports\n                </div>\n            </div>\n        </div>\n    </ng-container>\n\n\n    <!-- NOTHING BELOW THIS POINT MATTERS -->\n\n\n\n    <!-- Results -->\n    <!-- <ion-list *ngIf=\"nothing_never_load\"> -->\n\n    <ion-list>\n        <!-- Status -->\n        <ion-item *ngIf=\"mode != 'NO_SEARCH'\" class=\"search-info ion-text-center\" lines=\"none\">\n            <!-- <ng-container *ngIf=\"mode=='NO_SEARCH'\">\n                You haven't searched anything yet. Here's some search activity near you!\n            </ng-container> -->\n            <ng-container *ngIf=\"mode=='SEARCHED'\">\n                These other WhoYousers are searching for \"{{search_string}}\" near you!\n            </ng-container>\n            <ng-container *ngIf=\"mode=='NO_MATCHES'\">\n                We couldn't find anyone near you searching for \"{{search_string}}\". Here are some alternative topics being searched near you.\n            </ng-container>\n        </ion-item>\n\n        <!-- Search Results -->\n        <ng-container *ngIf=\"mode=='SEARCHED'\">\n            <ng-container *ngFor=\"let this_result of search_results\">\n                <ion-item (click)=\"GoToUser(this_result.user);\" class=\"search-result\">\n                    <!-- TODO - PORT THIS -->\n                    <ion-icon name=\"md-chatbubbles\" slot=\"end\" *ngIf=\"mode=='SEARCHED'\"></ion-icon>\n\n                </ion-item>\n\n                <!-- TODO - PORT THIS -->\n                <ion-item *ngIf=\"authentication.user && authentication.user['email'].includes('@whoyouapp.com')\">\n                    <ion-button (click)=\"DeleteSearch(this_result.id, this_result.phrase);\">Delete Search: {{this_result.phrase}}</ion-button>\n                </ion-item>\n\n\n            </ng-container>\n\n        </ng-container>\n\n        <!-- Nearby Results -->\n        <ng-container *ngIf=\"mode!='SEARCHED'\">\n            <ng-container *ngFor=\"let this_result of nearby_searches\">\n                <ion-item (click)=\"GoToUser(this_result.user);\" class=\"search-result\" *ngIf=\"filtered_recommendations && !filtered_recommendations.includes(this_result.phrase)\">\n                    <!-- <ion-avatar slot=\"start\">\n                        <img [src]=\"this_result.user_details.profile_photo ? this_result.user_details.profile_photo : authentication.default_avatar\">\n                    </ion-avatar> -->\n                    <ion-label>\n                        <h3>{{this_result.phrase}}</h3>\n                        <!-- <p>{{this_result.user_details.company_name}}</p> -->\n                    </ion-label>\n                    <!-- <ion-icon name=\"md-chatbubbles\" slot=\"end\"></ion-icon> -->\n                </ion-item>\n            </ng-container>\n        </ng-container>\n\n        <ion-item *ngIf=\"more_results_exist\" lines=\"none\">\n            <ion-button expand=\"full\" class=\"whoyou-button\" (click)=\"GetMoreSearchMatches();\">Load More</ion-button>\n        </ion-item>\n\n    </ion-list>\n\n    <!--     <div> // REFERENCE FOR VARIOUS STATES\n        <div class=\"whoyou-search\">\n            <ion-searchbar debounce=\"1500\" placeholder=\"Search Words or Phrases...\" (click)=\"OpenAdvancedSearch();\" autocomplete=\"off\"></ion-searchbar>\n        </div>\n        <p class=\"whoyou-alternative-search\" style=\"padding-left: 8px; padding-right: 8px;\" *ngIf=\"!loading_service.prompt\">\n            {{mode == \"NO_SEARCH\" ? \"Searches near you.You'll have to search for these words if you want to speak with these users.\" : \"let's get connecting\"}}\n        </p>\n    </div> -->\n\n\n</ion-content>\n\n<ion-footer>\n    <ion-toolbar>\n        <ion-tabs>\n            <ion-tab-bar slot=\"bottom\">\n                <ion-tab-button [routerLink]=\"'/profile'\" routerDirection=\"root\">\n                    <ion-icon name=\"md-person\"></ion-icon>\n                </ion-tab-button>\n                <ion-tab-button [routerLink]=\"'/dashboard'\" routerDirection=\"root\">\n                    <ion-icon name=\"md-search\"></ion-icon>\n                </ion-tab-button>\n                <ion-tab-button [routerLink]=\"'/messages'\" routerDirection=\"root\">\n                    <ion-icon name=\"md-chatbubbles\"></ion-icon>\n                </ion-tab-button>\n            </ion-tab-bar>\n        </ion-tabs>\n    </ion-toolbar>\n</ion-footer>"

/***/ }),

/***/ "./src/app/search/search.module.ts":
/*!*****************************************!*\
  !*** ./src/app/search/search.module.ts ***!
  \*****************************************/
/*! exports provided: SearchPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchPageModule", function() { return SearchPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _search_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./search.page */ "./src/app/search/search.page.ts");







const routes = [
    {
        path: '',
        component: _search_page__WEBPACK_IMPORTED_MODULE_6__["SearchPage"]
    }
];
let SearchPageModule = class SearchPageModule {
};
SearchPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_search_page__WEBPACK_IMPORTED_MODULE_6__["SearchPage"]]
    })
], SearchPageModule);



/***/ }),

/***/ "./src/app/search/search.page.scss":
/*!*****************************************!*\
  !*** ./src/app/search/search.page.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".search-index-item {\n  width: 100%;\n  padding-bottom: 15px;\n  padding-top: 15px;\n}\n.search-index-item-row {\n  display: -webkit-box;\n  display: flex;\n}\n.search-index-item-row-request-items {\n  padding-top: 16px;\n}\n.search-index-item-button {\n  display: inline-block;\n  text-align: center;\n  border-radius: 20px;\n  font-size: 13px;\n  padding: 11px;\n}\n.search-index-item-button-delete {\n  background: rgba(208, 2, 27, 0.12);\n  color: #c66363;\n  width: 102px;\n}\n.search-index-item-button-view {\n  background: #9a46bb;\n  color: white;\n  width: calc(100% - 102px - 16px);\n  margin-left: 16px;\n}\n.search-index-item-badge {\n  display: inline-block;\n  background: rgba(154, 70, 187, 0.15);\n  color: #9a46bb;\n  padding: 4px 7px;\n  font-weight: bold;\n  text-transform: uppercase;\n  font-variant: small-caps;\n  font-size: 11px;\n}\n.search-index-item-image {\n  display: inline-block;\n  width: 64px;\n}\n.search-index-item-content {\n  display: inline-block;\n  width: calc(100% - 64px - 13px);\n  margin-left: 13px;\n}\n.search-index-item-content h2 {\n  margin-top: 0px;\n  margin-bottom: 4px;\n  padding-top: 8px;\n  font-size: 14px;\n}\n.search-index-item-content p {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  font-size: 14px;\n  opacity: 0.57;\n}\n.search-index-item-content p.strong {\n  opacity: 1;\n}\n.placeholder-result h3, .placeholder-result p, .placeholder-result ion-avatar {\n  color: transparent !important;\n  background: #D8D8D8 !important;\n  position: relative;\n  overflow: hidden;\n}\n.placeholder-result ion-avatar:before {\n  content: \"\";\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  background: #D8D8D8;\n}\n.placeholder-result h3:after, .placeholder-result p:after, .placeholder-result ion-avatar:after {\n  content: \"\";\n  position: absolute;\n  top: 0px;\n  width: 100%;\n  height: 100%;\n  background: -webkit-gradient(linear, left top, right top, from(rgba(0, 0, 0, 0)), color-stop(rgba(1, 1, 1, 0.15)), to(rgba(0, 0, 0, 0)));\n  background: linear-gradient(90deg, rgba(0, 0, 0, 0), rgba(1, 1, 1, 0.15), rgba(0, 0, 0, 0));\n  -webkit-transform: translateX(-100%);\n          transform: translateX(-100%);\n  -webkit-animation: loading 1.5s infinite;\n          animation: loading 1.5s infinite;\n}\n@-webkit-keyframes loading {\n  100% {\n    -webkit-transform: translateX(100%);\n            transform: translateX(100%);\n  }\n}\n@keyframes loading {\n  100% {\n    -webkit-transform: translateX(100%);\n            transform: translateX(100%);\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zaGFudGFtc2hhcm1hL0Rvd25sb2Fkcy93aG95b3Uvc3JjL2FwcC9zZWFyY2gvc2VhcmNoLnBhZ2Uuc2NzcyIsInNyYy9hcHAvc2VhcmNoL3NlYXJjaC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQ0M7RUFFQyxXQUFBO0VBQ0Esb0JBQUE7RUFDQSxpQkFBQTtBQ0RGO0FER0U7RUFDQyxvQkFBQTtFQUFBLGFBQUE7QUNESDtBREdHO0VBQ0MsaUJBQUE7QUNESjtBREtFO0VBQ0MscUJBQUE7RUFDQSxrQkFBQTtFQUNBLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLGFBQUE7QUNISDtBREtHO0VBQ0Msa0NBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQ0hKO0FETUc7RUFDQyxtQkFBQTtFQUNBLFlBQUE7RUFDQSxnQ0FBQTtFQUNBLGlCQUFBO0FDSko7QURRRTtFQUNDLHFCQUFBO0VBQ0Esb0NBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLHlCQUFBO0VBQ0Esd0JBQUE7RUFDQSxlQUFBO0FDTkg7QURTRTtFQUNDLHFCQUFBO0VBQ0EsV0FBQTtBQ1BIO0FEVUU7RUFDQyxxQkFBQTtFQUNBLCtCQUFBO0VBQ0EsaUJBQUE7QUNSSDtBRFVHO0VBQ0MsZUFBQTtFQUNBLGtCQUFBO0VBRUEsZ0JBQUE7RUFFQSxlQUFBO0FDVko7QURhRztFQUNDLGVBQUE7RUFDQSxrQkFBQTtFQUVBLGVBQUE7RUFFQSxhQUFBO0FDYko7QURlSTtFQUNDLFVBQUE7QUNiTDtBRHFCQztFQUNDLDZCQUFBO0VBQ0EsOEJBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FDbEJGO0FEb0JDO0VBQ0MsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBQ2xCRjtBRG9CQztFQUNJLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFFBQUE7RUFDQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLHdJQUFBO0VBQUEsMkZBQUE7RUFNQSxvQ0FBQTtVQUFBLDRCQUFBO0VBQ0Esd0NBQUE7VUFBQSxnQ0FBQTtBQ3ZCTDtBRDJCQTtFQUNDO0lBQ0MsbUNBQUE7WUFBQSwyQkFBQTtFQ3hCQTtBQUNGO0FEcUJBO0VBQ0M7SUFDQyxtQ0FBQTtZQUFBLDJCQUFBO0VDeEJBO0FBQ0YiLCJmaWxlIjoic3JjL2FwcC9zZWFyY2gvc2VhcmNoLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5zZWFyY2gtaW5kZXgge1xuXHQmLWl0ZW0ge1xuXG5cdFx0d2lkdGg6IDEwMCU7XG5cdFx0cGFkZGluZy1ib3R0b206IDE1cHg7XG5cdFx0cGFkZGluZy10b3A6IDE1cHg7XG5cblx0XHQmLXJvdyB7XG5cdFx0XHRkaXNwbGF5OiBmbGV4O1xuXG5cdFx0XHQmLXJlcXVlc3QtaXRlbXMge1xuXHRcdFx0XHRwYWRkaW5nLXRvcDogMTZweDtcblx0XHRcdH1cblx0XHR9XG5cblx0XHQmLWJ1dHRvbiB7XG5cdFx0XHRkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG5cdFx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XG5cdFx0XHRib3JkZXItcmFkaXVzOiAyMHB4O1xuXHRcdFx0Zm9udC1zaXplOiAxM3B4O1xuXHRcdFx0cGFkZGluZzogMTFweDtcblxuXHRcdFx0Ji1kZWxldGUge1xuXHRcdFx0XHRiYWNrZ3JvdW5kOiByZ2JhKDIwOCwgMiwgMjcsIDAuMTIpO1xuXHRcdFx0XHRjb2xvcjogcmdiKDE5OCwgOTksIDk5KTtcblx0XHRcdFx0d2lkdGg6IDEwMnB4O1xuXHRcdFx0fVxuXG5cdFx0XHQmLXZpZXcge1xuXHRcdFx0XHRiYWNrZ3JvdW5kOiByZ2IoMTU0LCA3MCwgMTg3KTtcblx0XHRcdFx0Y29sb3I6IHdoaXRlO1xuXHRcdFx0XHR3aWR0aDogY2FsYygxMDAlIC0gMTAycHggLSAxNnB4KTtcblx0XHRcdFx0bWFyZ2luLWxlZnQ6IDE2cHg7XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ji1iYWRnZSB7XG5cdFx0XHRkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG5cdFx0XHRiYWNrZ3JvdW5kOiByZ2JhKDE1NCwgNzAsIDE4NywgMC4xNSk7XG5cdFx0XHRjb2xvcjogcmdiKDE1NCwgNzAsIDE4Nyk7XG5cdFx0XHRwYWRkaW5nOiA0cHggN3B4O1xuXHRcdFx0Zm9udC13ZWlnaHQ6IGJvbGQ7XG5cdFx0XHR0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuXHRcdFx0Zm9udC12YXJpYW50OiBzbWFsbC1jYXBzO1xuXHRcdFx0Zm9udC1zaXplOiAxMXB4O1xuXHRcdH1cblxuXHRcdCYtaW1hZ2Uge1xuXHRcdFx0ZGlzcGxheTogaW5saW5lLWJsb2NrO1xuXHRcdFx0d2lkdGg6IDY0cHg7XG5cdFx0fVxuXG5cdFx0Ji1jb250ZW50IHtcblx0XHRcdGRpc3BsYXk6IGlubGluZS1ibG9jaztcblx0XHRcdHdpZHRoOiBjYWxjKDEwMCUgLSA2NHB4IC0gMTNweCk7XG5cdFx0XHRtYXJnaW4tbGVmdDogMTNweDtcblxuXHRcdFx0aDIge1xuXHRcdFx0XHRtYXJnaW4tdG9wOiAwcHg7XG5cdFx0XHRcdG1hcmdpbi1ib3R0b206IDRweDtcblxuXHRcdFx0XHRwYWRkaW5nLXRvcDogOHB4O1xuXG5cdFx0XHRcdGZvbnQtc2l6ZTogMTRweDtcblx0XHRcdH1cblxuXHRcdFx0cCB7XG5cdFx0XHRcdG1hcmdpbi10b3A6IDBweDtcblx0XHRcdFx0bWFyZ2luLWJvdHRvbTogMHB4O1xuXG5cdFx0XHRcdGZvbnQtc2l6ZTogMTRweDtcblxuXHRcdFx0XHRvcGFjaXR5OiAwLjU3O1xuXG5cdFx0XHRcdCYuc3Ryb25nIHtcblx0XHRcdFx0XHRvcGFjaXR5OiAxO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG59XG5cbi5wbGFjZWhvbGRlci1yZXN1bHQge1xuXHRoMywgcCwgaW9uLWF2YXRhciB7XG5cdFx0Y29sb3I6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG5cdFx0YmFja2dyb3VuZDogI0Q4RDhEOCAhaW1wb3J0YW50O1xuXHRcdHBvc2l0aW9uOiByZWxhdGl2ZTtcblx0XHRvdmVyZmxvdzogaGlkZGVuO1xuXHR9XG5cdGlvbi1hdmF0YXI6YmVmb3JlIHtcblx0XHRjb250ZW50OiAnJztcblx0XHRwb3NpdGlvbjogYWJzb2x1dGU7XG5cdFx0d2lkdGg6IDEwMCU7XG5cdFx0aGVpZ2h0OiAxMDAlO1xuXHRcdGJhY2tncm91bmQ6ICNEOEQ4RDg7XG5cdH1cblx0aDM6YWZ0ZXIsIHA6YWZ0ZXIsIGlvbi1hdmF0YXI6YWZ0ZXIge1xuICAgIFx0Y29udGVudDogJyc7XG4gICAgXHRwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgXHR0b3A6IDBweDtcbiAgICBcdHdpZHRoOiAxMDAlO1xuICAgIFx0aGVpZ2h0OiAxMDAlO1xuICAgIFx0YmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KFxuICAgIFx0XHRcdDkwZGVnLCBcbiAgICBcdFx0XHRyZ2JhKDAsIDAsIDAsIDApLCBcbiAgICBcdFx0XHRyZ2JhKDEsIDEsIDEsIDE1JSksIFxuICAgIFx0XHRcdHJnYmEoMCwgMCwgMCwgMClcbiAgICBcdFx0KTtcbiAgICBcdHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtMTAwJSk7XG4gICAgXHRhbmltYXRpb246IGxvYWRpbmcgMS41cyBpbmZpbml0ZTtcblx0fVxufVxuXG5Aa2V5ZnJhbWVzIGxvYWRpbmcge1xuXHQxMDAlIHtcblx0XHR0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMTAwJSlcblx0fVxufSIsIi5zZWFyY2gtaW5kZXgtaXRlbSB7XG4gIHdpZHRoOiAxMDAlO1xuICBwYWRkaW5nLWJvdHRvbTogMTVweDtcbiAgcGFkZGluZy10b3A6IDE1cHg7XG59XG4uc2VhcmNoLWluZGV4LWl0ZW0tcm93IHtcbiAgZGlzcGxheTogZmxleDtcbn1cbi5zZWFyY2gtaW5kZXgtaXRlbS1yb3ctcmVxdWVzdC1pdGVtcyB7XG4gIHBhZGRpbmctdG9wOiAxNnB4O1xufVxuLnNlYXJjaC1pbmRleC1pdGVtLWJ1dHRvbiB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBib3JkZXItcmFkaXVzOiAyMHB4O1xuICBmb250LXNpemU6IDEzcHg7XG4gIHBhZGRpbmc6IDExcHg7XG59XG4uc2VhcmNoLWluZGV4LWl0ZW0tYnV0dG9uLWRlbGV0ZSB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMjA4LCAyLCAyNywgMC4xMik7XG4gIGNvbG9yOiAjYzY2MzYzO1xuICB3aWR0aDogMTAycHg7XG59XG4uc2VhcmNoLWluZGV4LWl0ZW0tYnV0dG9uLXZpZXcge1xuICBiYWNrZ3JvdW5kOiAjOWE0NmJiO1xuICBjb2xvcjogd2hpdGU7XG4gIHdpZHRoOiBjYWxjKDEwMCUgLSAxMDJweCAtIDE2cHgpO1xuICBtYXJnaW4tbGVmdDogMTZweDtcbn1cbi5zZWFyY2gtaW5kZXgtaXRlbS1iYWRnZSB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgYmFja2dyb3VuZDogcmdiYSgxNTQsIDcwLCAxODcsIDAuMTUpO1xuICBjb2xvcjogIzlhNDZiYjtcbiAgcGFkZGluZzogNHB4IDdweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG4gIGZvbnQtdmFyaWFudDogc21hbGwtY2FwcztcbiAgZm9udC1zaXplOiAxMXB4O1xufVxuLnNlYXJjaC1pbmRleC1pdGVtLWltYWdlIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB3aWR0aDogNjRweDtcbn1cbi5zZWFyY2gtaW5kZXgtaXRlbS1jb250ZW50IHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB3aWR0aDogY2FsYygxMDAlIC0gNjRweCAtIDEzcHgpO1xuICBtYXJnaW4tbGVmdDogMTNweDtcbn1cbi5zZWFyY2gtaW5kZXgtaXRlbS1jb250ZW50IGgyIHtcbiAgbWFyZ2luLXRvcDogMHB4O1xuICBtYXJnaW4tYm90dG9tOiA0cHg7XG4gIHBhZGRpbmctdG9wOiA4cHg7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cbi5zZWFyY2gtaW5kZXgtaXRlbS1jb250ZW50IHAge1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBvcGFjaXR5OiAwLjU3O1xufVxuLnNlYXJjaC1pbmRleC1pdGVtLWNvbnRlbnQgcC5zdHJvbmcge1xuICBvcGFjaXR5OiAxO1xufVxuXG4ucGxhY2Vob2xkZXItcmVzdWx0IGgzLCAucGxhY2Vob2xkZXItcmVzdWx0IHAsIC5wbGFjZWhvbGRlci1yZXN1bHQgaW9uLWF2YXRhciB7XG4gIGNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICBiYWNrZ3JvdW5kOiAjRDhEOEQ4ICFpbXBvcnRhbnQ7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cbi5wbGFjZWhvbGRlci1yZXN1bHQgaW9uLWF2YXRhcjpiZWZvcmUge1xuICBjb250ZW50OiBcIlwiO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIGJhY2tncm91bmQ6ICNEOEQ4RDg7XG59XG4ucGxhY2Vob2xkZXItcmVzdWx0IGgzOmFmdGVyLCAucGxhY2Vob2xkZXItcmVzdWx0IHA6YWZ0ZXIsIC5wbGFjZWhvbGRlci1yZXN1bHQgaW9uLWF2YXRhcjphZnRlciB7XG4gIGNvbnRlbnQ6IFwiXCI7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgcmdiYSgwLCAwLCAwLCAwKSwgcmdiYSgxLCAxLCAxLCAwLjE1KSwgcmdiYSgwLCAwLCAwLCAwKSk7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWCgtMTAwJSk7XG4gIGFuaW1hdGlvbjogbG9hZGluZyAxLjVzIGluZmluaXRlO1xufVxuXG5Aa2V5ZnJhbWVzIGxvYWRpbmcge1xuICAxMDAlIHtcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVgoMTAwJSk7XG4gIH1cbn0iXX0= */"

/***/ }),

/***/ "./src/app/search/search.page.ts":
/*!***************************************!*\
  !*** ./src/app/search/search.page.ts ***!
  \***************************************/
/*! exports provided: SearchPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchPage", function() { return SearchPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/toast.service */ "./src/app/services/toast.service.ts");
/* harmony import */ var _services_navigation_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/navigation.service */ "./src/app/services/navigation.service.ts");
/* harmony import */ var _services_query_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/query.service */ "./src/app/services/query.service.ts");
/* harmony import */ var _services_loading_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/loading.service */ "./src/app/services/loading.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");










const { Geolocation } = _capacitor_core__WEBPACK_IMPORTED_MODULE_9__["Plugins"];
const { Modals } = _capacitor_core__WEBPACK_IMPORTED_MODULE_9__["Plugins"];
let SearchPage = class SearchPage {
    constructor(route, router, authentication, toast, nav, query, loading_service, alertController) {
        this.route = route;
        this.router = router;
        this.authentication = authentication;
        this.toast = toast;
        this.nav = nav;
        this.query = query;
        this.loading_service = loading_service;
        this.alertController = alertController;
        this.search_string = "";
        this.connotation = "";
        this.search_object = undefined;
        this.current_page = 0;
        this.page_size = 20;
        this.more_results_exist = false;
        this.search_results = [];
        this.processed_combos = [];
        this.processed_search_combos = [];
        this.search_meta = undefined;
        // NO_SEARCH (empty search), SEARCHED, NO_MATCHES
        this.mode = "SEARCHING";
        this.nearby_searches = [];
        this.skipped_render = false;
        this.image_data = [];
        this.filtered_recommendations_pre = [
            "Ass", "shit", "fuck", "fucker", "faggot", "anal", "vagina", "cunt",
            "pussy", "nigger", "nigga", "queer", "kike", "spic", "wetback",
            "pterolytics", "bitch", "whore", "slut", "penis", "asshole",
            "diarrhea", "vomit", "piss", "puss", "zit", "tits", "boobs", "butt",
            "kinky", "dildo", "scissoring", "blowjob", "handjob", "fingering",
            "rape", "sodomy", "pedophile", "pedophilia", "necrophile", "necrophilia",
            "zoophile", "bestiality", "porn", "pornography", "sex", "fag", "poon",
            "chlamydia", "AIDS", "HIV", "gonorrhea", "syphilis", "genital", "HPV",
            "warts", "herpes", "meth", "methamphetamine", "codeine", "cocaine",
            "heroin", "LSD", "krokodil", "ketamine", "piss", "cocksucker",
            "motherfucker", "anus", "poo", "poop", "pee", "cum", "semen",
            "testicles", "cock", "scrotum", "labia", "feces", "Ku Klux Klan",
            "Al Qaeda", "muhajideen", "jihad", "Nazi", "murder", "killing",
            "prostitute", "prostitution", "stripper", "virgin", "sadism",
            "masochism", "S&M", "ketamine", "weed", "blow", "cocaine",
            "dirty sanchez", "hentai", "tiddies", "titties", "big tiddies",
            "dick", "tentacle porn", "porn"
        ];
        this.filtered_recommendations = null;
    }
    ngOnInit() {
    }
    //'https://api.jsonbin.io/b/5f43d7244d8ce411137fc20f/latest',
    UpdateForbiddenWords() {
        this.query.request('discovery/bad-words', 'GET', {}).subscribe(results => {
            this.filtered_recommendations = this.filtered_recommendations_pre;
            this.filtered_recommendations = this.filtered_recommendations.concat(results['words']);
            //console.log('this.filtered_recommendations', this.filtered_recommendations);
            // this.CreateSearchAndGetResults();
        }, error => {
            this.toast.DisplaySimpleToast("Unable to update forbidden words.");
            // this.CreateSearchAndGetResults();
        });
    }
    DeleteSearch(search_to_delete, phrase_to_delete) {
        this.query.request('discovery/searches/'.concat(search_to_delete), 'DELETE', {}).subscribe(results => {
            this.nav.NavigateRoot('dashboard', {});
        }, error => {
            this.toast.DisplaySimpleToast("Unable to delete search.");
        });
        this.query.request('discovery/bad-words', 'GET', {}).subscribe(results => {
            results['words'].push(phrase_to_delete);
            console.log(results);
            this.query.request('discovery/bad-words', 'POST', {}, {
                "word": [phrase_to_delete]
            }).subscribe(results => {
                console.log('Added Forbidden Word');
            });
        }, error => {
            this.toast.DisplaySimpleToast("Unable to update forbidden words.");
        });
    }
    ngAfterViewInit() {
        this.UpdateForbiddenWords();
        this.search_string = this.route.snapshot.paramMap.get('junk');
        this.connotation = this.nav.stored_params.connotation;
        console.log('this.connotation', this.connotation);
        var mock_event = { "target": { "value": this.search_string } };
        this.PerformSearch(mock_event);
    }
    PerformSearch($event) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            this.MakeSearchCall($event);
        });
    }
    PerformSearchOfPhrase(phrase) {
        this.nav.NavigateForward('search/' + phrase, { "search_string": phrase });
    }
    OpenAdvancedSearch() {
        this.nav.NavigateForward('advanced-search', {});
    }
    MakeSearchCall($event) {
        this.search_string = $event.target.value;
        if (this.search_string)
            this.mode = "SEARCHING";
        this.CreateSearchAndGetResults(this.connotation);
    }
    GetNearbySearches(coordinates) {
        this.nearby_searches = [];
        this.processed_search_combos = [];
        var query_params = {
            "latitude": coordinates['coords']['latitude'],
            "longitude": coordinates['coords']['longitude']
        };
        var deletedWord = [];
        this.query.request('discovery/bad-words', 'GET', {}).subscribe(results => {
            deletedWord = results['words'];
            for (let i = 0; i < deletedWord.length; i++) {
                deletedWord[i] = deletedWord[i].toLowerCase();
            }
            //this.filtered_recommendations = this.filtered_recommendations.concat(results['words']);
            this.query.request('discovery/nearby-searches', 'GET', query_params).subscribe(results => {
                var more_data = results['data'];
                var add_data = [];
                for (let this_item of more_data) {
                    var check_string = this_item['user'] + "-" + this_item['phrase'];
                    if (!this.processed_search_combos.includes(check_string)) {
                        if (deletedWord.indexOf(this_item.phrase.toLowerCase()) === -1) {
                            add_data.push(this_item);
                            this.processed_search_combos.push(check_string);
                        }
                    }
                }
                this.nearby_searches = add_data;
                this.search_meta = results['meta'];
                if (this.mode == "NO_SEARCH") {
                    this.loading_service.DismissLoader();
                }
            }, error => {
                this.toast.DisplaySimpleToast("Unable to perform search.");
            });
        }, error => {
        });
    }
    // GetNearbySearches(coordinates) {
    //     this.nearby_searches = [];
    //     this.processed_search_combos = [];
    //     var query_params = {
    //         "latitude": coordinates['coords']['latitude'],
    //         "longitude": coordinates['coords']['longitude']
    //     };
    //     this.query.request(
    //             'discovery/nearby-searches', 
    //             'GET', 
    //             query_params
    //         ).subscribe(
    //             results => {
    //                 var more_data = results['data'];
    //                 var add_data = [];
    //                 for(let this_item of more_data) {
    //                     var check_string = this_item['user'] + "-" + this_item['phrase'];
    //                     if(!this.processed_search_combos.includes(check_string)) {
    //                         add_data.push(this_item);
    //                         this.processed_search_combos.push(check_string);
    //                     }
    //                 }
    //                 this.nearby_searches = add_data;
    //                 this.search_meta = results['meta'];
    //                 if(this.mode == "NO_SEARCH") {
    //                     this.loading_service.DismissLoader();
    //                 }
    //             },
    //             error => {
    //                 this.toast.DisplaySimpleToast(
    //                         "Unable to perform search."
    //                     );
    //             }
    //         )
    // }
    CreateSearchAndGetResults(connotation) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            // if(this.skipped_render) {
            //     console.log('Skipping Render');
            //     this.loading_service.PresentLoader("Searching...");
            // }
            this.loading_service.PresentLoader("Searching...");
            this.skipped_render = true;
            // Get location.
            console.log('Getting Coordinates...', this.search_string);
            var stored_coordinates = {};
            const coordinates = yield Geolocation.getCurrentPosition()
                .then(response => {
                stored_coordinates = response;
            })
                .catch(error => {
                console.log('Failed To Get Coordinates');
                stored_coordinates = {
                    "coords": {
                        "latitude": 39.043756699999996,
                        "longitude": -77.4874416
                    }
                };
            });
            // Get nearby searches, so we have them just in case.
            this.GetNearbySearches(stored_coordinates);
            // Check if we are actually searching for something.
            if (this.search_string && (this.search_string.length > 100)) {
                this.toast.DisplaySimpleToast("This search is too long.");
                this.search_string = "";
            }
            if (!this.search_string) {
                this.mode = "NO_SEARCH";
                return;
            }
            // Create search object.
            var data = {
                "phrase": this.search_string,
                "connotation": connotation,
                "latitude": stored_coordinates['coords']['latitude'],
                "longitude": stored_coordinates['coords']['longitude']
            };
            this.query.request('discovery/searches', 'POST', {}, data).subscribe(results => {
                this.search_object = results['data'];
                this.ResetSearchMatches();
                this.GetMoreSearchMatches();
            }, error => {
                this.loading_service.DismissLoader();
                this.toast.DisplaySimpleToast("Unable to perform search.");
            });
        });
    }
    ResetSearchMatches() {
        this.current_page = 0;
        this.search_results = [];
        this.processed_combos = [];
    }
    GetMoreSearchMatches() {
        this.current_page = this.current_page + 1;
        this.query.request('discovery/search-matches', 'GET', {
            "search_id": this.search_object.id,
            "page_size": this.page_size,
            "page": this.current_page
        }).subscribe(results => {
            var more_data = results['data'];
            var add_data = [];
            for (let this_item of more_data) {
                var check_string = this_item['user'] + "-" + this_item['phrase'];
                if (!this.processed_combos.includes(check_string)) {
                    add_data.push(this_item);
                    this.processed_combos.push(check_string);
                }
            }
            this.search_meta = results['meta'];
            this.search_results = this.search_results.concat(add_data);
            this.more_results_exist = false;
            if (results['meta']['next'])
                this.more_results_exist = true;
            if (this.search_results.length)
                this.mode = "SEARCHED";
            else
                this.mode = "NO_MATCHES";
            this.loading_service.DismissLoader();
        }, error => {
            this.loading_service.DismissLoader();
            this.toast.DisplaySimpleToast("Unable to retrieve matches.");
        });
    }
    GoToUser(user_id) {
        if (this.mode != 'SEARCHED')
            return;
        this.nav.NavigateForward('user/' + user_id, {
            "search_object": this.search_object,
            "user_id": user_id
        });
    }
};
SearchPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _services_authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"] },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_4__["ToastService"] },
    { type: _services_navigation_service__WEBPACK_IMPORTED_MODULE_5__["NavigationService"] },
    { type: _services_query_service__WEBPACK_IMPORTED_MODULE_6__["QueryService"] },
    { type: _services_loading_service__WEBPACK_IMPORTED_MODULE_7__["LoadingService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["AlertController"] }
];
SearchPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-search',
        template: __webpack_require__(/*! raw-loader!./search.page.html */ "./node_modules/raw-loader/index.js!./src/app/search/search.page.html"),
        styles: [__webpack_require__(/*! ./search.page.scss */ "./src/app/search/search.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _services_authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"],
        _services_toast_service__WEBPACK_IMPORTED_MODULE_4__["ToastService"],
        _services_navigation_service__WEBPACK_IMPORTED_MODULE_5__["NavigationService"],
        _services_query_service__WEBPACK_IMPORTED_MODULE_6__["QueryService"],
        _services_loading_service__WEBPACK_IMPORTED_MODULE_7__["LoadingService"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_8__["AlertController"]])
], SearchPage);



/***/ }),

/***/ "./src/app/services/toast.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/toast.service.ts ***!
  \*******************************************/
/*! exports provided: ToastService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToastService", function() { return ToastService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



let ToastService = class ToastService {
    constructor(toast_controller) {
        this.toast_controller = toast_controller;
    }
    DisplaySimpleToast(message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const toast = yield this.toast_controller.create({
                "message": message, "duration": 2000
            });
            toast.present();
        });
    }
};
ToastService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
], ToastService);



/***/ })

}]);
//# sourceMappingURL=search-search-module-es2015.js.map