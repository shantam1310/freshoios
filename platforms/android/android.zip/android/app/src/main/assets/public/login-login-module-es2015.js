(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/login/login.page.html":
/*!*****************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/login/login.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n    <div class=\"auth-background\">\n        <div class=\"flag-image\">\n            <img src=\"/assets/whoyou-logo.png\" alt=\"\" style=\"max-height: 92px\" />\n            <h2 style=\"font-size: 19px; color: white;\">whoyou</h2>\n        </div>\n        <div class=\"auth-form put-padding\" style=\"position: relative; z-index: 10; padding-bottom: 0px;\">\n            <div class=\"form-control-holder\">\n                <input type=\"text\" [(ngModel)]=\"form.username\" placeholder=\"email address\" autocomplete=\"off\" />\n            </div>\n            <div class=\"form-control-holder\">\n                <input type=\"password\" [(ngModel)]=\"form.password\" placeholder=\"password\" autocomplete=\"off\" />\n            </div>\n            <div expand=\"block\" class=\"home-button home-primary\" size=\"large\" class=\"whoyou-round-button button-white\" (click)=\"Submit();\">\n                <span>Sign in</span>\n            </div>\n            <div expand=\"block\" color=\"light\" class=\"home-button\" size=\"large\" class=\"whoyou-round-button button-empty\" (click)=\"RunForgotPassword();\">\n                <span>Forgot Password?</span>\n            </div>\n        </div>\n\n        <div class=\"fix-z center-contents put-padding\" style=\"padding-bottom: 0px;\">\n            <div expand=\"block\" size=\"large\" class=\"whoyou-round-button button-white-border\" [routerLink]=\"'/signup'\" routerDirection=\"forward\" style=\"width: 100%;\">\n                <span>Sign Up for an Account</span>\n            </div>\n            <div class=\"art-line\"></div>\n            <div class=\"agreements\">\n                <a href=\"https://bluezephyrapps-hosted-app-pages.s3.amazonaws.com/whoyou/eula.html\" target=\"_blank\">EULA</a> | <a href=\"https://bluezephyrapps-hosted-app-pages.s3.amazonaws.com/whoyou/privacy_policy.html\" target=\"_blank\">Privacy Policy</a>\n            </div>\n        </div>\n    </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/login/login.module.ts":
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");







const routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]
    }
];
let LoginPageModule = class LoginPageModule {
};
LoginPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
    })
], LoginPageModule);



/***/ }),

/***/ "./src/app/login/login.page.scss":
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2xvZ2luL2xvZ2luLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/login/login.page.ts":
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/toast.service */ "./src/app/services/toast.service.ts");
/* harmony import */ var _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/navigation.service */ "./src/app/services/navigation.service.ts");
/* harmony import */ var _services_query_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/query.service */ "./src/app/services/query.service.ts");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");







const { Modals } = _capacitor_core__WEBPACK_IMPORTED_MODULE_6__["Plugins"];
let LoginPage = class LoginPage {
    constructor(authentication, toast, nav, query) {
        this.authentication = authentication;
        this.toast = toast;
        this.nav = nav;
        this.query = query;
        this.form = {};
    }
    ngOnInit() {
    }
    RunForgotPassword() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            let prompt_response = yield Modals.prompt({
                title: 'Reset Password',
                message: 'Enter the email you are having issues with.'
            });
            var message_content = "";
            if (prompt_response['cancelled'])
                return; // User cancelled the send.
            if (!prompt_response['cancelled'] && prompt_response['value']) {
                message_content = prompt_response['value'];
                console.log('message_content', message_content);
            }
            this.query.request('users/actions/password_reset', 'POST', { "email": message_content }, { "email": message_content }).subscribe(results => {
                this.toast.DisplaySimpleToast("Please check your email for your new password.");
            }, error => {
                this.toast.DisplaySimpleToast("Unable to reset password.");
            });
        });
    }
    Submit() {
        this.authentication.AuthorizeAndGetUser(this.form.username, this.form.password).subscribe(user => {
            var user_data = user['data'];
            this.authentication.SetUser(user_data);
            //this.push_service.RegisterPushNotifications();
            this.nav.NavigateRoot('dashboard', {});
        }, error => {
            this.toast.DisplaySimpleToast("Unable to log in with given credentials.");
        });
    }
};
LoginPage.ctorParameters = () => [
    { type: _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"] },
    { type: _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"] },
    { type: _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"] }
];
LoginPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-login',
        template: __webpack_require__(/*! raw-loader!./login.page.html */ "./node_modules/raw-loader/index.js!./src/app/login/login.page.html"),
        styles: [__webpack_require__(/*! ./login.page.scss */ "./src/app/login/login.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"],
        _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"],
        _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"],
        _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"]])
], LoginPage);



/***/ }),

/***/ "./src/app/services/toast.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/toast.service.ts ***!
  \*******************************************/
/*! exports provided: ToastService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToastService", function() { return ToastService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



let ToastService = class ToastService {
    constructor(toast_controller) {
        this.toast_controller = toast_controller;
    }
    DisplaySimpleToast(message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const toast = yield this.toast_controller.create({
                "message": message, "duration": 2000
            });
            toast.present();
        });
    }
};
ToastService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
], ToastService);



/***/ })

}]);
//# sourceMappingURL=login-login-module-es2015.js.map