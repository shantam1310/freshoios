(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/login/login.page.html":
/*!*****************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/login/login.page.html ***!
  \*****************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n    <div class=\"auth-background\">\n        <div class=\"flag-image\">\n            <img src=\"/assets/whoyou-logo.png\" alt=\"\" style=\"max-height: 92px\" />\n            <h2 style=\"font-size: 19px; color: white;\">whoyou</h2>\n        </div>\n        <div class=\"auth-form put-padding\" style=\"position: relative; z-index: 10; padding-bottom: 0px;\">\n            <div class=\"form-control-holder\">\n                <input type=\"text\" [(ngModel)]=\"form.username\" placeholder=\"email address\" autocomplete=\"off\" />\n            </div>\n            <div class=\"form-control-holder\">\n                <input type=\"password\" [(ngModel)]=\"form.password\" placeholder=\"password\" autocomplete=\"off\" />\n            </div>\n            <div expand=\"block\" class=\"home-button home-primary\" size=\"large\" class=\"whoyou-round-button button-white\" (click)=\"Submit();\">\n                <span>Sign in</span>\n            </div>\n            <div expand=\"block\" color=\"light\" class=\"home-button\" size=\"large\" class=\"whoyou-round-button button-empty\" (click)=\"RunForgotPassword();\">\n                <span>Forgot Password?</span>\n            </div>\n        </div>\n\n        <div class=\"fix-z center-contents put-padding\" style=\"padding-bottom: 0px;\">\n            <div expand=\"block\" size=\"large\" class=\"whoyou-round-button button-white-border\" [routerLink]=\"'/signup'\" routerDirection=\"forward\" style=\"width: 100%;\">\n                <span>Sign Up for an Account</span>\n            </div>\n            <div class=\"art-line\"></div>\n            <div class=\"agreements\">\n                <a href=\"https://bluezephyrapps-hosted-app-pages.s3.amazonaws.com/whoyou/eula.html\" target=\"_blank\">EULA</a> | <a href=\"https://bluezephyrapps-hosted-app-pages.s3.amazonaws.com/whoyou/privacy_policy.html\" target=\"_blank\">Privacy Policy</a>\n            </div>\n        </div>\n    </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/login/login.module.ts":
/*!***************************************!*\
  !*** ./src/app/login/login.module.ts ***!
  \***************************************/
/*! exports provided: LoginPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPageModule", function() { return LoginPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./login.page */ "./src/app/login/login.page.ts");







var routes = [
    {
        path: '',
        component: _login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]
    }
];
var LoginPageModule = /** @class */ (function () {
    function LoginPageModule() {
    }
    LoginPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
        })
    ], LoginPageModule);
    return LoginPageModule;
}());



/***/ }),

/***/ "./src/app/login/login.page.scss":
/*!***************************************!*\
  !*** ./src/app/login/login.page.scss ***!
  \***************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2xvZ2luL2xvZ2luLnBhZ2Uuc2NzcyJ9 */"

/***/ }),

/***/ "./src/app/login/login.page.ts":
/*!*************************************!*\
  !*** ./src/app/login/login.page.ts ***!
  \*************************************/
/*! exports provided: LoginPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LoginPage", function() { return LoginPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/toast.service */ "./src/app/services/toast.service.ts");
/* harmony import */ var _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/navigation.service */ "./src/app/services/navigation.service.ts");
/* harmony import */ var _services_query_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/query.service */ "./src/app/services/query.service.ts");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");







var Modals = _capacitor_core__WEBPACK_IMPORTED_MODULE_6__["Plugins"].Modals;
var LoginPage = /** @class */ (function () {
    function LoginPage(authentication, toast, nav, query) {
        this.authentication = authentication;
        this.toast = toast;
        this.nav = nav;
        this.query = query;
        this.form = {};
    }
    LoginPage.prototype.ngOnInit = function () {
    };
    LoginPage.prototype.RunForgotPassword = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var prompt_response, message_content;
            var _this = this;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, Modals.prompt({
                            title: 'Reset Password',
                            message: 'Enter the email you are having issues with.'
                        })];
                    case 1:
                        prompt_response = _a.sent();
                        message_content = "";
                        if (prompt_response['cancelled'])
                            return [2 /*return*/]; // User cancelled the send.
                        if (!prompt_response['cancelled'] && prompt_response['value']) {
                            message_content = prompt_response['value'];
                            console.log('message_content', message_content);
                        }
                        this.query.request('users/actions/password_reset', 'POST', { "email": message_content }, { "email": message_content }).subscribe(function (results) {
                            _this.toast.DisplaySimpleToast("Please check your email for your new password.");
                        }, function (error) {
                            _this.toast.DisplaySimpleToast("Unable to reset password.");
                        });
                        return [2 /*return*/];
                }
            });
        });
    };
    LoginPage.prototype.Submit = function () {
        var _this = this;
        this.authentication.AuthorizeAndGetUser(this.form.username, this.form.password).subscribe(function (user) {
            var user_data = user['data'];
            _this.authentication.SetUser(user_data);
            //this.push_service.RegisterPushNotifications();
            _this.nav.NavigateRoot('dashboard', {});
        }, function (error) {
            _this.toast.DisplaySimpleToast("Unable to log in with given credentials.");
        });
    };
    LoginPage.ctorParameters = function () { return [
        { type: _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] },
        { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"] },
        { type: _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"] },
        { type: _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"] }
    ]; };
    LoginPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-login',
            template: __webpack_require__(/*! raw-loader!./login.page.html */ "./node_modules/raw-loader/index.js!./src/app/login/login.page.html"),
            styles: [__webpack_require__(/*! ./login.page.scss */ "./src/app/login/login.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"],
            _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"],
            _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"],
            _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"]])
    ], LoginPage);
    return LoginPage;
}());



/***/ }),

/***/ "./src/app/services/toast.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/toast.service.ts ***!
  \*******************************************/
/*! exports provided: ToastService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToastService", function() { return ToastService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var ToastService = /** @class */ (function () {
    function ToastService(toast_controller) {
        this.toast_controller = toast_controller;
    }
    ToastService.prototype.DisplaySimpleToast = function (message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toast_controller.create({
                            "message": message, "duration": 2000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    ToastService.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
    ]; };
    ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
    ], ToastService);
    return ToastService;
}());



/***/ })

}]);
//# sourceMappingURL=login-login-module-es5.js.map