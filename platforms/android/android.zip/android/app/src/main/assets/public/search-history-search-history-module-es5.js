(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["search-history-search-history-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/search-history/search-history.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/search-history/search-history.page.html ***!
  \***********************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content class=\"search-history\">\n    <div class=\"common-header-spacer\"></div>\n    <div class=\"common-header\">\n        <div class=\"common-header-icon\">\n            <ion-icon name=\"md-arrow-back\" slot=\"end\" (click)=\"nav.PopView();\"> \n            </ion-icon>\n        </div>\n        <div class=\"common-header-title\">\n            Search History\n        </div>\n        <div class=\"common-header-icon\">\n            <!-- <ion-icon name=\"md-more\" slot=\"end\" (click)=\"DisplayActions();\"> \n            </ion-icon> -->\n        </div>\n    </div>\n\n    <div class=\"search-history-container\">\n        <h3 class=\"generic-h3\">\n            Your search history is publicly visible on your profile.\n        </h3>\n        <p class=\"notice-paragraph\" style=\"color: black;\">\n            If you delete one of your searches, others will no longer be able to send you message requests based on that search.\n        </p>\n\n        <div class=\"search-history-list\">\n            <ng-container *ngFor=\"let this_result of past_searches\">\n                <div class=\"search-history-list-item\">\n                    <div class=\"search-history-list-item-group\">\n                        <div class=\"search-history-list-item-phrase\">\n                            {{this_result.phrase}}\n                        </div>\n                        <div class=\"search-history-list-item-date\">\n                            {{this_result.created_at|date:'short'}}\n                        </div>\n                    </div>\n\n                    <div class=\"search-history-list-item-icon\">\n                        <ion-icon name=\"ios-close-circle\" slot=\"end\"\n                                  (click)=\"DeleteSearch(this_result);\"></ion-icon>\n                    </div>\n                </div>\n            </ng-container>\n        </div>\n    </div>\n</ion-content>\n"

/***/ }),

/***/ "./src/app/search-history/search-history.module.ts":
/*!*********************************************************!*\
  !*** ./src/app/search-history/search-history.module.ts ***!
  \*********************************************************/
/*! exports provided: SearchHistoryPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchHistoryPageModule", function() { return SearchHistoryPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _search_history_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./search-history.page */ "./src/app/search-history/search-history.page.ts");







var routes = [
    {
        path: '',
        component: _search_history_page__WEBPACK_IMPORTED_MODULE_6__["SearchHistoryPage"]
    }
];
var SearchHistoryPageModule = /** @class */ (function () {
    function SearchHistoryPageModule() {
    }
    SearchHistoryPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_search_history_page__WEBPACK_IMPORTED_MODULE_6__["SearchHistoryPage"]]
        })
    ], SearchHistoryPageModule);
    return SearchHistoryPageModule;
}());



/***/ }),

/***/ "./src/app/search-history/search-history.page.scss":
/*!*********************************************************!*\
  !*** ./src/app/search-history/search-history.page.scss ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".search-history-container {\n  padding: 24px;\n}\n.search-history-list-item {\n  padding: 19px 0px;\n  border-top: solid 1px #979797;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n          align-items: center;\n}\n.search-history-list-item-group {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: justify;\n          justify-content: space-between;\n  -webkit-box-align: center;\n          align-items: center;\n}\n.search-history-list-item-phrase {\n  font-size: 16px;\n  color: #9a46bb;\n  font-weight: bold;\n}\n.search-history-list-item-date {\n  font-size: 16px;\n  color: #9b9b9b;\n  margin-left: 8px;\n}\n.search-history-list-item-icon ion-icon {\n  color: #BB4646;\n  font-size: 22px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zaGFudGFtc2hhcm1hL0Rvd25sb2Fkcy93aG95b3Uvc3JjL2FwcC9zZWFyY2gtaGlzdG9yeS9zZWFyY2gtaGlzdG9yeS5wYWdlLnNjc3MiLCJzcmMvYXBwL3NlYXJjaC1oaXN0b3J5L3NlYXJjaC1oaXN0b3J5LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFFQztFQUNDLGFBQUE7QUNERjtBREtFO0VBQ0MsaUJBQUE7RUFDQSw2QkFBQTtFQUVBLG9CQUFBO0VBQUEsYUFBQTtFQUNBLHlCQUFBO1VBQUEsOEJBQUE7RUFDQSx5QkFBQTtVQUFBLG1CQUFBO0FDSkg7QURNRztFQUNDLG9CQUFBO0VBQUEsYUFBQTtFQUNBLHlCQUFBO1VBQUEsOEJBQUE7RUFDQSx5QkFBQTtVQUFBLG1CQUFBO0FDSko7QURPRztFQUNDLGVBQUE7RUFDQSxjQUFBO0VBQ0EsaUJBQUE7QUNMSjtBRFFHO0VBQ0MsZUFBQTtFQUNBLGNBQUE7RUFDQSxnQkFBQTtBQ05KO0FEVUk7RUFDQyxjQUFBO0VBQ0EsZUFBQTtBQ1JMIiwiZmlsZSI6InNyYy9hcHAvc2VhcmNoLWhpc3Rvcnkvc2VhcmNoLWhpc3RvcnkucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiXG4uc2VhcmNoLWhpc3Rvcnkge1xuXHQmLWNvbnRhaW5lciB7XG5cdFx0cGFkZGluZzogMjRweDtcblx0fVxuXG5cdCYtbGlzdCB7XG5cdFx0Ji1pdGVtIHtcblx0XHRcdHBhZGRpbmc6IDE5cHggMHB4O1xuXHRcdFx0Ym9yZGVyLXRvcDogc29saWQgMXB4IHJnYigxNTEsIDE1MSwgMTUxKTtcblxuXHRcdFx0ZGlzcGxheTogZmxleDtcblx0XHRcdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2Vlbjtcblx0XHRcdGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cblx0XHRcdCYtZ3JvdXAge1xuXHRcdFx0XHRkaXNwbGF5OiBmbGV4O1xuXHRcdFx0XHRqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG5cdFx0XHRcdGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cdFx0XHR9XG5cblx0XHRcdCYtcGhyYXNlIHtcblx0XHRcdFx0Zm9udC1zaXplOiAxNnB4O1xuXHRcdFx0XHRjb2xvcjogcmdiKDE1NCwgNzAsIDE4Nyk7XG5cdFx0XHRcdGZvbnQtd2VpZ2h0OiBib2xkO1xuXHRcdFx0fVxuXG5cdFx0XHQmLWRhdGUge1xuXHRcdFx0XHRmb250LXNpemU6IDE2cHg7XG5cdFx0XHRcdGNvbG9yOiByZ2IoMTU1LCAxNTUsIDE1NSk7XG5cdFx0XHRcdG1hcmdpbi1sZWZ0OiA4cHg7XG5cdFx0XHR9XG5cblx0XHRcdCYtaWNvbiB7XG5cdFx0XHRcdGlvbi1pY29uIHtcblx0XHRcdFx0XHRjb2xvcjogI0JCNDY0Njtcblx0XHRcdFx0XHRmb250LXNpemU6IDIycHg7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH1cbn0iLCIuc2VhcmNoLWhpc3RvcnktY29udGFpbmVyIHtcbiAgcGFkZGluZzogMjRweDtcbn1cbi5zZWFyY2gtaGlzdG9yeS1saXN0LWl0ZW0ge1xuICBwYWRkaW5nOiAxOXB4IDBweDtcbiAgYm9yZGVyLXRvcDogc29saWQgMXB4ICM5Nzk3OTc7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbi5zZWFyY2gtaGlzdG9yeS1saXN0LWl0ZW0tZ3JvdXAge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG59XG4uc2VhcmNoLWhpc3RvcnktbGlzdC1pdGVtLXBocmFzZSB7XG4gIGZvbnQtc2l6ZTogMTZweDtcbiAgY29sb3I6ICM5YTQ2YmI7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuLnNlYXJjaC1oaXN0b3J5LWxpc3QtaXRlbS1kYXRlIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBjb2xvcjogIzliOWI5YjtcbiAgbWFyZ2luLWxlZnQ6IDhweDtcbn1cbi5zZWFyY2gtaGlzdG9yeS1saXN0LWl0ZW0taWNvbiBpb24taWNvbiB7XG4gIGNvbG9yOiAjQkI0NjQ2O1xuICBmb250LXNpemU6IDIycHg7XG59Il19 */"

/***/ }),

/***/ "./src/app/search-history/search-history.page.ts":
/*!*******************************************************!*\
  !*** ./src/app/search-history/search-history.page.ts ***!
  \*******************************************************/
/*! exports provided: SearchHistoryPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SearchHistoryPage", function() { return SearchHistoryPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/toast.service */ "./src/app/services/toast.service.ts");
/* harmony import */ var _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/navigation.service */ "./src/app/services/navigation.service.ts");
/* harmony import */ var _services_query_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/query.service */ "./src/app/services/query.service.ts");






var SearchHistoryPage = /** @class */ (function () {
    function SearchHistoryPage(authentication, toast, nav, query) {
        this.authentication = authentication;
        this.toast = toast;
        this.nav = nav;
        this.query = query;
        this.past_searches = [];
        this.LoadSearchHistory();
    }
    SearchHistoryPage.prototype.ngOnInit = function () {
    };
    SearchHistoryPage.prototype.LoadSearchHistory = function () {
        var _this = this;
        this.query.request('discovery/searches', 'GET', {
            user: this.authentication.user['id'],
            page_size: 10000
        }).subscribe(function (searches) {
            _this.past_searches = searches['data'];
        }, function (error) {
            _this.toast.DisplaySimpleToast("Unable to load search history.");
        });
    };
    SearchHistoryPage.prototype.DeleteSearch = function (search) {
        var _this = this;
        this.query.request('discovery/searches/'.concat(search['id']), 'DELETE', {}).subscribe(function (result) {
            _this.LoadSearchHistory();
        }, function (error) {
            _this.toast.DisplaySimpleToast("Unable to delete search history.");
        });
    };
    SearchHistoryPage.ctorParameters = function () { return [
        { type: _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] },
        { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"] },
        { type: _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"] },
        { type: _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"] }
    ]; };
    SearchHistoryPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-search-history',
            template: __webpack_require__(/*! raw-loader!./search-history.page.html */ "./node_modules/raw-loader/index.js!./src/app/search-history/search-history.page.html"),
            styles: [__webpack_require__(/*! ./search-history.page.scss */ "./src/app/search-history/search-history.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"],
            _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"],
            _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"],
            _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"]])
    ], SearchHistoryPage);
    return SearchHistoryPage;
}());



/***/ }),

/***/ "./src/app/services/toast.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/toast.service.ts ***!
  \*******************************************/
/*! exports provided: ToastService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToastService", function() { return ToastService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var ToastService = /** @class */ (function () {
    function ToastService(toast_controller) {
        this.toast_controller = toast_controller;
    }
    ToastService.prototype.DisplaySimpleToast = function (message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toast_controller.create({
                            "message": message, "duration": 2000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    ToastService.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
    ]; };
    ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
    ], ToastService);
    return ToastService;
}());



/***/ })

}]);
//# sourceMappingURL=search-history-search-history-module-es5.js.map