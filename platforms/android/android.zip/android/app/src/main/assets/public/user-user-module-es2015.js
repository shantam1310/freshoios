(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["user-user-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/user/user.page.html":
/*!***************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/user/user.page.html ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content class=\"profile-page\">\n    <div class=\"common-header is-transparent\">\n        <div class=\"common-header-icon\">\n            <ion-icon name=\"md-arrow-back\" slot=\"end\" (click)=\"nav.PopView();\"> \n            </ion-icon>\n        </div>\n        <div class=\"common-header-title\">\n            <!-- Empty -->\n        </div>\n        <div class=\"common-header-icon\">\n            <!-- Empty -->\n        </div>\n    </div>\n\n    <ng-container  *ngIf=\"user_object\">\n        <div class=\"profile-page-slider\">\n            <div class=\"profile-page-slider-item {{ image_data.length <=1 ? 'is-only-item' : '' }}\"\n                 *ngFor=\"let this_image of image_data\"\n                 (click)=\"ShowPhoto(this_image.media_url);\">\n                <img class=\"profile-page-slider-item-image\"\n                     [src]=\"this_image.media_url\" />\n            </div>\n        </div>\n\n        <div class=\"profile-page-header\">\n            <div class=\"profile-page-header-image\">\n                <img class=\"profile-page-header-image-element\" \n                     [src]=\"user_object.profile_photo || authentication.default_avatar\" />\n            </div>\n            <div class=\"profile-page-header-name\">\n                {{ user_object.company_name }}\n            </div>\n            <div class=\"profile-page-header-settings\">\n                <ion-icon name=\"md-settings\" class=\"profile-page-header-settings-icon\"\n                          style=\"visibility: hidden;\"></ion-icon>\n            </div>\n        </div>\n\n        <div class=\"profile-page-big-button\" *ngIf=\"!hide_aux_info\" (click)=\"StartMessage();\">\n            <ion-icon name=\"md-chatbubbles\"></ion-icon>\n            Say Hello\n        </div>\n\n        <div class=\"profile-page-section\">\n            <div class=\"profile-page-section-title\">\n                About Me\n            </div>\n            <div class=\"profile-page-section-paragraph\">\n                {{ user_object.settings.biography || 'This user prefers to maintain a sense of mystery about them.' }}\n            </div>\n        </div>\n\n        <div class=\"profile-page-section\" *ngIf=\"user_object && (user_object.settings.hide_past_searches != 'true')\">\n            <div class=\"profile-page-section-title\">\n                {{ user_object.company_name }}'s Recent Searches\n            </div>\n            <div class=\"profile-page-section-searches\">\n                <div class=\"profile-page-section-searches-item\" \n                     *ngFor=\"let this_result of past_searches\"\n                     (click)=\"PerformSearchOfPhrase(this_result.phrase);\">\n                    <div class=\"profile-page-section-searches-item-phrase\">\n                        {{this_result.connotation}} {{this_result.phrase}}\n                    </div>\n                </div>\n            </div>\n        </div>\n\n        <div class=\"profile-page-big-button\" (click)=\"BlockUser();\">\n            <ion-icon name=\"md-nuclear\"></ion-icon>\n            Flag User\n        </div>\n\n        <div class=\"profile-page-big-button\" (click)=\"DeleteUser();\"\n            *ngIf=\"authentication.user && authentication.user['email'].includes('@whoyouapp.com')\">\n            <ion-icon name=\"md-trash\"></ion-icon>\n            Delete User\n        </div>\n\n    </ng-container>\n</ion-content>\n\n<ion-footer>\n    <ion-toolbar>\n        <ion-tabs>\n            <ion-tab-bar slot=\"bottom\">\n                <ion-tab-button [routerLink]=\"'/profile'\" routerDirection=\"root\">\n                    <ion-icon name=\"md-person\"></ion-icon>\n                </ion-tab-button>\n                <ion-tab-button [routerLink]=\"'/dashboard'\" routerDirection=\"root\">\n                    <ion-icon name=\"md-search\"></ion-icon>\n                </ion-tab-button>\n                <ion-tab-button [routerLink]=\"'/messages'\" routerDirection=\"root\">\n                    <ion-icon name=\"md-chatbubbles\"></ion-icon>\n                </ion-tab-button>\n            </ion-tab-bar>\n        </ion-tabs>\n    </ion-toolbar>\n</ion-footer>\n"

/***/ }),

/***/ "./src/app/services/toast.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/toast.service.ts ***!
  \*******************************************/
/*! exports provided: ToastService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToastService", function() { return ToastService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



let ToastService = class ToastService {
    constructor(toast_controller) {
        this.toast_controller = toast_controller;
    }
    DisplaySimpleToast(message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const toast = yield this.toast_controller.create({
                "message": message, "duration": 2000
            });
            toast.present();
        });
    }
};
ToastService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
];
ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
], ToastService);



/***/ }),

/***/ "./src/app/user/user.module.ts":
/*!*************************************!*\
  !*** ./src/app/user/user.module.ts ***!
  \*************************************/
/*! exports provided: UserPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserPageModule", function() { return UserPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _user_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./user.page */ "./src/app/user/user.page.ts");







const routes = [
    {
        path: '',
        component: _user_page__WEBPACK_IMPORTED_MODULE_6__["UserPage"]
    }
];
let UserPageModule = class UserPageModule {
};
UserPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_user_page__WEBPACK_IMPORTED_MODULE_6__["UserPage"]]
    })
], UserPageModule);



/***/ }),

/***/ "./src/app/user/user.page.scss":
/*!*************************************!*\
  !*** ./src/app/user/user.page.scss ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".profile-page-edit {\n  color: #9a46bb;\n  font-size: 19px;\n  margin-left: 8px;\n}\n.profile-page-slider {\n  display: -webkit-box;\n  display: flex;\n  flex-wrap: nowrap;\n  overflow-x: scroll;\n}\n.profile-page-slider-item {\n  -webkit-box-flex: 0;\n          flex: 0 0 auto;\n  height: 189px;\n  margin-right: 4px;\n}\n.profile-page-slider-item.is-only-item {\n  width: 100vw;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-align: center;\n          align-items: center;\n}\n.profile-page-slider-item.is-only-item img {\n  width: 100%;\n  height: auto;\n}\n.profile-page-slider-item.is-add-slider-item {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  min-width: 50vw;\n  background: #A740C2;\n}\n.profile-page-slider-item.is-add-slider-item ion-icon {\n  margin-top: calc((189px - 40px) / 2);\n  font-size: 40px;\n  color: white;\n}\n.profile-page-slider-item-image {\n  height: 100%;\n  width: auto;\n}\n.profile-page-header {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: justify;\n          justify-content: space-between;\n  padding: 20px 24px;\n}\n.profile-page-header-image {\n  display: -webkit-box;\n  display: flex;\n  position: relative;\n  margin-top: -36px;\n  width: 88px;\n  height: 88px;\n  border-radius: 50%;\n  overflow: hidden;\n  border: 4px solid white;\n}\n.profile-page-header-image-image-element {\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n.profile-page-header-name {\n  font-size: 22px;\n  font-weight: bold;\n}\n.profile-page-header-settings-icon {\n  font-size: 24px;\n  color: #9a46bb;\n}\n.profile-page-section {\n  padding: 20px 24px;\n  padding-top: 0px;\n}\n.profile-page-section-title {\n  font-size: 16px;\n  font-weight: bold;\n  text-transform: uppercase;\n  margin-bottom: 16px;\n}\n.profile-page-section-paragraph {\n  font-size: 16px;\n  line-height: 24px;\n}\n.profile-page-section-searches-item {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n          flex-direction: row;\n  -webkit-box-pack: justify;\n          justify-content: space-between;\n  padding: 12px 24px;\n  background: rgba(154, 70, 187, 0.1);\n  border-radius: 21px;\n  margin-bottom: 8px;\n}\n.profile-page-section-searches-item-phrase {\n  font-size: 14px;\n}\n.profile-page-big-button {\n  margin: 20px 26px;\n  margin-top: 0px;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  padding: 14px;\n  border-radius: 7px;\n  background: #9a46bb;\n  color: white;\n  font-size: 20px;\n  font-weight: bold;\n}\n.profile-page-big-button ion-icon {\n  margin-right: 12px;\n}\n.profile-image-holder {\n  background: #A740C2;\n  height: 70px;\n  width: 70px;\n  text-align: center;\n  overflow: hidden;\n}\n.profile-image-holder ion-icon {\n  margin-top: 12px;\n  font-size: 32px;\n  color: #FFFFFF !important;\n}\n.profile-image-holder.featured-image {\n  border: #FFD700 solid 4px;\n  border-radius: 4px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zaGFudGFtc2hhcm1hL0Rvd25sb2Fkcy93aG95b3Uvc3JjL2FwcC91c2VyL3VzZXIucGFnZS5zY3NzIiwic3JjL2FwcC91c2VyL3VzZXIucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNDO0VBQ0MsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ0FGO0FER0M7RUFDQyxvQkFBQTtFQUFBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FDREY7QURHRTtFQUNDLG1CQUFBO1VBQUEsY0FBQTtFQUVBLGFBQUE7RUFDQSxpQkFBQTtBQ0ZIO0FESUc7RUFDQyxZQUFBO0VBQ0Esb0JBQUE7RUFBQSxhQUFBO0VBQ0EseUJBQUE7VUFBQSxtQkFBQTtBQ0ZKO0FESUk7RUFDQyxXQUFBO0VBQ0EsWUFBQTtBQ0ZMO0FETUc7RUFDQyxvQkFBQTtFQUFBLGFBQUE7RUFDQSx3QkFBQTtVQUFBLHVCQUFBO0VBRUEsZUFBQTtFQUNBLG1CQUFBO0FDTEo7QURPSTtFQUNDLG9DQUFBO0VBQ0EsZUFBQTtFQUNBLFlBQUE7QUNMTDtBRFNHO0VBQ0MsWUFBQTtFQUNBLFdBQUE7QUNQSjtBRFlDO0VBQ0Msb0JBQUE7RUFBQSxhQUFBO0VBQ0EseUJBQUE7VUFBQSw4QkFBQTtFQUVBLGtCQUFBO0FDWEY7QURhRTtFQUNDLG9CQUFBO0VBQUEsYUFBQTtFQUVBLGtCQUFBO0VBRUEsaUJBQUE7RUFFQSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSx1QkFBQTtBQ2RIO0FEZ0JHO0VBQ0Msb0JBQUE7S0FBQSxpQkFBQTtBQ2RKO0FEa0JFO0VBQ0MsZUFBQTtFQUNBLGlCQUFBO0FDaEJIO0FEb0JHO0VBQ0MsZUFBQTtFQUNBLGNBQUE7QUNsQko7QUR1QkM7RUFDQyxrQkFBQTtFQUNBLGdCQUFBO0FDckJGO0FEdUJFO0VBQ0MsZUFBQTtFQUNBLGlCQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBQ3JCSDtBRHdCRTtFQUNDLGVBQUE7RUFDQSxpQkFBQTtBQ3RCSDtBRDBCRztFQUNDLG9CQUFBO0VBQUEsYUFBQTtFQUNBLDhCQUFBO0VBQUEsNkJBQUE7VUFBQSxtQkFBQTtFQUNBLHlCQUFBO1VBQUEsOEJBQUE7RUFFQSxrQkFBQTtFQUNBLG1DQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBQ3pCSjtBRDJCSTtFQUNDLGVBQUE7QUN6Qkw7QUQrQkM7RUFDQyxpQkFBQTtFQUNBLGVBQUE7RUFFQSxvQkFBQTtFQUFBLGFBQUE7RUFDQSx3QkFBQTtVQUFBLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLGtCQUFBO0VBRUEsbUJBQUE7RUFDQSxZQUFBO0VBQ0EsZUFBQTtFQUNBLGlCQUFBO0FDL0JGO0FEaUNFO0VBQ0Msa0JBQUE7QUMvQkg7QURvQ0E7RUFDQyxtQkFBQTtFQUNBLFlBQUE7RUFDQSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBQ2pDRDtBRGtDQztFQUNDLGdCQUFBO0VBQ0EsZUFBQTtFQUNBLHlCQUFBO0FDaENGO0FEa0NDO0VBQ0MseUJBQUE7RUFDQSxrQkFBQTtBQ2hDRiIsImZpbGUiOiJzcmMvYXBwL3VzZXIvdXNlci5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIucHJvZmlsZS1wYWdlIHtcblx0Ji1lZGl0IHtcblx0XHRjb2xvcjogcmdiKDE1NCwgNzAsIDE4Nyk7XG5cdFx0Zm9udC1zaXplOiAxOXB4O1xuXHRcdG1hcmdpbi1sZWZ0OiA4cHg7XG5cdH1cblxuXHQmLXNsaWRlciB7XG5cdFx0ZGlzcGxheTogZmxleDtcblx0XHRmbGV4LXdyYXA6IG5vd3JhcDtcblx0XHRvdmVyZmxvdy14OiBzY3JvbGw7XG5cblx0XHQmLWl0ZW0ge1xuXHRcdFx0ZmxleDogMCAwIGF1dG87XG5cblx0XHRcdGhlaWdodDogMTg5cHg7XG5cdFx0XHRtYXJnaW4tcmlnaHQ6IDRweDtcblxuXHRcdFx0Ji5pcy1vbmx5LWl0ZW0ge1xuXHRcdFx0XHR3aWR0aDogMTAwdnc7XG5cdFx0XHRcdGRpc3BsYXk6IGZsZXg7XG5cdFx0XHRcdGFsaWduLWl0ZW1zOiBjZW50ZXI7XG5cblx0XHRcdFx0aW1nIHtcblx0XHRcdFx0XHR3aWR0aDogMTAwJTtcblx0XHRcdFx0XHRoZWlnaHQ6IGF1dG87XG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0Ji5pcy1hZGQtc2xpZGVyLWl0ZW0ge1xuXHRcdFx0XHRkaXNwbGF5OiBmbGV4O1xuXHRcdFx0XHRqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcblxuXHRcdFx0XHRtaW4td2lkdGg6IDUwdnc7XG5cdFx0XHRcdGJhY2tncm91bmQ6ICNBNzQwQzI7XG5cblx0XHRcdFx0aW9uLWljb24ge1xuXHRcdFx0XHRcdG1hcmdpbi10b3A6IGNhbGMoKDE4OXB4IC0gNDBweCkgLyAyKTtcblx0XHRcdFx0XHRmb250LXNpemU6IDQwcHg7XG5cdFx0XHRcdFx0Y29sb3I6IHdoaXRlO1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdCYtaW1hZ2Uge1xuXHRcdFx0XHRoZWlnaHQ6IDEwMCU7XG5cdFx0XHRcdHdpZHRoOiBhdXRvO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdCYtaGVhZGVyIHtcblx0XHRkaXNwbGF5OiBmbGV4O1xuXHRcdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcblxuXHRcdHBhZGRpbmc6IDIwcHggMjRweDtcblxuXHRcdCYtaW1hZ2Uge1xuXHRcdFx0ZGlzcGxheTogZmxleDtcblxuXHRcdFx0cG9zaXRpb246IHJlbGF0aXZlO1xuXG5cdFx0XHRtYXJnaW4tdG9wOiAtMzZweDtcblxuXHRcdFx0d2lkdGg6IDg4cHg7XG5cdFx0XHRoZWlnaHQ6IDg4cHg7XG5cdFx0XHRib3JkZXItcmFkaXVzOiA1MCU7XG5cdFx0XHRvdmVyZmxvdzogaGlkZGVuO1xuXHRcdFx0Ym9yZGVyOiA0cHggc29saWQgd2hpdGU7XG5cblx0XHRcdCYtaW1hZ2UtZWxlbWVudCB7XG5cdFx0XHRcdG9iamVjdC1maXQ6IGNvdmVyO1xuXHRcdFx0fVxuXHRcdH1cblxuXHRcdCYtbmFtZSB7XG5cdFx0XHRmb250LXNpemU6IDIycHg7XG5cdFx0XHRmb250LXdlaWdodDogYm9sZDtcblx0XHR9XG5cblx0XHQmLXNldHRpbmdzIHtcblx0XHRcdCYtaWNvbiB7XG5cdFx0XHRcdGZvbnQtc2l6ZTogMjRweDtcblx0XHRcdFx0Y29sb3I6IHJnYigxNTQsIDcwLCAxODcpO1xuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdCYtc2VjdGlvbiB7XG5cdFx0cGFkZGluZzogMjBweCAyNHB4O1xuXHRcdHBhZGRpbmctdG9wOiAwcHg7XG5cblx0XHQmLXRpdGxlIHtcblx0XHRcdGZvbnQtc2l6ZTogMTZweDtcblx0XHRcdGZvbnQtd2VpZ2h0OiBib2xkO1xuXHRcdFx0dGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcblx0XHRcdG1hcmdpbi1ib3R0b206IDE2cHg7XG5cdFx0fVxuXG5cdFx0Ji1wYXJhZ3JhcGgge1xuXHRcdFx0Zm9udC1zaXplOiAxNnB4O1xuXHRcdFx0bGluZS1oZWlnaHQ6IDI0cHg7XG5cdFx0fVxuXG5cdFx0Ji1zZWFyY2hlcyB7XG5cdFx0XHQmLWl0ZW0ge1xuXHRcdFx0XHRkaXNwbGF5OiBmbGV4O1xuXHRcdFx0XHRmbGV4LWRpcmVjdGlvbjogcm93O1xuXHRcdFx0XHRqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG5cblx0XHRcdFx0cGFkZGluZzogMTJweCAyNHB4O1xuXHRcdFx0XHRiYWNrZ3JvdW5kOiByZ2JhKDE1NCwgNzAsIDE4NywgMC4xKTtcblx0XHRcdFx0Ym9yZGVyLXJhZGl1czogMjFweDtcblx0XHRcdFx0bWFyZ2luLWJvdHRvbTogOHB4O1xuXG5cdFx0XHRcdCYtcGhyYXNlIHtcblx0XHRcdFx0XHRmb250LXNpemU6IDE0cHg7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHQmLWJpZy1idXR0b24ge1xuXHRcdG1hcmdpbjogMjBweCAyNnB4O1xuXHRcdG1hcmdpbi10b3A6IDBweDtcblxuXHRcdGRpc3BsYXk6IGZsZXg7XG5cdFx0anVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG5cdFx0cGFkZGluZzogMTRweDtcblx0XHRib3JkZXItcmFkaXVzOiA3cHg7XG5cblx0XHRiYWNrZ3JvdW5kOiByZ2IoMTU0LCA3MCwgMTg3KTtcblx0XHRjb2xvcjogd2hpdGU7XG5cdFx0Zm9udC1zaXplOiAyMHB4O1xuXHRcdGZvbnQtd2VpZ2h0OiBib2xkO1xuXG5cdFx0aW9uLWljb24ge1xuXHRcdFx0bWFyZ2luLXJpZ2h0OiAxMnB4O1xuXHRcdH1cblx0fVxufVxuXG4ucHJvZmlsZS1pbWFnZS1ob2xkZXIge1xuXHRiYWNrZ3JvdW5kOiAjQTc0MEMyO1xuXHRoZWlnaHQ6IDcwcHg7XG5cdHdpZHRoOiA3MHB4O1xuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XG5cdG92ZXJmbG93OiBoaWRkZW47XG5cdGlvbi1pY29uIHtcblx0XHRtYXJnaW4tdG9wOiAxMnB4O1xuXHRcdGZvbnQtc2l6ZTogMzJweDtcblx0XHRjb2xvcjogI0ZGRkZGRiAhaW1wb3J0YW50O1xuXHR9XG5cdCYuZmVhdHVyZWQtaW1hZ2Uge1xuXHRcdGJvcmRlcjogI0ZGRDcwMCBzb2xpZCA0cHg7XG5cdFx0Ym9yZGVyLXJhZGl1czogNHB4O1xuXHR9XG59IiwiLnByb2ZpbGUtcGFnZS1lZGl0IHtcbiAgY29sb3I6ICM5YTQ2YmI7XG4gIGZvbnQtc2l6ZTogMTlweDtcbiAgbWFyZ2luLWxlZnQ6IDhweDtcbn1cbi5wcm9maWxlLXBhZ2Utc2xpZGVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC13cmFwOiBub3dyYXA7XG4gIG92ZXJmbG93LXg6IHNjcm9sbDtcbn1cbi5wcm9maWxlLXBhZ2Utc2xpZGVyLWl0ZW0ge1xuICBmbGV4OiAwIDAgYXV0bztcbiAgaGVpZ2h0OiAxODlweDtcbiAgbWFyZ2luLXJpZ2h0OiA0cHg7XG59XG4ucHJvZmlsZS1wYWdlLXNsaWRlci1pdGVtLmlzLW9ubHktaXRlbSB7XG4gIHdpZHRoOiAxMDB2dztcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbn1cbi5wcm9maWxlLXBhZ2Utc2xpZGVyLWl0ZW0uaXMtb25seS1pdGVtIGltZyB7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IGF1dG87XG59XG4ucHJvZmlsZS1wYWdlLXNsaWRlci1pdGVtLmlzLWFkZC1zbGlkZXItaXRlbSB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBtaW4td2lkdGg6IDUwdnc7XG4gIGJhY2tncm91bmQ6ICNBNzQwQzI7XG59XG4ucHJvZmlsZS1wYWdlLXNsaWRlci1pdGVtLmlzLWFkZC1zbGlkZXItaXRlbSBpb24taWNvbiB7XG4gIG1hcmdpbi10b3A6IGNhbGMoKDE4OXB4IC0gNDBweCkgLyAyKTtcbiAgZm9udC1zaXplOiA0MHB4O1xuICBjb2xvcjogd2hpdGU7XG59XG4ucHJvZmlsZS1wYWdlLXNsaWRlci1pdGVtLWltYWdlIHtcbiAgaGVpZ2h0OiAxMDAlO1xuICB3aWR0aDogYXV0bztcbn1cbi5wcm9maWxlLXBhZ2UtaGVhZGVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBwYWRkaW5nOiAyMHB4IDI0cHg7XG59XG4ucHJvZmlsZS1wYWdlLWhlYWRlci1pbWFnZSB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgbWFyZ2luLXRvcDogLTM2cHg7XG4gIHdpZHRoOiA4OHB4O1xuICBoZWlnaHQ6IDg4cHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbiAgYm9yZGVyOiA0cHggc29saWQgd2hpdGU7XG59XG4ucHJvZmlsZS1wYWdlLWhlYWRlci1pbWFnZS1pbWFnZS1lbGVtZW50IHtcbiAgb2JqZWN0LWZpdDogY292ZXI7XG59XG4ucHJvZmlsZS1wYWdlLWhlYWRlci1uYW1lIHtcbiAgZm9udC1zaXplOiAyMnB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cbi5wcm9maWxlLXBhZ2UtaGVhZGVyLXNldHRpbmdzLWljb24ge1xuICBmb250LXNpemU6IDI0cHg7XG4gIGNvbG9yOiAjOWE0NmJiO1xufVxuLnByb2ZpbGUtcGFnZS1zZWN0aW9uIHtcbiAgcGFkZGluZzogMjBweCAyNHB4O1xuICBwYWRkaW5nLXRvcDogMHB4O1xufVxuLnByb2ZpbGUtcGFnZS1zZWN0aW9uLXRpdGxlIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgbWFyZ2luLWJvdHRvbTogMTZweDtcbn1cbi5wcm9maWxlLXBhZ2Utc2VjdGlvbi1wYXJhZ3JhcGgge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGxpbmUtaGVpZ2h0OiAyNHB4O1xufVxuLnByb2ZpbGUtcGFnZS1zZWN0aW9uLXNlYXJjaGVzLWl0ZW0ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIHBhZGRpbmc6IDEycHggMjRweDtcbiAgYmFja2dyb3VuZDogcmdiYSgxNTQsIDcwLCAxODcsIDAuMSk7XG4gIGJvcmRlci1yYWRpdXM6IDIxcHg7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cbi5wcm9maWxlLXBhZ2Utc2VjdGlvbi1zZWFyY2hlcy1pdGVtLXBocmFzZSB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbn1cbi5wcm9maWxlLXBhZ2UtYmlnLWJ1dHRvbiB7XG4gIG1hcmdpbjogMjBweCAyNnB4O1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBwYWRkaW5nOiAxNHB4O1xuICBib3JkZXItcmFkaXVzOiA3cHg7XG4gIGJhY2tncm91bmQ6ICM5YTQ2YmI7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBmb250LXdlaWdodDogYm9sZDtcbn1cbi5wcm9maWxlLXBhZ2UtYmlnLWJ1dHRvbiBpb24taWNvbiB7XG4gIG1hcmdpbi1yaWdodDogMTJweDtcbn1cblxuLnByb2ZpbGUtaW1hZ2UtaG9sZGVyIHtcbiAgYmFja2dyb3VuZDogI0E3NDBDMjtcbiAgaGVpZ2h0OiA3MHB4O1xuICB3aWR0aDogNzBweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBvdmVyZmxvdzogaGlkZGVuO1xufVxuLnByb2ZpbGUtaW1hZ2UtaG9sZGVyIGlvbi1pY29uIHtcbiAgbWFyZ2luLXRvcDogMTJweDtcbiAgZm9udC1zaXplOiAzMnB4O1xuICBjb2xvcjogI0ZGRkZGRiAhaW1wb3J0YW50O1xufVxuLnByb2ZpbGUtaW1hZ2UtaG9sZGVyLmZlYXR1cmVkLWltYWdlIHtcbiAgYm9yZGVyOiAjRkZENzAwIHNvbGlkIDRweDtcbiAgYm9yZGVyLXJhZGl1czogNHB4O1xufSJdfQ== */"

/***/ }),

/***/ "./src/app/user/user.page.ts":
/*!***********************************!*\
  !*** ./src/app/user/user.page.ts ***!
  \***********************************/
/*! exports provided: UserPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UserPage", function() { return UserPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/toast.service */ "./src/app/services/toast.service.ts");
/* harmony import */ var _services_navigation_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/navigation.service */ "./src/app/services/navigation.service.ts");
/* harmony import */ var _services_query_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/query.service */ "./src/app/services/query.service.ts");
/* harmony import */ var _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/photo-viewer/ngx */ "./node_modules/@ionic-native/photo-viewer/ngx/index.js");
/* harmony import */ var _services_loading_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/loading.service */ "./src/app/services/loading.service.ts");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");










const { Modals } = _capacitor_core__WEBPACK_IMPORTED_MODULE_9__["Plugins"];
let UserPage = class UserPage {
    constructor(route, router, authentication, toast, nav, loading_service, photos, query) {
        this.route = route;
        this.router = router;
        this.authentication = authentication;
        this.toast = toast;
        this.nav = nav;
        this.loading_service = loading_service;
        this.photos = photos;
        this.query = query;
        this.user_id = undefined;
        this.origin_search = undefined;
        this.search_string = "";
        this.user_object = undefined;
        this.past_searches = [];
        this.image_data = [];
        this.hide_aux_info = false;
        this.user_id = this.route.snapshot.paramMap.get('id');
        this.origin_search = this.nav.stored_params['search_object'];
        this.hide_aux_info = this.nav.stored_params['hide_aux_info'];
        this.LoadUserData();
        this.LoadImageList();
        this.LoadSearchHistory();
        console.log('origin_search', this.origin_search);
        if (this.origin_search) {
            this.search_string = this.origin_search.phrase;
        }
    }
    ngOnInit() {
    }
    StartMessage() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            // let prompt_response = await Modals.prompt({
            //     title: 'Introduce Yourself',
            //     message: 'Send your first message to this user!'
            // });
            var message_content = "";
            // if(prompt_response['cancelled'])
            //     return; // User cancelled the send.
            // if(!prompt_response['cancelled'] && prompt_response['value']) {
            //     message_content = prompt_response['value'];
            //     console.log('message_content', message_content);
            // }
            this.query.request('messaging/threads', 'POST', { "search_origin": this.origin_search.id }, { "participants": [this.user_id] }).subscribe(results => {
                var data = results['data'];
                this.nav.messageRouteFlag.next('hello-message');
                this.nav.NavigateForward('message-view/' + data['id'], {});
                // var body = {
                //     //"content": message_content,
                //     "thread": data['id'],
                //     "media_url": undefined
                // };
                // this.query.request(
                //         'messaging/messages', 'POST', {}, body
                //     ).subscribe(
                //             results => {
                //                 console.log("test message-view",results)
                //                 this.nav.NavigateForward('message-view/' + data['id'], {});
                //             },
                //             error => {
                //                 this.toast.DisplaySimpleToast(
                //                         "Unable to send message."
                //                     );
                //             }
                //         );
            }, error => {
                this.toast.DisplaySimpleToast("Unable to start message thread.");
            });
        });
    }
    LoadUserData() {
        this.query.request('users/'.concat(this.user_id), 'GET', {}).subscribe(results => {
            this.user_object = results['data'];
        }, error => {
            this.toast.DisplaySimpleToast("Unable to retrieve user.");
        });
    }
    DeleteUser() {
        this.query.request('users/'.concat(this.user_id), 'DELETE', {}).subscribe(results => {
            this.nav.NavigateRoot('dashboard', {});
        }, error => {
            this.toast.DisplaySimpleToast("Unable to delete user.");
        });
    }
    DeleteSearch() {
        var search_to_delete = this.origin_search.id;
        this.query.request('discovery/searches/'.concat(search_to_delete), 'DELETE', {}).subscribe(results => {
            this.nav.NavigateRoot('dashboard', {});
        }, error => {
            this.toast.DisplaySimpleToast("Unable to delete search.");
        });
    }
    LoadImageList() {
        this.query.request('profile/photos', 'GET', {
            "user": this.user_id
        }).subscribe(results => {
            this.image_data = results['data'];
            // TODO - Remove this console statement.
            console.log('this.image_data', this.image_data);
        }, error => {
            this.toast.DisplaySimpleToast("Unable to load photos.");
        });
    }
    LoadSearchHistory() {
        this.query.request('discovery/searches', 'GET', {
            user: this.user_id,
            page_size: 10
        }).subscribe(searches => {
            this.past_searches = searches['data'];
        }, error => {
            this.toast.DisplaySimpleToast("Unable to load search history.");
        });
    }
    PerformSearch($event) {
        console.log('$event', $event);
        this.search_string = $event.target.value;
        this.NavigateToSearch();
    }
    PerformSearchOfPhrase(phrase) {
        this.nav.NavigateForward('search/' + phrase, { "search_string": phrase });
    }
    NavigateToSearch() {
        this.search_string = this.search_string.replace(/[^\w\s\'\"\-]/gi, '');
        // this.loading_service.PresentLoader("Searching...");
        this.nav.NavigateForward('search/' + this.search_string, { "search_string": this.search_string });
    }
    SearchFor(phrase) {
        this.search_string = phrase;
        this.NavigateToSearch();
    }
    ShowPhoto(media_url) {
        this.photos.show(media_url);
    }
    BlockUser() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            let confirm_results = yield Modals.confirm({
                title: 'Confirm',
                message: 'You are about to flag this user\'s content as malicious and objectionable. You will no longer see content from this user. Continue?'
            });
            if (confirm_results['value']) {
                console.log('Block this user.');
                var body = { flaggee: this.user_id, flagger: this.authentication.user.id };
                this.query.request('profile/flags', 'POST', {}, body).subscribe(results => {
                    this.nav.NavigateRoot('dashboard', {});
                    this.toast.DisplaySimpleToast("This user has been blocked.");
                }, error => {
                    this.toast.DisplaySimpleToast("Unable to block user.");
                });
            }
        });
    }
};
UserPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _services_authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"] },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_4__["ToastService"] },
    { type: _services_navigation_service__WEBPACK_IMPORTED_MODULE_5__["NavigationService"] },
    { type: _services_loading_service__WEBPACK_IMPORTED_MODULE_8__["LoadingService"] },
    { type: _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_7__["PhotoViewer"] },
    { type: _services_query_service__WEBPACK_IMPORTED_MODULE_6__["QueryService"] }
];
UserPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-user',
        template: __webpack_require__(/*! raw-loader!./user.page.html */ "./node_modules/raw-loader/index.js!./src/app/user/user.page.html"),
        styles: [__webpack_require__(/*! ./user.page.scss */ "./src/app/user/user.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _services_authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"],
        _services_toast_service__WEBPACK_IMPORTED_MODULE_4__["ToastService"],
        _services_navigation_service__WEBPACK_IMPORTED_MODULE_5__["NavigationService"],
        _services_loading_service__WEBPACK_IMPORTED_MODULE_8__["LoadingService"],
        _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_7__["PhotoViewer"],
        _services_query_service__WEBPACK_IMPORTED_MODULE_6__["QueryService"]])
], UserPage);



/***/ })

}]);
//# sourceMappingURL=user-user-module-es2015.js.map