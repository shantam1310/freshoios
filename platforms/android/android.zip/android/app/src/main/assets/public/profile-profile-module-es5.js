(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["profile-profile-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/profile/profile.page.html":
/*!*********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/profile/profile.page.html ***!
  \*********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content class=\"profile-page is-my-profile\">\n    <ion-item style=\"width:1px; height:1px; overflow:hidden; \n                                 position:relative; left:-1000px;\">\n         <ion-label id=\"profile_image\" color=\"primary\" stacked>\n             Add Image\n         </ion-label>\n         <input type=\"file\" accept=\"image/*\" name=\"file\" #file id=\"file\" \n                (change)=\"ChangeListener($event)\" />\n     </ion-item>\n\n    <div class=\"profile-page-slider\">\n        <div class=\"profile-page-slider-item\" *ngFor=\"let this_image of image_data\"\n              (click)=\"DisplayActions(this_image);\">\n            <img class=\"profile-page-slider-item-image\"\n                 [src]=\"this_image.media_url\" />\n        </div>\n        <div class=\"profile-page-slider-item is-add-slider-item {{ !image_data.length ? 'is-only-option' : '' }}\" \n             *ngIf=\"image_data.length < 6\"\n             (click)=\"TriggerFileInput();\">\n            <ion-icon [name]=\"'md-camera'\"></ion-icon>\n        </div>\n    </div>\n\n    <div class=\"profile-page-header\">\n        <div class=\"profile-page-header-image\">\n            <img class=\"profile-page-header-image-element\" \n                 [src]=\"authentication.user.profile_photo || authentication.default_avatar\" />\n        </div>\n        <div class=\"profile-page-header-name\">\n            {{ form.company_name }}\n            <ion-icon [name]=\"'md-create'\" class=\"profile-page-edit\"\n                      (click)=\"EditSetting(form, 'company_name', 'Edit Name');\"></ion-icon>\n        </div>\n        <div class=\"profile-page-header-settings\">\n            <ion-icon name=\"md-settings\" class=\"profile-page-header-settings-icon\"\n                      [routerLink]=\"'/settings'\" routerDirection=\"forward\"></ion-icon>\n        </div>\n    </div>\n\n    <div class=\"profile-page-section\">\n        <div class=\"profile-page-section-title\">\n            About Me\n            <ion-icon [name]=\"'md-create'\" class=\"profile-page-edit\"\n                      (click)=\"EditSetting(form.settings, 'biography', 'Edit About Me');\"></ion-icon>\n        </div>\n        <div class=\"profile-page-section-paragraph\">\n            {{ form.settings.biography }}\n        </div>\n    </div>\n\n    <div class=\"profile-page-section\">\n        <div class=\"profile-page-section-title\">\n            <div>\n                Recent Searches\n            </div>\n            <div class=\"profile-page-section-title-link\"\n                 [routerLink]=\"'/search-history'\" routerDirection=\"forward\">\n                Manage\n            </div>\n        </div>\n        <div class=\"profile-page-section-searches\">\n            <div class=\"profile-page-section-searches-item\n                        {{ this_result.clicked ? 'is-clicked' : '' }}\" \n                 *ngFor=\"let this_result of past_searches\"\n                 (click)=\"PerformSearchOfPhrase(this_result.phrase, this_result);\">\n                <div class=\"profile-page-section-searches-item-phrase\">\n                    {{this_result.connotation}} {{this_result.phrase}}\n                </div>\n            </div>\n        </div>\n    </div>\n\n    <div class=\"profile-page-section\" *ngIf=\"flagged_users.length\">\n        <div class=\"profile-page-section-title\">\n            Flagged Users\n        </div>\n        <div class=\"profile-page-section-searches\">\n            <div class=\"profile-page-section-searches-item\" *ngFor=\"let this_result of flagged_users\">\n                <div class=\"profile-page-section-searches-item-phrase\">\n                    {{this_result.friendly_identifier}}\n                </div>\n                <div class=\"profile-page-section-searches-item-close\">\n                    <ion-icon name=\"ios-close-circle\" slot=\"end\"\n                              (click)=\"DeleteFlaggedUsers(this_result);\"></ion-icon>\n                </div>\n            </div>\n        </div>\n    </div>\n</ion-content>\n\n<ion-footer>\n    <ion-toolbar>\n        <ion-tabs>\n            <ion-tab-bar slot=\"bottom\" class=\"whoyou-tabs\">\n                <ion-tab-button [routerLink]=\"'/profile'\" routerDirection=\"root\"\n                                class=\"whoyou-tabs-item is-active\n                                       {{ isLoading ? 'is-big' : '' }}\">\n                    <ion-icon name=\"md-person\"></ion-icon>\n                </ion-tab-button>\n                <ion-tab-button [routerLink]=\"'/dashboard'\" routerDirection=\"root\"\n                                class=\"whoyou-tabs-item\">\n                    <ion-icon name=\"md-search\"></ion-icon>\n                </ion-tab-button>\n                <ion-tab-button [routerLink]=\"'/messages'\" routerDirection=\"root\"\n                                class=\"whoyou-tabs-item\">\n                    <ion-icon name=\"md-chatbubbles\"></ion-icon>\n                </ion-tab-button>\n            </ion-tab-bar>\n        </ion-tabs>\n    </ion-toolbar>\n</ion-footer>"

/***/ }),

/***/ "./src/app/profile/profile.module.ts":
/*!*******************************************!*\
  !*** ./src/app/profile/profile.module.ts ***!
  \*******************************************/
/*! exports provided: ProfilePageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePageModule", function() { return ProfilePageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _profile_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./profile.page */ "./src/app/profile/profile.page.ts");







var routes = [
    {
        path: '',
        component: _profile_page__WEBPACK_IMPORTED_MODULE_6__["ProfilePage"]
    }
];
var ProfilePageModule = /** @class */ (function () {
    function ProfilePageModule() {
    }
    ProfilePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_profile_page__WEBPACK_IMPORTED_MODULE_6__["ProfilePage"]]
        })
    ], ProfilePageModule);
    return ProfilePageModule;
}());



/***/ }),

/***/ "./src/app/profile/profile.page.scss":
/*!*******************************************!*\
  !*** ./src/app/profile/profile.page.scss ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".profile-page-edit {\n  color: #9a46bb;\n  font-size: 19px;\n  margin-left: 8px;\n}\n.profile-page-slider {\n  display: -webkit-box;\n  display: flex;\n  flex-wrap: nowrap;\n  overflow-x: scroll;\n}\n.profile-page-slider-item {\n  -webkit-box-flex: 0;\n          flex: 0 0 auto;\n  height: 189px;\n  margin-right: 4px;\n}\n.profile-page-slider-item.is-add-slider-item {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  min-width: 50vw;\n  background: #A740C2;\n}\n.profile-page-slider-item.is-add-slider-item.is-only-option {\n  margin-right: 0px;\n  width: 100%;\n}\n.profile-page-slider-item.is-add-slider-item ion-icon {\n  margin-top: calc((189px - 40px) / 2);\n  font-size: 40px;\n  color: white;\n}\n.profile-page-slider-item-image {\n  height: 100%;\n  width: auto;\n}\n.profile-page-header {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: justify;\n          justify-content: space-between;\n  padding: 20px 24px;\n}\n.profile-page-header-image {\n  display: -webkit-box;\n  display: flex;\n  position: relative;\n  margin-top: -36px;\n  width: 88px;\n  height: 88px;\n  border-radius: 50%;\n  overflow: hidden;\n  border: 4px solid white;\n}\n.profile-page-header-image-image-element {\n  -o-object-fit: cover;\n     object-fit: cover;\n}\n.profile-page-header-name {\n  font-size: 22px;\n  font-weight: bold;\n}\n.profile-page-header-settings-icon {\n  font-size: 24px;\n  color: #9a46bb;\n}\n.profile-page-section {\n  padding: 20px 24px;\n  padding-top: 0px;\n}\n.profile-page-section-title {\n  font-size: 16px;\n  font-weight: bold;\n  text-transform: uppercase;\n  margin-bottom: 16px;\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: justify;\n          justify-content: space-between;\n}\n.profile-page-section-title-link {\n  font-size: 14px;\n  color: #9a46bb;\n}\n.profile-page-section-paragraph {\n  font-size: 16px;\n  line-height: 24px;\n}\n.profile-page-section-searches-item {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-orient: horizontal;\n  -webkit-box-direction: normal;\n          flex-direction: row;\n  -webkit-box-pack: justify;\n          justify-content: space-between;\n  padding: 12px 24px;\n  background: rgba(154, 70, 187, 0.1);\n  border-radius: 21px;\n  margin-bottom: 8px;\n  -webkit-transition: margin 0.2s;\n  transition: margin 0.2s;\n}\n.profile-page-section-searches-item.is-clicked {\n  margin: 8px 16px;\n}\n.profile-page-section-searches-item-phrase {\n  font-size: 14px;\n}\n.profile-page-big-button {\n  display: -webkit-box;\n  display: flex;\n  -webkit-box-pack: center;\n          justify-content: center;\n  padding: 14px;\n  border-radius: 7px;\n  background: #9a46bb;\n  color: white;\n  font-size: 20px;\n  font-weight: bold;\n}\n.profile-page-big-button ion-icon {\n  margin-right: 12px;\n}\n.profile-image-holder {\n  background: #A740C2;\n  height: 70px;\n  width: 70px;\n  text-align: center;\n  overflow: hidden;\n}\n.profile-image-holder ion-icon {\n  margin-top: 12px;\n  font-size: 32px;\n  color: #FFFFFF !important;\n}\n.profile-image-holder.featured-image {\n  border: #FFD700 solid 4px;\n  border-radius: 4px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zaGFudGFtc2hhcm1hL0Rvd25sb2Fkcy93aG95b3Uvc3JjL2FwcC9wcm9maWxlL3Byb2ZpbGUucGFnZS5zY3NzIiwic3JjL2FwcC9wcm9maWxlL3Byb2ZpbGUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUNDO0VBQ0MsY0FBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBQ0FGO0FER0M7RUFDQyxvQkFBQTtFQUFBLGFBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0FDREY7QURHRTtFQUNDLG1CQUFBO1VBQUEsY0FBQTtFQUVBLGFBQUE7RUFDQSxpQkFBQTtBQ0ZIO0FESUc7RUFDQyxvQkFBQTtFQUFBLGFBQUE7RUFDQSx3QkFBQTtVQUFBLHVCQUFBO0VBRUEsZUFBQTtFQUNBLG1CQUFBO0FDSEo7QURLSTtFQUNDLGlCQUFBO0VBQ0EsV0FBQTtBQ0hMO0FETUk7RUFDQyxvQ0FBQTtFQUNBLGVBQUE7RUFDQSxZQUFBO0FDSkw7QURRRztFQUNDLFlBQUE7RUFDQSxXQUFBO0FDTko7QURXQztFQUNDLG9CQUFBO0VBQUEsYUFBQTtFQUNBLHlCQUFBO1VBQUEsOEJBQUE7RUFFQSxrQkFBQTtBQ1ZGO0FEWUU7RUFDQyxvQkFBQTtFQUFBLGFBQUE7RUFFQSxrQkFBQTtFQUVBLGlCQUFBO0VBRUEsV0FBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0VBQ0EsdUJBQUE7QUNiSDtBRGVHO0VBQ0Msb0JBQUE7S0FBQSxpQkFBQTtBQ2JKO0FEaUJFO0VBQ0MsZUFBQTtFQUNBLGlCQUFBO0FDZkg7QURtQkc7RUFDQyxlQUFBO0VBQ0EsY0FBQTtBQ2pCSjtBRHNCQztFQUNDLGtCQUFBO0VBQ0EsZ0JBQUE7QUNwQkY7QURzQkU7RUFDQyxlQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0VBRUEsb0JBQUE7RUFBQSxhQUFBO0VBQ0EseUJBQUE7VUFBQSw4QkFBQTtBQ3JCSDtBRHVCRztFQUNDLGVBQUE7RUFDQSxjQUFBO0FDckJKO0FEeUJFO0VBQ0MsZUFBQTtFQUNBLGlCQUFBO0FDdkJIO0FEMkJHO0VBQ0Msb0JBQUE7RUFBQSxhQUFBO0VBQ0EsOEJBQUE7RUFBQSw2QkFBQTtVQUFBLG1CQUFBO0VBQ0EseUJBQUE7VUFBQSw4QkFBQTtFQUVBLGtCQUFBO0VBQ0EsbUNBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0EsK0JBQUE7RUFBQSx1QkFBQTtBQzFCSjtBRDRCSTtFQUNDLGdCQUFBO0FDMUJMO0FENkJJO0VBQ0MsZUFBQTtBQzNCTDtBRGlDQztFQUNDLG9CQUFBO0VBQUEsYUFBQTtFQUNBLHdCQUFBO1VBQUEsdUJBQUE7RUFDQSxhQUFBO0VBQ0Esa0JBQUE7RUFFQSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7QUNoQ0Y7QURrQ0U7RUFDQyxrQkFBQTtBQ2hDSDtBRHFDQTtFQUNDLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7RUFDQSxrQkFBQTtFQUNBLGdCQUFBO0FDbENEO0FEbUNDO0VBQ0MsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EseUJBQUE7QUNqQ0Y7QURtQ0M7RUFDQyx5QkFBQTtFQUNBLGtCQUFBO0FDakNGIiwiZmlsZSI6InNyYy9hcHAvcHJvZmlsZS9wcm9maWxlLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIi5wcm9maWxlLXBhZ2Uge1xuXHQmLWVkaXQge1xuXHRcdGNvbG9yOiByZ2IoMTU0LCA3MCwgMTg3KTtcblx0XHRmb250LXNpemU6IDE5cHg7XG5cdFx0bWFyZ2luLWxlZnQ6IDhweDtcblx0fVxuXG5cdCYtc2xpZGVyIHtcblx0XHRkaXNwbGF5OiBmbGV4O1xuXHRcdGZsZXgtd3JhcDogbm93cmFwO1xuXHRcdG92ZXJmbG93LXg6IHNjcm9sbDtcblxuXHRcdCYtaXRlbSB7XG5cdFx0XHRmbGV4OiAwIDAgYXV0bztcblxuXHRcdFx0aGVpZ2h0OiAxODlweDtcblx0XHRcdG1hcmdpbi1yaWdodDogNHB4O1xuXG5cdFx0XHQmLmlzLWFkZC1zbGlkZXItaXRlbSB7XG5cdFx0XHRcdGRpc3BsYXk6IGZsZXg7XG5cdFx0XHRcdGp1c3RpZnktY29udGVudDogY2VudGVyO1xuXG5cdFx0XHRcdG1pbi13aWR0aDogNTB2dztcblx0XHRcdFx0YmFja2dyb3VuZDogI0E3NDBDMjtcblxuXHRcdFx0XHQmLmlzLW9ubHktb3B0aW9uIHtcblx0XHRcdFx0XHRtYXJnaW4tcmlnaHQ6IDBweDtcblx0XHRcdFx0XHR3aWR0aDogMTAwJTtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdGlvbi1pY29uIHtcblx0XHRcdFx0XHRtYXJnaW4tdG9wOiBjYWxjKCgxODlweCAtIDQwcHgpIC8gMik7XG5cdFx0XHRcdFx0Zm9udC1zaXplOiA0MHB4O1xuXHRcdFx0XHRcdGNvbG9yOiB3aGl0ZTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHQmLWltYWdlIHtcblx0XHRcdFx0aGVpZ2h0OiAxMDAlO1xuXHRcdFx0XHR3aWR0aDogYXV0bztcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHQmLWhlYWRlciB7XG5cdFx0ZGlzcGxheTogZmxleDtcblx0XHRqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG5cblx0XHRwYWRkaW5nOiAyMHB4IDI0cHg7XG5cblx0XHQmLWltYWdlIHtcblx0XHRcdGRpc3BsYXk6IGZsZXg7XG5cblx0XHRcdHBvc2l0aW9uOiByZWxhdGl2ZTtcblxuXHRcdFx0bWFyZ2luLXRvcDogLTM2cHg7XG5cblx0XHRcdHdpZHRoOiA4OHB4O1xuXHRcdFx0aGVpZ2h0OiA4OHB4O1xuXHRcdFx0Ym9yZGVyLXJhZGl1czogNTAlO1xuXHRcdFx0b3ZlcmZsb3c6IGhpZGRlbjtcblx0XHRcdGJvcmRlcjogNHB4IHNvbGlkIHdoaXRlO1xuXG5cdFx0XHQmLWltYWdlLWVsZW1lbnQge1xuXHRcdFx0XHRvYmplY3QtZml0OiBjb3Zlcjtcblx0XHRcdH1cblx0XHR9XG5cblx0XHQmLW5hbWUge1xuXHRcdFx0Zm9udC1zaXplOiAyMnB4O1xuXHRcdFx0Zm9udC13ZWlnaHQ6IGJvbGQ7XG5cdFx0fVxuXG5cdFx0Ji1zZXR0aW5ncyB7XG5cdFx0XHQmLWljb24ge1xuXHRcdFx0XHRmb250LXNpemU6IDI0cHg7XG5cdFx0XHRcdGNvbG9yOiByZ2IoMTU0LCA3MCwgMTg3KTtcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHQmLXNlY3Rpb24ge1xuXHRcdHBhZGRpbmc6IDIwcHggMjRweDtcblx0XHRwYWRkaW5nLXRvcDogMHB4O1xuXG5cdFx0Ji10aXRsZSB7XG5cdFx0XHRmb250LXNpemU6IDE2cHg7XG5cdFx0XHRmb250LXdlaWdodDogYm9sZDtcblx0XHRcdHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG5cdFx0XHRtYXJnaW4tYm90dG9tOiAxNnB4O1xuXG5cdFx0XHRkaXNwbGF5OiBmbGV4O1xuXHRcdFx0anVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuXG5cdFx0XHQmLWxpbmsge1xuXHRcdFx0XHRmb250LXNpemU6IDE0cHg7XG5cdFx0XHRcdGNvbG9yOiByZ2IoMTU0LCA3MCwgMTg3KTtcblx0XHRcdH1cblx0XHR9XG5cblx0XHQmLXBhcmFncmFwaCB7XG5cdFx0XHRmb250LXNpemU6IDE2cHg7XG5cdFx0XHRsaW5lLWhlaWdodDogMjRweDtcblx0XHR9XG5cblx0XHQmLXNlYXJjaGVzIHtcblx0XHRcdCYtaXRlbSB7XG5cdFx0XHRcdGRpc3BsYXk6IGZsZXg7XG5cdFx0XHRcdGZsZXgtZGlyZWN0aW9uOiByb3c7XG5cdFx0XHRcdGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcblxuXHRcdFx0XHRwYWRkaW5nOiAxMnB4IDI0cHg7XG5cdFx0XHRcdGJhY2tncm91bmQ6IHJnYmEoMTU0LCA3MCwgMTg3LCAwLjEpO1xuXHRcdFx0XHRib3JkZXItcmFkaXVzOiAyMXB4O1xuXHRcdFx0XHRtYXJnaW4tYm90dG9tOiA4cHg7XG5cdFx0XHRcdHRyYW5zaXRpb246IG1hcmdpbiAwLjJzO1xuXG5cdFx0XHRcdCYuaXMtY2xpY2tlZCB7XG5cdFx0XHRcdFx0bWFyZ2luOiA4cHggMTZweDtcblx0XHRcdFx0fVxuXG5cdFx0XHRcdCYtcGhyYXNlIHtcblx0XHRcdFx0XHRmb250LXNpemU6IDE0cHg7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXHQmLWJpZy1idXR0b24ge1xuXHRcdGRpc3BsYXk6IGZsZXg7XG5cdFx0anVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG5cdFx0cGFkZGluZzogMTRweDtcblx0XHRib3JkZXItcmFkaXVzOiA3cHg7XG5cblx0XHRiYWNrZ3JvdW5kOiByZ2IoMTU0LCA3MCwgMTg3KTtcblx0XHRjb2xvcjogd2hpdGU7XG5cdFx0Zm9udC1zaXplOiAyMHB4O1xuXHRcdGZvbnQtd2VpZ2h0OiBib2xkO1xuXG5cdFx0aW9uLWljb24ge1xuXHRcdFx0bWFyZ2luLXJpZ2h0OiAxMnB4O1xuXHRcdH1cblx0fVxufVxuXG4ucHJvZmlsZS1pbWFnZS1ob2xkZXIge1xuXHRiYWNrZ3JvdW5kOiAjQTc0MEMyO1xuXHRoZWlnaHQ6IDcwcHg7XG5cdHdpZHRoOiA3MHB4O1xuXHR0ZXh0LWFsaWduOiBjZW50ZXI7XG5cdG92ZXJmbG93OiBoaWRkZW47XG5cdGlvbi1pY29uIHtcblx0XHRtYXJnaW4tdG9wOiAxMnB4O1xuXHRcdGZvbnQtc2l6ZTogMzJweDtcblx0XHRjb2xvcjogI0ZGRkZGRiAhaW1wb3J0YW50O1xuXHR9XG5cdCYuZmVhdHVyZWQtaW1hZ2Uge1xuXHRcdGJvcmRlcjogI0ZGRDcwMCBzb2xpZCA0cHg7XG5cdFx0Ym9yZGVyLXJhZGl1czogNHB4O1xuXHR9XG59IiwiLnByb2ZpbGUtcGFnZS1lZGl0IHtcbiAgY29sb3I6ICM5YTQ2YmI7XG4gIGZvbnQtc2l6ZTogMTlweDtcbiAgbWFyZ2luLWxlZnQ6IDhweDtcbn1cbi5wcm9maWxlLXBhZ2Utc2xpZGVyIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC13cmFwOiBub3dyYXA7XG4gIG92ZXJmbG93LXg6IHNjcm9sbDtcbn1cbi5wcm9maWxlLXBhZ2Utc2xpZGVyLWl0ZW0ge1xuICBmbGV4OiAwIDAgYXV0bztcbiAgaGVpZ2h0OiAxODlweDtcbiAgbWFyZ2luLXJpZ2h0OiA0cHg7XG59XG4ucHJvZmlsZS1wYWdlLXNsaWRlci1pdGVtLmlzLWFkZC1zbGlkZXItaXRlbSB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xuICBtaW4td2lkdGg6IDUwdnc7XG4gIGJhY2tncm91bmQ6ICNBNzQwQzI7XG59XG4ucHJvZmlsZS1wYWdlLXNsaWRlci1pdGVtLmlzLWFkZC1zbGlkZXItaXRlbS5pcy1vbmx5LW9wdGlvbiB7XG4gIG1hcmdpbi1yaWdodDogMHB4O1xuICB3aWR0aDogMTAwJTtcbn1cbi5wcm9maWxlLXBhZ2Utc2xpZGVyLWl0ZW0uaXMtYWRkLXNsaWRlci1pdGVtIGlvbi1pY29uIHtcbiAgbWFyZ2luLXRvcDogY2FsYygoMTg5cHggLSA0MHB4KSAvIDIpO1xuICBmb250LXNpemU6IDQwcHg7XG4gIGNvbG9yOiB3aGl0ZTtcbn1cbi5wcm9maWxlLXBhZ2Utc2xpZGVyLWl0ZW0taW1hZ2Uge1xuICBoZWlnaHQ6IDEwMCU7XG4gIHdpZHRoOiBhdXRvO1xufVxuLnByb2ZpbGUtcGFnZS1oZWFkZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIHBhZGRpbmc6IDIwcHggMjRweDtcbn1cbi5wcm9maWxlLXBhZ2UtaGVhZGVyLWltYWdlIHtcbiAgZGlzcGxheTogZmxleDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xuICBtYXJnaW4tdG9wOiAtMzZweDtcbiAgd2lkdGg6IDg4cHg7XG4gIGhlaWdodDogODhweDtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xuICBvdmVyZmxvdzogaGlkZGVuO1xuICBib3JkZXI6IDRweCBzb2xpZCB3aGl0ZTtcbn1cbi5wcm9maWxlLXBhZ2UtaGVhZGVyLWltYWdlLWltYWdlLWVsZW1lbnQge1xuICBvYmplY3QtZml0OiBjb3Zlcjtcbn1cbi5wcm9maWxlLXBhZ2UtaGVhZGVyLW5hbWUge1xuICBmb250LXNpemU6IDIycHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuLnByb2ZpbGUtcGFnZS1oZWFkZXItc2V0dGluZ3MtaWNvbiB7XG4gIGZvbnQtc2l6ZTogMjRweDtcbiAgY29sb3I6ICM5YTQ2YmI7XG59XG4ucHJvZmlsZS1wYWdlLXNlY3Rpb24ge1xuICBwYWRkaW5nOiAyMHB4IDI0cHg7XG4gIHBhZGRpbmctdG9wOiAwcHg7XG59XG4ucHJvZmlsZS1wYWdlLXNlY3Rpb24tdGl0bGUge1xuICBmb250LXNpemU6IDE2cHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB0ZXh0LXRyYW5zZm9ybTogdXBwZXJjYXNlO1xuICBtYXJnaW4tYm90dG9tOiAxNnB4O1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG59XG4ucHJvZmlsZS1wYWdlLXNlY3Rpb24tdGl0bGUtbGluayB7XG4gIGZvbnQtc2l6ZTogMTRweDtcbiAgY29sb3I6ICM5YTQ2YmI7XG59XG4ucHJvZmlsZS1wYWdlLXNlY3Rpb24tcGFyYWdyYXBoIHtcbiAgZm9udC1zaXplOiAxNnB4O1xuICBsaW5lLWhlaWdodDogMjRweDtcbn1cbi5wcm9maWxlLXBhZ2Utc2VjdGlvbi1zZWFyY2hlcy1pdGVtIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBwYWRkaW5nOiAxMnB4IDI0cHg7XG4gIGJhY2tncm91bmQ6IHJnYmEoMTU0LCA3MCwgMTg3LCAwLjEpO1xuICBib3JkZXItcmFkaXVzOiAyMXB4O1xuICBtYXJnaW4tYm90dG9tOiA4cHg7XG4gIHRyYW5zaXRpb246IG1hcmdpbiAwLjJzO1xufVxuLnByb2ZpbGUtcGFnZS1zZWN0aW9uLXNlYXJjaGVzLWl0ZW0uaXMtY2xpY2tlZCB7XG4gIG1hcmdpbjogOHB4IDE2cHg7XG59XG4ucHJvZmlsZS1wYWdlLXNlY3Rpb24tc2VhcmNoZXMtaXRlbS1waHJhc2Uge1xuICBmb250LXNpemU6IDE0cHg7XG59XG4ucHJvZmlsZS1wYWdlLWJpZy1idXR0b24ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbiAgcGFkZGluZzogMTRweDtcbiAgYm9yZGVyLXJhZGl1czogN3B4O1xuICBiYWNrZ3JvdW5kOiAjOWE0NmJiO1xuICBjb2xvcjogd2hpdGU7XG4gIGZvbnQtc2l6ZTogMjBweDtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG4ucHJvZmlsZS1wYWdlLWJpZy1idXR0b24gaW9uLWljb24ge1xuICBtYXJnaW4tcmlnaHQ6IDEycHg7XG59XG5cbi5wcm9maWxlLWltYWdlLWhvbGRlciB7XG4gIGJhY2tncm91bmQ6ICNBNzQwQzI7XG4gIGhlaWdodDogNzBweDtcbiAgd2lkdGg6IDcwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgb3ZlcmZsb3c6IGhpZGRlbjtcbn1cbi5wcm9maWxlLWltYWdlLWhvbGRlciBpb24taWNvbiB7XG4gIG1hcmdpbi10b3A6IDEycHg7XG4gIGZvbnQtc2l6ZTogMzJweDtcbiAgY29sb3I6ICNGRkZGRkYgIWltcG9ydGFudDtcbn1cbi5wcm9maWxlLWltYWdlLWhvbGRlci5mZWF0dXJlZC1pbWFnZSB7XG4gIGJvcmRlcjogI0ZGRDcwMCBzb2xpZCA0cHg7XG4gIGJvcmRlci1yYWRpdXM6IDRweDtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/profile/profile.page.ts":
/*!*****************************************!*\
  !*** ./src/app/profile/profile.page.ts ***!
  \*****************************************/
/*! exports provided: ProfilePage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ProfilePage", function() { return ProfilePage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/toast.service */ "./src/app/services/toast.service.ts");
/* harmony import */ var _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/navigation.service */ "./src/app/services/navigation.service.ts");
/* harmony import */ var _services_query_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/query.service */ "./src/app/services/query.service.ts");
/* harmony import */ var _services_bucket_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/bucket.service */ "./src/app/services/bucket.service.ts");
/* harmony import */ var _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/photo-viewer/ngx */ "./node_modules/@ionic-native/photo-viewer/ngx/index.js");
/* harmony import */ var _services_loading_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/loading.service */ "./src/app/services/loading.service.ts");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");










var Modals = _capacitor_core__WEBPACK_IMPORTED_MODULE_9__["Plugins"].Modals;
var ProfilePage = /** @class */ (function () {
    function ProfilePage(authentication, toast, nav, query, bucket, photos, loading_service) {
        var _this = this;
        this.authentication = authentication;
        this.toast = toast;
        this.nav = nav;
        this.query = query;
        this.bucket = bucket;
        this.photos = photos;
        this.loading_service = loading_service;
        this.form = {};
        this.image_data = [];
        this.past_searches = [];
        this.flagged_users = [];
        this.isLoading = true;
        this.form = {
            "company_name": authentication.user.company_name,
        };
        this.form.settings = this.authentication.user.settings;
        this.form.settings['biography'] = authentication.user.settings.biography ? authentication.user.settings.biography : "This user prefers to maintain a sense of mystery about them.";
        this.LoadImageList();
        this.LoadSearchHistory();
        this.LoadFlags();
        setTimeout(function () {
            _this.isLoading = false;
        }, 200);
    }
    ProfilePage.prototype.ionViewWillLeave = function () {
        console.log('Leaving Profile Page');
        this.Submit();
    };
    ProfilePage.prototype.ionViewWillEnter = function () {
        console.log('Entering Profile Page');
        this.form.settings = this.authentication.user.settings;
        console.log('this.form.settings', this.form.settings);
    };
    ProfilePage.prototype.ngOnInit = function () {
    };
    ProfilePage.prototype.compareFn = function (e1, e2) {
        return parseInt(e1) == parseInt(e2);
    };
    ProfilePage.prototype.Submit = function () {
        var _this = this;
        this.query.request('users/'.concat(this.authentication.user.id), 'PATCH', {}, this.form).subscribe(function (user) {
            var user_data = user['data'];
            _this.authentication.SetUser(user_data);
        }, function (error) {
            _this.toast.DisplaySimpleToast("Unable to update profile.");
        });
    };
    ProfilePage.prototype.LoadImageList = function () {
        var _this = this;
        this.query.request('profile/photos', 'GET', {
            "user": this.authentication.user.id
        }).subscribe(function (results) {
            _this.image_data = results['data'];
        }, function (error) {
            _this.toast.DisplaySimpleToast("Unable to load photos.");
        });
    };
    ProfilePage.prototype.UploadFiles = function () {
        var _this = this;
        this.loading_service.PresentLoader("Uploading...");
        this.bucket.UploadAndGetRemoteFileURL(this.files, 'profiles').then(function (image_url) {
            _this.SubmitProfilePhoto(image_url);
        });
    };
    ProfilePage.prototype.SubmitProfilePhoto = function (image_url) {
        var _this = this;
        var body = {
            "media_url": image_url,
            "user": this.authentication.user.id
        };
        this.query.request('profile/photos', 'POST', {}, body).subscribe(function (results) {
            _this.loading_service.DismissLoader();
            _this.toast.DisplaySimpleToast("Photo has been uploaded. Refreshing...");
            _this.LoadImageList();
        }, function (error) {
            _this.loading_service.DismissLoader();
            _this.toast.DisplaySimpleToast("Unable to upload photo.");
        });
    };
    ProfilePage.prototype.ChangeListener = function ($event) {
        this.files = $event.target.files[0];
        this.UploadFiles();
    };
    ProfilePage.prototype.TriggerFileInput = function () {
        this.file_input.nativeElement.click();
    };
    ProfilePage.prototype.DisplayActions = function (image) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var promptRet;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, Modals.showActions({
                            title: 'Photo Options',
                            message: 'Select an option to perform',
                            options: [
                                {
                                    title: 'Make Featured'
                                },
                                {
                                    title: 'Delete'
                                },
                                {
                                    title: 'View Fullscreen'
                                },
                                {
                                    title: 'Cancel'
                                }
                            ]
                        })];
                    case 1:
                        promptRet = _a.sent();
                        console.log('promptRet', promptRet);
                        if (promptRet.index == 0 /*Feature*/) {
                            this.FeatureImage(image);
                        }
                        if (promptRet.index == 1 /*Delete*/) {
                            this.DeleteImage(image);
                        }
                        if (promptRet.index == 2 /*Fullscreen*/) {
                            this.photos.show(image.media_url);
                        }
                        return [2 /*return*/];
                }
            });
        });
    };
    ProfilePage.prototype.DeleteImage = function (image) {
        var _this = this;
        this.query.request('profile/photos/'.concat(image.id), 'DELETE', {}).subscribe(function (results) {
            _this.toast.DisplaySimpleToast("Photo has been deleted. Refreshing...");
            _this.LoadImageList();
        }, function (error) {
            _this.toast.DisplaySimpleToast("Unable to delete photo.");
        });
    };
    ProfilePage.prototype.FeatureImage = function (image) {
        var _this = this;
        this.query.request('profile/photos/'.concat(image.id), 'PATCH', {}, { is_featured: true }).subscribe(function (results) {
            _this.toast.DisplaySimpleToast("Photo has been featured. Refreshing...");
            _this.LoadImageList();
        }, function (error) {
            _this.toast.DisplaySimpleToast("Unable to update photo.");
        });
    };
    ProfilePage.prototype.LoadSearchHistory = function () {
        var _this = this;
        this.query.request('discovery/searches', 'GET', {
            user: this.authentication.user['id'],
            page_size: 10000
        }).subscribe(function (searches) {
            _this.past_searches = searches['data'];
        }, function (error) {
            _this.toast.DisplaySimpleToast("Unable to load search history.");
        });
    };
    ProfilePage.prototype.PerformSearch = function (search_phrase) {
        search_phrase = search_phrase.replace(/[^\w\s\'\"\-]/gi, '');
        this.nav.NavigateForward('search/' + search_phrase, { "search_string": search_phrase });
    };
    ProfilePage.prototype.PerformSearchOfPhrase = function (phrase, searchItem) {
        var _this = this;
        searchItem['clicked'] = true;
        setTimeout(function () {
            _this.nav.NavigateForward('search/' + phrase, { "search_string": phrase });
            searchItem['clicked'] = false;
        }, 200);
    };
    ProfilePage.prototype.DeleteSearch = function (search) {
        var _this = this;
        this.query.request('discovery/searches/'.concat(search['id']), 'DELETE', {}).subscribe(function (result) {
            _this.LoadSearchHistory();
        }, function (error) {
            _this.toast.DisplaySimpleToast("Unable to delete search history.");
        });
    };
    ProfilePage.prototype.LoadFlags = function () {
        var _this = this;
        this.query.request('profile/flags', 'GET', {
            flagger: this.authentication.user['id'],
            page_size: 10000
        }).subscribe(function (flag_results) {
            _this.flagged_users = flag_results['data'];
        }, function (error) {
            _this.toast.DisplaySimpleToast("Unable to load flags.");
        });
    };
    ProfilePage.prototype.DeleteFlaggedUsers = function (flag) {
        var _this = this;
        this.query.request('profile/flags/'.concat(flag['id']), 'DELETE', {}).subscribe(function (result) {
            _this.LoadFlags();
        }, function (error) {
            _this.toast.DisplaySimpleToast("Unable to delete flag.");
        });
    };
    ProfilePage.prototype.EditSetting = function (master, key, label) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var prompt_response, new_value;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, Modals.prompt({
                            title: label,
                            message: 'Please enter your details.',
                        })];
                    case 1:
                        prompt_response = _a.sent();
                        new_value = "";
                        if (prompt_response['cancelled'])
                            return [2 /*return*/]; // User cancelled the send.
                        if (!prompt_response['cancelled'] && prompt_response['value']) {
                            new_value = prompt_response['value'];
                            console.log('new_value', new_value);
                        }
                        master[key] = new_value;
                        return [2 /*return*/];
                }
            });
        });
    };
    ProfilePage.ctorParameters = function () { return [
        { type: _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] },
        { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"] },
        { type: _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"] },
        { type: _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"] },
        { type: _services_bucket_service__WEBPACK_IMPORTED_MODULE_6__["BucketService"] },
        { type: _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_7__["PhotoViewer"] },
        { type: _services_loading_service__WEBPACK_IMPORTED_MODULE_8__["LoadingService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("file", { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
    ], ProfilePage.prototype, "file_input", void 0);
    ProfilePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-profile',
            template: __webpack_require__(/*! raw-loader!./profile.page.html */ "./node_modules/raw-loader/index.js!./src/app/profile/profile.page.html"),
            styles: [__webpack_require__(/*! ./profile.page.scss */ "./src/app/profile/profile.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"],
            _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"],
            _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"],
            _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"],
            _services_bucket_service__WEBPACK_IMPORTED_MODULE_6__["BucketService"],
            _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_7__["PhotoViewer"],
            _services_loading_service__WEBPACK_IMPORTED_MODULE_8__["LoadingService"]])
    ], ProfilePage);
    return ProfilePage;
}());



/***/ })

}]);
//# sourceMappingURL=profile-profile-module-es5.js.map