(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["message-view-message-view-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/message-view/message-view.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/message-view/message-view.page.html ***!
  \*******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content class=\"white-background message-view\" #content>\n    <div class=\"common-header-spacer\"></div>\n    <div class=\"common-header\">\n        <div class=\"common-header-icon\">\n            <ion-icon name=\"md-arrow-back\" slot=\"end\" (click)=\"nav.PopView();\">\n            </ion-icon>\n        </div>\n        <div class=\"common-header-title\" (click)=\"GoToOpposingUserProfile();\">\n            {{user_data ? user_data.company_name : ''}}\n        </div>\n        <div class=\"common-header-icon\">\n            <ion-icon name=\"md-more\" slot=\"end\" (click)=\"DisplayActions();\">\n            </ion-icon>\n        </div>\n    </div>\n    <ion-list>\n        <!-- Hidden Upload -->\n        <ion-item style=\"width:1px; height:1px; overflow:hidden; \n                         position:relative; left:-1000px;\">\n            <ion-label id=\"profile_image\" color=\"primary\" stacked>\n                Add Image\n            </ion-label>\n            <input type=\"file\" accept=\"image/*\" name=\"file\" #file id=\"file\" (change)=\"ChangeListener($event)\" />\n        </ion-item>\n\n        <!-- Explainer -->\n        <div *ngIf=\"user_data && search_data\" class=\"message-view-explainer\">\n            <ng-container *ngIf=\"(thread_data.owner != authentication.user.id) && !thread_data.is_accepted\">\n                <p class=\"message-view-explainer-card\">\n                    <img src=\"/assets/whoyou-logo.png\" alt=\"\" style=\"max-height: 92px\" class=\"message-view-explainer-card-image\" /> You have a new connection request from {{user_data.company_name}}.\n                </p>\n            </ng-container>\n            <p class=\"message-view-explainer-card\">\n                <img src=\"/assets/whoyou-logo.png\" alt=\"\" style=\"max-height: 92px\" class=\"message-view-explainer-card-image\" /> You and {{user_data.company_name}} both searched for \"{{search_data.phrase}}\".\n            </p>\n        </div>\n\n        <!-- Message Reel -->\n        <ng-container *ngIf=\"message_data && user_data\">\n            <ng-container *ngFor=\"let this_message of message_data; first as is_first\">\n                <ion-item lines=\"none\" class=\"message-view-list-item\">\n                    <ion-avatar slot=\"start\" (click)=\"GoToOpposingUserProfile(this_message.owner);\" *ngIf=\"this_message.owner != authentication.user.id\">\n                        <img [src]=\"this_message.profile_image ? this_message.profile_image : authentication.default_avatar\">\n                    </ion-avatar>\n                    <ion-label class=\"ion-text-wrap whoyou-message message-view-list-item-message\" [ngClass]=\"this_message.owner == authentication.user.id ? 'your-message' : 'their-message'\">\n                        <p>{{this_message.content}}</p>\n                        <div *ngIf=\"this_message.media_url && ((authentication.user.settings.hide_image_content != 'true') || (this_message.owner == authentication.user.id))\">\n                            <ng-container *ngIf=\"FileIsImage(this_message.media_url)\">\n                                <img [src]=\"this_message.media_url\" (click)=\"ShowImage(this_message.media_url);\" />\n                            </ng-container>\n                            <!-- <ng-container *ngIf=\"!FileIsImage(this_message.media_url)\">\n                                <video [src]=\"this_message.media_url\" style=\"width: 100%;\"></video>\n                            </ng-container> -->\n                        </div>\n                    </ion-label>\n                    <ion-avatar slot=\"end\" (click)=\"GoToOpposingUserProfile(this_message.owner);\" *ngIf=\"this_message.owner == authentication.user.id\">\n                        <img [src]=\"this_message.profile_image ? this_message.profile_image : authentication.default_avatar\">\n                    </ion-avatar>\n                </ion-item>\n\n                <!-- You Accepted Message -->\n                <ng-container *ngIf=\"(thread_data.owner != authentication.user.id) && thread_data.is_accepted&& is_first\">\n                    <p class=\"message-view-inline-explainer-card\">\n                        You accepted {{user_data.company_name}}'s message request. Say hello!\n                    </p>\n                </ng-container>\n\n                <!-- Awaiting Acceptance -->\n                <ng-container *ngIf=\"(thread_data.owner == authentication.user.id) && !thread_data.is_accepted && message_data && message_data.length\">\n                    <p class=\"message-view-inline-explainer-card\">\n                        You are waiting on {{user_data.company_name}} to accept this contact request.\n                    </p>\n                </ng-container>\n\n            </ng-container>\n        </ng-container>\n\n        <!-- Acceptance Popup -->\n        <div *ngIf=\"user_data && search_data\">\n            <ng-container *ngIf=\"(thread_data.owner != authentication.user.id) && !thread_data.is_accepted\">\n                <div class=\"message-index-item-row message-index-item-row-request-items\" *ngIf=\"!thread_data.is_accepted\">\n                    <div class=\"message-index-item-button message-index-item-button-delete\" (click)=\"MarkThreadDeclined();\">\n                        Delete\n                    </div>\n                    <div class=\"message-index-item-button message-index-item-button-view\" (click)=\"MarkThreadAccepted();\">\n                        Accept Request\n                    </div>\n                </div>\n            </ng-container>\n\n        </div>\n    </ion-list>\n</ion-content>\n\n<ion-footer>\n    <ion-toolbar>\n        <ion-buttons slot=\"start\">\n            <ion-button [disabled]=\"(!thread_data || !message_data) || ((thread_data.owner == authentication.user.id) && !thread_data.is_accepted && message_data.length)\" (click)=\"TriggerFileInput();\">\n                <ion-img *ngIf=\"form.media_url\" [src]=\"form.media_url\" style=\"max-width: 40px;\"></ion-img>\n                <ion-icon [name]=\"form.media_url ? 'md-close' : 'md-attach'\" *ngIf=\"!form.media_url\"></ion-icon>\n            </ion-button>\n        </ion-buttons>\n        <ion-title>\n            <ion-textarea placeholder=\"Message...\" [(ngModel)]=\"form.content\" autocomplete=\"true\" spellcheck=\"true\" [disabled]=\"(!thread_data || !message_data) || ((thread_data.owner == authentication.user.id) \n            && !thread_data.is_accepted && message_data.length)\"></ion-textarea>\n            <!-- <ion-textarea placeholder=\"Message...\" [(ngModel)]=\"form.content\" autocomplete=\"true\" \n                spellcheck=\"true\" [disabled]=\"(!thread_data || !message_data) || ((thread_data.owner == authentication.user.id) && !thread_data.is_accepted && message_data.length)\"></ion-textarea> -->\n        </ion-title>\n        <ion-buttons slot=\"end\">\n            <ion-button (click)=\"SendMessage();\" (mousedown)=\"$event.preventDefault()\" [disabled]=\"(!thread_data || !message_data) || ((thread_data.owner == authentication.user.id)\n             && !thread_data.is_accepted && message_data.length)\">\n                <ion-icon name=\"md-send\"></ion-icon>\n            </ion-button>\n        </ion-buttons>\n    </ion-toolbar>\n</ion-footer>"

/***/ }),

/***/ "./src/app/message-view/message-view.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/message-view/message-view.module.ts ***!
  \*****************************************************/
/*! exports provided: MessageViewPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessageViewPageModule", function() { return MessageViewPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _message_view_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./message-view.page */ "./src/app/message-view/message-view.page.ts");







const routes = [
    {
        path: '',
        component: _message_view_page__WEBPACK_IMPORTED_MODULE_6__["MessageViewPage"]
    }
];
let MessageViewPageModule = class MessageViewPageModule {
};
MessageViewPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_message_view_page__WEBPACK_IMPORTED_MODULE_6__["MessageViewPage"]]
    })
], MessageViewPageModule);



/***/ }),

/***/ "./src/app/message-view/message-view.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/message-view/message-view.page.scss ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".message-view {\n  /* Ported Styles From Message Index */\n}\n.message-view-explainer {\n  padding: 16px;\n}\n.message-view-explainer-card {\n  position: relative;\n  padding: 17px;\n  padding-left: 71px;\n  font-size: 14px;\n  font-weight: bold;\n  color: white;\n  background: #9a46bb;\n  margin-bottom: 8px;\n  border-radius: 8px;\n}\n.message-view-explainer-card-image {\n  position: absolute;\n  top: 13px;\n  left: 17px;\n  width: 38px;\n  height: auto;\n}\n.message-view-inline-explainer-card {\n  margin-left: 16px;\n  margin-right: 16px;\n  padding: 17px;\n  font-size: 14px;\n  font-weight: bold;\n  color: white;\n  background: #9a46bb;\n  margin-bottom: 8px;\n  border-radius: 8px;\n  text-align: center;\n}\n.message-view-list-item-message {\n  padding: 16px;\n}\n.message-view-list-item-message p {\n  font-size: 16px !important;\n  font-weight: bold !important;\n}\n.message-view .message-index-item {\n  width: 100%;\n  padding-bottom: 15px;\n  padding-top: 15px;\n}\n.message-view .message-index-item-row {\n  margin-left: 16px;\n  margin-right: 16px;\n  display: -webkit-box;\n  display: flex;\n}\n.message-view .message-index-item-row-request-items {\n  padding-top: 16px;\n}\n.message-view .message-index-item-button {\n  display: inline-block;\n  text-align: center;\n  border-radius: 20px;\n  font-size: 13px;\n  padding: 11px;\n}\n.message-view .message-index-item-button-delete {\n  background: rgba(208, 2, 27, 0.12);\n  color: #c66363;\n  width: 102px;\n}\n.message-view .message-index-item-button-view {\n  background: #9a46bb;\n  color: white;\n  width: calc(100% - 102px - 16px);\n  margin-left: 16px;\n}\n.message-view .message-index-item-badge {\n  display: inline-block;\n  background: rgba(154, 70, 187, 0.15);\n  color: #9a46bb;\n  padding: 4px 7px;\n  font-weight: bold;\n  text-transform: uppercase;\n  font-variant: small-caps;\n  font-size: 11px;\n}\n.message-view .message-index-item-image {\n  display: inline-block;\n  width: 64px;\n}\n.message-view .message-index-item-content {\n  display: inline-block;\n  width: calc(100% - 64px - 13px);\n  margin-left: 13px;\n}\n.message-view .message-index-item-content h2 {\n  margin-top: 0px;\n  margin-bottom: 4px;\n  padding-top: 8px;\n  font-size: 14px;\n}\n.message-view .message-index-item-content p {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  font-size: 14px;\n  opacity: 0.57;\n}\n.message-view .message-index-item-content p.strong {\n  opacity: 1;\n}\n.whoyou-message {\n  border-radius: 5px;\n}\n.whoyou-message.their-message {\n  background: #E8E8E8 !important;\n}\n.whoyou-message.your-message {\n  background: #E8E8E8 !important;\n}\n.whoyou-message.your-message h2, .whoyou-message.your-message p {\n  color: #9a46bb !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zaGFudGFtc2hhcm1hL0Rvd25sb2Fkcy93aG95b3Uvc3JjL2FwcC9tZXNzYWdlLXZpZXcvbWVzc2FnZS12aWV3LnBhZ2Uuc2NzcyIsInNyYy9hcHAvbWVzc2FnZS12aWV3L21lc3NhZ2Utdmlldy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFzREMscUNBQUE7QUNwREQ7QUREQztFQUNDLGFBQUE7QUNHRjtBRERFO0VBQ0Msa0JBQUE7RUFFQSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSxlQUFBO0VBQ0EsaUJBQUE7RUFDQSxZQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FDRUg7QURBRztFQUNDLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFVBQUE7RUFFQSxXQUFBO0VBQ0EsWUFBQTtBQ0NKO0FESUM7RUFDQyxpQkFBQTtFQUNBLGtCQUFBO0VBQ0EsYUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBQ0ZGO0FETUU7RUFDQyxhQUFBO0FDSkg7QURNRztFQUNDLDBCQUFBO0VBQ0EsNEJBQUE7QUNKSjtBRGNFO0VBRUMsV0FBQTtFQUNBLG9CQUFBO0VBQ0EsaUJBQUE7QUNiSDtBRGVHO0VBQ0MsaUJBQUE7RUFDQSxrQkFBQTtFQUVBLG9CQUFBO0VBQUEsYUFBQTtBQ2RKO0FEZ0JJO0VBQ0MsaUJBQUE7QUNkTDtBRGtCRztFQUNDLHFCQUFBO0VBQ0Esa0JBQUE7RUFDQSxtQkFBQTtFQUNBLGVBQUE7RUFDQSxhQUFBO0FDaEJKO0FEa0JJO0VBQ0Msa0NBQUE7RUFDQSxjQUFBO0VBQ0EsWUFBQTtBQ2hCTDtBRG1CSTtFQUNDLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGdDQUFBO0VBQ0EsaUJBQUE7QUNqQkw7QURxQkc7RUFDQyxxQkFBQTtFQUNBLG9DQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsaUJBQUE7RUFDQSx5QkFBQTtFQUNBLHdCQUFBO0VBQ0EsZUFBQTtBQ25CSjtBRHNCRztFQUNDLHFCQUFBO0VBQ0EsV0FBQTtBQ3BCSjtBRHVCRztFQUNDLHFCQUFBO0VBQ0EsK0JBQUE7RUFDQSxpQkFBQTtBQ3JCSjtBRHVCSTtFQUNDLGVBQUE7RUFDQSxrQkFBQTtFQUVBLGdCQUFBO0VBRUEsZUFBQTtBQ3ZCTDtBRDBCSTtFQUNDLGVBQUE7RUFDQSxrQkFBQTtFQUVBLGVBQUE7RUFFQSxhQUFBO0FDMUJMO0FENEJLO0VBQ0MsVUFBQTtBQzFCTjtBRHFDQTtFQUNDLGtCQUFBO0FDbENEO0FEb0NDO0VBQ0MsOEJBQUE7QUNsQ0Y7QURvQ0M7RUFDQyw4QkFBQTtBQ2xDRjtBRG1DRTtFQUNDLHlCQUFBO0FDakNIIiwiZmlsZSI6InNyYy9hcHAvbWVzc2FnZS12aWV3L21lc3NhZ2Utdmlldy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIubWVzc2FnZS12aWV3IHtcblx0Ji1leHBsYWluZXIge1xuXHRcdHBhZGRpbmc6IDE2cHg7XG5cblx0XHQmLWNhcmQge1xuXHRcdFx0cG9zaXRpb246IHJlbGF0aXZlO1xuXG5cdFx0XHRwYWRkaW5nOiAxN3B4O1xuXHRcdFx0cGFkZGluZy1sZWZ0OiA3MXB4O1xuXHRcdFx0Zm9udC1zaXplOiAxNHB4O1xuXHRcdFx0Zm9udC13ZWlnaHQ6IGJvbGQ7XG5cdFx0XHRjb2xvcjogd2hpdGU7XG5cdFx0XHRiYWNrZ3JvdW5kOiByZ2IoMTU0LCA3MCwgMTg3KTtcblx0XHRcdG1hcmdpbi1ib3R0b206IDhweDtcblx0XHRcdGJvcmRlci1yYWRpdXM6IDhweDtcblxuXHRcdFx0Ji1pbWFnZSB7XG5cdFx0XHRcdHBvc2l0aW9uOiBhYnNvbHV0ZTtcblx0XHRcdFx0dG9wOiAxM3B4O1xuXHRcdFx0XHRsZWZ0OiAxN3B4O1xuXG5cdFx0XHRcdHdpZHRoOiAzOHB4O1xuXHRcdFx0XHRoZWlnaHQ6IGF1dG87XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblx0Ji1pbmxpbmUtZXhwbGFpbmVyLWNhcmQge1xuXHRcdG1hcmdpbi1sZWZ0OiAxNnB4O1xuXHRcdG1hcmdpbi1yaWdodDogMTZweDtcblx0XHRwYWRkaW5nOiAxN3B4O1xuXHRcdGZvbnQtc2l6ZTogMTRweDtcblx0XHRmb250LXdlaWdodDogYm9sZDtcblx0XHRjb2xvcjogd2hpdGU7XG5cdFx0YmFja2dyb3VuZDogcmdiKDE1NCwgNzAsIDE4Nyk7XG5cdFx0bWFyZ2luLWJvdHRvbTogOHB4O1xuXHRcdGJvcmRlci1yYWRpdXM6IDhweDtcblx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XG5cdH1cblxuXHQmLWxpc3QtaXRlbSB7XG5cdFx0Ji1tZXNzYWdlIHtcblx0XHRcdHBhZGRpbmc6IDE2cHg7XG5cblx0XHRcdHAge1xuXHRcdFx0XHRmb250LXNpemU6IDE2cHggIWltcG9ydGFudDtcblx0XHRcdFx0Zm9udC13ZWlnaHQ6IGJvbGQgIWltcG9ydGFudDtcblx0XHRcdH1cblx0XHR9XG5cdH1cblxuXG5cblxuXHQvKiBQb3J0ZWQgU3R5bGVzIEZyb20gTWVzc2FnZSBJbmRleCAqL1xuXHQubWVzc2FnZS1pbmRleCB7XG5cdFx0Ji1pdGVtIHtcblxuXHRcdFx0d2lkdGg6IDEwMCU7XG5cdFx0XHRwYWRkaW5nLWJvdHRvbTogMTVweDtcblx0XHRcdHBhZGRpbmctdG9wOiAxNXB4O1xuXG5cdFx0XHQmLXJvdyB7XG5cdFx0XHRcdG1hcmdpbi1sZWZ0OiAxNnB4O1xuXHRcdFx0XHRtYXJnaW4tcmlnaHQ6IDE2cHg7XG5cblx0XHRcdFx0ZGlzcGxheTogZmxleDtcblxuXHRcdFx0XHQmLXJlcXVlc3QtaXRlbXMge1xuXHRcdFx0XHRcdHBhZGRpbmctdG9wOiAxNnB4O1xuXHRcdFx0XHR9XG5cdFx0XHR9XG5cblx0XHRcdCYtYnV0dG9uIHtcblx0XHRcdFx0ZGlzcGxheTogaW5saW5lLWJsb2NrO1xuXHRcdFx0XHR0ZXh0LWFsaWduOiBjZW50ZXI7XG5cdFx0XHRcdGJvcmRlci1yYWRpdXM6IDIwcHg7XG5cdFx0XHRcdGZvbnQtc2l6ZTogMTNweDtcblx0XHRcdFx0cGFkZGluZzogMTFweDtcblxuXHRcdFx0XHQmLWRlbGV0ZSB7XG5cdFx0XHRcdFx0YmFja2dyb3VuZDogcmdiYSgyMDgsIDIsIDI3LCAwLjEyKTtcblx0XHRcdFx0XHRjb2xvcjogcmdiKDE5OCwgOTksIDk5KTtcblx0XHRcdFx0XHR3aWR0aDogMTAycHg7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHQmLXZpZXcge1xuXHRcdFx0XHRcdGJhY2tncm91bmQ6IHJnYigxNTQsIDcwLCAxODcpO1xuXHRcdFx0XHRcdGNvbG9yOiB3aGl0ZTtcblx0XHRcdFx0XHR3aWR0aDogY2FsYygxMDAlIC0gMTAycHggLSAxNnB4KTtcblx0XHRcdFx0XHRtYXJnaW4tbGVmdDogMTZweDtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXG5cdFx0XHQmLWJhZGdlIHtcblx0XHRcdFx0ZGlzcGxheTogaW5saW5lLWJsb2NrO1xuXHRcdFx0XHRiYWNrZ3JvdW5kOiByZ2JhKDE1NCwgNzAsIDE4NywgMC4xNSk7XG5cdFx0XHRcdGNvbG9yOiByZ2IoMTU0LCA3MCwgMTg3KTtcblx0XHRcdFx0cGFkZGluZzogNHB4IDdweDtcblx0XHRcdFx0Zm9udC13ZWlnaHQ6IGJvbGQ7XG5cdFx0XHRcdHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG5cdFx0XHRcdGZvbnQtdmFyaWFudDogc21hbGwtY2Fwcztcblx0XHRcdFx0Zm9udC1zaXplOiAxMXB4O1xuXHRcdFx0fVxuXG5cdFx0XHQmLWltYWdlIHtcblx0XHRcdFx0ZGlzcGxheTogaW5saW5lLWJsb2NrO1xuXHRcdFx0XHR3aWR0aDogNjRweDtcblx0XHRcdH1cblxuXHRcdFx0Ji1jb250ZW50IHtcblx0XHRcdFx0ZGlzcGxheTogaW5saW5lLWJsb2NrO1xuXHRcdFx0XHR3aWR0aDogY2FsYygxMDAlIC0gNjRweCAtIDEzcHgpO1xuXHRcdFx0XHRtYXJnaW4tbGVmdDogMTNweDtcblxuXHRcdFx0XHRoMiB7XG5cdFx0XHRcdFx0bWFyZ2luLXRvcDogMHB4O1xuXHRcdFx0XHRcdG1hcmdpbi1ib3R0b206IDRweDtcblxuXHRcdFx0XHRcdHBhZGRpbmctdG9wOiA4cHg7XG5cblx0XHRcdFx0XHRmb250LXNpemU6IDE0cHg7XG5cdFx0XHRcdH1cblxuXHRcdFx0XHRwIHtcblx0XHRcdFx0XHRtYXJnaW4tdG9wOiAwcHg7XG5cdFx0XHRcdFx0bWFyZ2luLWJvdHRvbTogMHB4O1xuXG5cdFx0XHRcdFx0Zm9udC1zaXplOiAxNHB4O1xuXG5cdFx0XHRcdFx0b3BhY2l0eTogMC41NztcblxuXHRcdFx0XHRcdCYuc3Ryb25nIHtcblx0XHRcdFx0XHRcdG9wYWNpdHk6IDE7XG5cdFx0XHRcdFx0fVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblxuXG59XG5cbi53aG95b3UtbWVzc2FnZSB7XG5cdGJvcmRlci1yYWRpdXM6IDVweDtcblx0Ly8gcGFkZGluZzogNXB4O1xuXHQmLnRoZWlyLW1lc3NhZ2Uge1xuXHRcdGJhY2tncm91bmQ6ICNFOEU4RTggIWltcG9ydGFudDtcblx0fVxuXHQmLnlvdXItbWVzc2FnZSB7XG5cdFx0YmFja2dyb3VuZDogI0U4RThFOCAhaW1wb3J0YW50O1xuXHRcdGgyLCBwIHtcblx0XHRcdGNvbG9yOiByZ2IoMTU0LCA3MCwgMTg3KSAhaW1wb3J0YW50O1xuXHRcdH1cblx0fVxufSIsIi5tZXNzYWdlLXZpZXcge1xuICAvKiBQb3J0ZWQgU3R5bGVzIEZyb20gTWVzc2FnZSBJbmRleCAqL1xufVxuLm1lc3NhZ2Utdmlldy1leHBsYWluZXIge1xuICBwYWRkaW5nOiAxNnB4O1xufVxuLm1lc3NhZ2Utdmlldy1leHBsYWluZXItY2FyZCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgcGFkZGluZzogMTdweDtcbiAgcGFkZGluZy1sZWZ0OiA3MXB4O1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBjb2xvcjogd2hpdGU7XG4gIGJhY2tncm91bmQ6ICM5YTQ2YmI7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xufVxuLm1lc3NhZ2Utdmlldy1leHBsYWluZXItY2FyZC1pbWFnZSB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgdG9wOiAxM3B4O1xuICBsZWZ0OiAxN3B4O1xuICB3aWR0aDogMzhweDtcbiAgaGVpZ2h0OiBhdXRvO1xufVxuLm1lc3NhZ2Utdmlldy1pbmxpbmUtZXhwbGFpbmVyLWNhcmQge1xuICBtYXJnaW4tbGVmdDogMTZweDtcbiAgbWFyZ2luLXJpZ2h0OiAxNnB4O1xuICBwYWRkaW5nOiAxN3B4O1xuICBmb250LXNpemU6IDE0cHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBjb2xvcjogd2hpdGU7XG4gIGJhY2tncm91bmQ6ICM5YTQ2YmI7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbiAgYm9yZGVyLXJhZGl1czogOHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4ubWVzc2FnZS12aWV3LWxpc3QtaXRlbS1tZXNzYWdlIHtcbiAgcGFkZGluZzogMTZweDtcbn1cbi5tZXNzYWdlLXZpZXctbGlzdC1pdGVtLW1lc3NhZ2UgcCB7XG4gIGZvbnQtc2l6ZTogMTZweCAhaW1wb3J0YW50O1xuICBmb250LXdlaWdodDogYm9sZCAhaW1wb3J0YW50O1xufVxuLm1lc3NhZ2UtdmlldyAubWVzc2FnZS1pbmRleC1pdGVtIHtcbiAgd2lkdGg6IDEwMCU7XG4gIHBhZGRpbmctYm90dG9tOiAxNXB4O1xuICBwYWRkaW5nLXRvcDogMTVweDtcbn1cbi5tZXNzYWdlLXZpZXcgLm1lc3NhZ2UtaW5kZXgtaXRlbS1yb3cge1xuICBtYXJnaW4tbGVmdDogMTZweDtcbiAgbWFyZ2luLXJpZ2h0OiAxNnB4O1xuICBkaXNwbGF5OiBmbGV4O1xufVxuLm1lc3NhZ2UtdmlldyAubWVzc2FnZS1pbmRleC1pdGVtLXJvdy1yZXF1ZXN0LWl0ZW1zIHtcbiAgcGFkZGluZy10b3A6IDE2cHg7XG59XG4ubWVzc2FnZS12aWV3IC5tZXNzYWdlLWluZGV4LWl0ZW0tYnV0dG9uIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGJvcmRlci1yYWRpdXM6IDIwcHg7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgcGFkZGluZzogMTFweDtcbn1cbi5tZXNzYWdlLXZpZXcgLm1lc3NhZ2UtaW5kZXgtaXRlbS1idXR0b24tZGVsZXRlIHtcbiAgYmFja2dyb3VuZDogcmdiYSgyMDgsIDIsIDI3LCAwLjEyKTtcbiAgY29sb3I6ICNjNjYzNjM7XG4gIHdpZHRoOiAxMDJweDtcbn1cbi5tZXNzYWdlLXZpZXcgLm1lc3NhZ2UtaW5kZXgtaXRlbS1idXR0b24tdmlldyB7XG4gIGJhY2tncm91bmQ6ICM5YTQ2YmI7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgd2lkdGg6IGNhbGMoMTAwJSAtIDEwMnB4IC0gMTZweCk7XG4gIG1hcmdpbi1sZWZ0OiAxNnB4O1xufVxuLm1lc3NhZ2UtdmlldyAubWVzc2FnZS1pbmRleC1pdGVtLWJhZGdlIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBiYWNrZ3JvdW5kOiByZ2JhKDE1NCwgNzAsIDE4NywgMC4xNSk7XG4gIGNvbG9yOiAjOWE0NmJiO1xuICBwYWRkaW5nOiA0cHggN3B4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgZm9udC12YXJpYW50OiBzbWFsbC1jYXBzO1xuICBmb250LXNpemU6IDExcHg7XG59XG4ubWVzc2FnZS12aWV3IC5tZXNzYWdlLWluZGV4LWl0ZW0taW1hZ2Uge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHdpZHRoOiA2NHB4O1xufVxuLm1lc3NhZ2UtdmlldyAubWVzc2FnZS1pbmRleC1pdGVtLWNvbnRlbnQge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHdpZHRoOiBjYWxjKDEwMCUgLSA2NHB4IC0gMTNweCk7XG4gIG1hcmdpbi1sZWZ0OiAxM3B4O1xufVxuLm1lc3NhZ2UtdmlldyAubWVzc2FnZS1pbmRleC1pdGVtLWNvbnRlbnQgaDIge1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIG1hcmdpbi1ib3R0b206IDRweDtcbiAgcGFkZGluZy10b3A6IDhweDtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuLm1lc3NhZ2UtdmlldyAubWVzc2FnZS1pbmRleC1pdGVtLWNvbnRlbnQgcCB7XG4gIG1hcmdpbi10b3A6IDBweDtcbiAgbWFyZ2luLWJvdHRvbTogMHB4O1xuICBmb250LXNpemU6IDE0cHg7XG4gIG9wYWNpdHk6IDAuNTc7XG59XG4ubWVzc2FnZS12aWV3IC5tZXNzYWdlLWluZGV4LWl0ZW0tY29udGVudCBwLnN0cm9uZyB7XG4gIG9wYWNpdHk6IDE7XG59XG5cbi53aG95b3UtbWVzc2FnZSB7XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbn1cbi53aG95b3UtbWVzc2FnZS50aGVpci1tZXNzYWdlIHtcbiAgYmFja2dyb3VuZDogI0U4RThFOCAhaW1wb3J0YW50O1xufVxuLndob3lvdS1tZXNzYWdlLnlvdXItbWVzc2FnZSB7XG4gIGJhY2tncm91bmQ6ICNFOEU4RTggIWltcG9ydGFudDtcbn1cbi53aG95b3UtbWVzc2FnZS55b3VyLW1lc3NhZ2UgaDIsIC53aG95b3UtbWVzc2FnZS55b3VyLW1lc3NhZ2UgcCB7XG4gIGNvbG9yOiAjOWE0NmJiICFpbXBvcnRhbnQ7XG59Il19 */"

/***/ }),

/***/ "./src/app/message-view/message-view.page.ts":
/*!***************************************************!*\
  !*** ./src/app/message-view/message-view.page.ts ***!
  \***************************************************/
/*! exports provided: MessageViewPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessageViewPage", function() { return MessageViewPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/toast.service */ "./src/app/services/toast.service.ts");
/* harmony import */ var _services_navigation_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/navigation.service */ "./src/app/services/navigation.service.ts");
/* harmony import */ var _services_query_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/query.service */ "./src/app/services/query.service.ts");
/* harmony import */ var _services_bucket_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/bucket.service */ "./src/app/services/bucket.service.ts");
/* harmony import */ var _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/photo-viewer/ngx */ "./node_modules/@ionic-native/photo-viewer/ngx/index.js");
/* harmony import */ var _services_loading_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../services/loading.service */ "./src/app/services/loading.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");













const { Modals } = _capacitor_core__WEBPACK_IMPORTED_MODULE_12__["Plugins"];
let MessageViewPage = class MessageViewPage {
    constructor(route, router, authentication, toast, nav, query, location, photos, bucket, loading_service) {
        this.route = route;
        this.router = router;
        this.authentication = authentication;
        this.toast = toast;
        this.nav = nav;
        this.query = query;
        this.location = location;
        this.photos = photos;
        this.bucket = bucket;
        this.loading_service = loading_service;
        this.image_data = [];
        this.opposing_id = undefined;
        this.thread_id = undefined;
        this.thread_data = undefined;
        this.user_data = undefined;
        this.search_data = undefined;
        this.message_data = undefined;
        this.message_data_count = undefined;
        // public first_time_enable = false;
        this.first_time_send_message = true;
        this.form = {
            "content": "",
            "thread": undefined,
            "media_url": undefined
        };
        this.thread_id = this.route.snapshot.paramMap.get('id');
        this.form.thread = this.thread_id;
    }
    ngOnInit() {
        this.LoadInitialData();
    }
    LoadInitialData() {
        this.firstTimeLoadThreadData();
    }
    firstTimeLoadThreadData() {
        console.log("testing");
        this.query.request('messaging/threads/'.concat(this.thread_id), 'GET', {}).subscribe(results => {
            this.nav.messageRouteFlag.subscribe((flag) => {
                console.log("flggg", flag);
                if (flag === 'hello-message') {
                    this.thread_data = results['data'];
                    this.thread_data['is_accepted'] = true;
                    this.message_data = results['data'];
                    //this.LoadMessageData();
                    //this.LoadThreadData();
                }
                else {
                    this.thread_data = results['data'];
                    // this.thread_data['is_accepted'] = true;
                    this.message_data = results['data'];
                    this.LoadMessageData();
                    this.LoadThreadData();
                }
            });
            console.log('this.thread_data', this.thread_data);
        }, error => {
            this.toast.DisplaySimpleToast("Unable to load message thread.");
        });
    }
    LoadThreadData() {
        this.query.request('messaging/threads/'.concat(this.thread_id), 'GET', {}).subscribe(results => {
            console.log("all load data testing", results);
            this.thread_data = results['data'];
            this.LoadUserData();
            this.LoadSearchData();
            console.log('testing chat', this.thread_data);
            this.MarkThreadRead();
            //this.contentArea.scrollToBottom();
        }, error => {
            this.toast.DisplaySimpleToast("Unable to load message thread.");
        });
    }
    MarkThreadRead() {
        var body = { pk: this.thread_id };
        this.query.request('messaging/actions/read-thread', 'POST', {}, body).subscribe(results => {
            this.contentArea.scrollToBottom();
        }, error => { });
    }
    GoToOpposingUserProfile(owner) {
        if (owner && (owner == this.authentication.user.id))
            return;
        this.nav.NavigateForward('user/' + this.opposing_id, {
            "search_object": this.search_data,
            "user_id": this.opposing_id,
            "hide_aux_info": true
        });
    }
    LoadUserData() {
        for (let user_id of this.thread_data.participants) {
            if (user_id != this.authentication.user.id) {
                this.query.request('users/'.concat(user_id), 'GET', {}).subscribe(results => {
                    this.user_data = results['data'];
                    this.opposing_id = this.user_data['id'];
                    console.log('this.user_data', this.user_data);
                }, error => {
                    this.toast.DisplaySimpleToast("Unable to load user data.");
                });
            }
        }
    }
    LoadSearchData() {
        this.query.request('discovery/searches/'.concat(this.thread_data.search_origin), 'GET', {}).subscribe(results => {
            this.search_data = results['data'];
            //console.log('this.search_data', this.search_data);
            //this.LoadMessageData();
        }, error => {
            this.toast.DisplaySimpleToast("Unable to load search data.");
        });
    }
    LoadMessageData() {
        this.query.request('messaging/messages', 'GET', { "thread": this.thread_id, page_size: 10000 }).subscribe(results => {
            this.message_data = results['data'];
            this.message_data_count = results['meta'].count;
            console.log('this.message_data', this.message_data);
            //this.contentArea.scrollToBottom();
        }, error => {
            this.toast.DisplaySimpleToast("Unable to load messages.");
        });
    }
    SendMessage() {
        if (this.form.content && (this.form.content.length > 500)) {
            this.toast.DisplaySimpleToast("This message is too long.");
            return;
        }
        if (!this.form.content) {
            this.toast.DisplaySimpleToast("This message is too short.");
            return;
        }
        this.query.request('messaging/messages', 'POST', {}, this.form).subscribe(results => {
            this.loading_service.DismissLoader();
            this.form.content = "";
            this.form.media_url = undefined;
            this.LoadMessageData();
            this.LoadThreadData();
            // if (this.thread_data['is_accepted'] === true) {
            //     this.first_time_enable = false
            // }
        }, error => {
            this.loading_service.DismissLoader();
            this.toast.DisplaySimpleToast("Unable to send message.");
        });
        this.loading_service.PresentLoader("Sending...");
        // this.query.request(
        //     'messaging/messages', 'POST', {}, this.form
        // ).subscribe(
        //     results => {
        //         this.loading_service.DismissLoader();
        //         this.form.content = "";
        //         this.form.media_url = undefined;
        //         this.LoadMessageData();
        //     },
        //     error => {
        //         this.loading_service.DismissLoader();
        //         this.toast.DisplaySimpleToast(
        //             "Unable to send message."
        //         );
        //     }
        // );
    }
    MarkThreadAccepted() {
        this.query.request('messaging/threads/'.concat(this.thread_id), 'PATCH', {}, { "is_accepted": true }).subscribe(results => {
            this.thread_data['is_accepted'] = true;
            console.log('this.thread_data', this.thread_data);
        }, error => {
            this.toast.DisplaySimpleToast("Unable to accept message thread.");
        });
    }
    MarkThreadDeclined() {
        this.query.request('messaging/threads/'.concat(this.thread_id), 'DELETE', {}).subscribe(results => {
            this.location.back();
        }, error => {
            this.toast.DisplaySimpleToast("Unable to accept message thread.");
        });
    }
    UploadFiles() {
        this.loading_service.PresentLoader("Uploading...");
        this.bucket.UploadAndGetRemoteFileURL(this.files, 'profiles').then(image_url => {
            // this.files = undefined;
            console.log('image_url', image_url);
            this.form.media_url = image_url;
            this.loading_service.DismissLoader();
        });
    }
    ChangeListener($event) {
        this.files = $event.target.files[0];
        this.UploadFiles();
    }
    TriggerFileInput() {
        if (this.form.media_url) {
            this.ClearFileInput();
            return;
        }
        this.file_input.nativeElement.click();
    }
    ClearFileInput() {
        this.form.media_url = undefined;
        this.file_input.nativeElement.value = null;
    }
    FileIsImage(media_url) {
        return (media_url.match(/\.(jpeg|jpg|gif|png)$/) != null);
    }
    ShowImage(media_url) {
        this.photos.show(media_url);
    }
    MarkUserFlagged() {
        console.log('Block this user.');
        var body = { flaggee: this.opposing_id, flagger: this.authentication.user.id };
        this.query.request('profile/flags', 'POST', {}, body).subscribe(results => {
            this.nav.NavigateRoot('dashboard', {});
            this.toast.DisplaySimpleToast("This user has been blocked.");
        }, error => {
            this.toast.DisplaySimpleToast("Unable to block user.");
        });
    }
    DisplayActions() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            let promptRet = yield Modals.showActions({
                title: 'Message Options',
                message: 'Select an option to perform',
                options: [
                    {
                        title: 'Flag User'
                    },
                    {
                        title: 'Delete'
                    },
                    {
                        title: 'Cancel'
                    }
                ]
            });
            console.log('promptRet', promptRet);
            if (promptRet.index == 0 /*Flag*/) {
                this.MarkUserFlagged();
            }
            if (promptRet.index == 1 /*Delete*/) {
                this.MarkThreadDeclined();
            }
        });
    }
};
MessageViewPage.ctorParameters = () => [
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
    { type: _services_authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"] },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_4__["ToastService"] },
    { type: _services_navigation_service__WEBPACK_IMPORTED_MODULE_5__["NavigationService"] },
    { type: _services_query_service__WEBPACK_IMPORTED_MODULE_6__["QueryService"] },
    { type: _angular_common__WEBPACK_IMPORTED_MODULE_11__["Location"] },
    { type: _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_8__["PhotoViewer"] },
    { type: _services_bucket_service__WEBPACK_IMPORTED_MODULE_7__["BucketService"] },
    { type: _services_loading_service__WEBPACK_IMPORTED_MODULE_9__["LoadingService"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("file", { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], MessageViewPage.prototype, "file_input", void 0);
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("content", { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _ionic_angular__WEBPACK_IMPORTED_MODULE_10__["IonContent"])
], MessageViewPage.prototype, "contentArea", void 0);
MessageViewPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-message-view',
        template: __webpack_require__(/*! raw-loader!./message-view.page.html */ "./node_modules/raw-loader/index.js!./src/app/message-view/message-view.page.html"),
        styles: [__webpack_require__(/*! ./message-view.page.scss */ "./src/app/message-view/message-view.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
        _services_authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"],
        _services_toast_service__WEBPACK_IMPORTED_MODULE_4__["ToastService"],
        _services_navigation_service__WEBPACK_IMPORTED_MODULE_5__["NavigationService"],
        _services_query_service__WEBPACK_IMPORTED_MODULE_6__["QueryService"],
        _angular_common__WEBPACK_IMPORTED_MODULE_11__["Location"],
        _ionic_native_photo_viewer_ngx__WEBPACK_IMPORTED_MODULE_8__["PhotoViewer"],
        _services_bucket_service__WEBPACK_IMPORTED_MODULE_7__["BucketService"],
        _services_loading_service__WEBPACK_IMPORTED_MODULE_9__["LoadingService"]])
], MessageViewPage);



/***/ })

}]);
//# sourceMappingURL=message-view-message-view-module-es2015.js.map