(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["messages-messages-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/messages/messages.page.html":
/*!***********************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/messages/messages.page.html ***!
  \***********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content class=\"white-background message-index\">\n    <div class=\"common-header-spacer\"></div>\n    <div class=\"common-header\">\n        <ion-avatar slot=\"start\" [routerLink]=\"'/profile'\" routerDirection=\"forward\" class=\"common-header-avatar\">\n            <img [src]=\"image_data ? image_data.media_url : authentication.default_avatar\">\n        </ion-avatar>\n        <div class=\"common-header-title\">\n            Messages\n        </div>\n    </div>\n    <ion-list *ngIf=\"thread_data\">\n        <ng-container *ngFor=\"let this_thread of thread_data\">\n            <ion-item-sliding>\n                <ion-item>\n                    <div class=\"message-index-item\">\n                        <div class=\"message-index-item-row\" (click)=\"FlagRoute(this_thread)\">\n                            <div class=\"message-index-item-image\">\n                                <ion-avatar>\n                                    <img [src]=\"this_thread.profile_image\">\n                                </ion-avatar>\n                            </div>\n                            <div class=\"message-index-item-content\">\n                                <span *ngIf=\"!this_thread.is_accepted\" class=\"message-index-item-badge\">Connection Request</span>\n                                <h2 [ngClass]=\"this_thread.new_content ? 'strong' : ''\">{{this_thread.name}}</h2>\n                                <p [ngClass]=\"this_thread.new_content ? 'strong' : ''\">{{this_thread.latest_message}}</p>\n                            </div>\n                        </div>\n                        <div class=\"message-index-item-row message-index-item-row-request-items\" *ngIf=\"!this_thread.is_accepted\">\n                            <div class=\"message-index-item-button message-index-item-button-delete\" (click)=\"DeleteMessage(this_thread)\">\n                                Delete\n                            </div>\n                            <div class=\"message-index-item-button message-index-item-button-view\n                                        {{ this_thread.clicked ? 'is-clicked' : '' }}\" (click)=\"GoToMessageView(this_thread);\">\n                                View Message\n                            </div>\n                        </div>\n                    </div>\n                </ion-item>\n\n                <ion-item-options side=\"end\">\n                    <ion-item-option color=\"danger\" (click)=\"DeleteMessage(this_thread)\">Delete</ion-item-option>\n                </ion-item-options>\n            </ion-item-sliding>\n        </ng-container>\n\n        <ng-container *ngIf=\"!thread_data.length\">\n            <!-- No Messages Available -->\n            <div class=\"center-column\">\n                <div class=\"spacer\" style=\"height: 134px;\"></div>\n                <img src=\"/assets/girl_sitting.png\" class=\"graphic-image\" />\n                <h3 class=\"generic-h3\">There's no one here yet.</h3>\n                <p class=\"notice-paragraph\">\n                    <a [routerLink]=\"'/dashboard'\" routerDirection=\"root\">\n                        Search for something\n                    </a> and chat with someone who's into the same things as you!\n                </p>\n            </div>\n        </ng-container>\n\n    </ion-list>\n</ion-content>\n\n<ion-footer>\n    <ion-toolbar>\n        <ion-tabs>\n            <ion-tab-bar slot=\"bottom\" class=\"whoyou-tabs\">\n                <ion-tab-button [routerLink]=\"'/profile'\" routerDirection=\"root\" class=\"whoyou-tabs-item\">\n                    <ion-icon name=\"md-person\"></ion-icon>\n                </ion-tab-button>\n                <ion-tab-button [routerLink]=\"'/dashboard'\" routerDirection=\"root\" class=\"whoyou-tabs-item\">\n                    <ion-icon name=\"md-search\"></ion-icon>\n                </ion-tab-button>\n                <ion-tab-button [routerLink]=\"'/messages'\" routerDirection=\"root\" class=\"whoyou-tabs-item is-active\n                                       {{ isLoading ? 'is-big' : '' }}\">\n                    <ion-icon name=\"md-chatbubbles\"></ion-icon>\n                </ion-tab-button>\n            </ion-tab-bar>\n        </ion-tabs>\n    </ion-toolbar>\n</ion-footer>"

/***/ }),

/***/ "./src/app/messages/messages.module.ts":
/*!*********************************************!*\
  !*** ./src/app/messages/messages.module.ts ***!
  \*********************************************/
/*! exports provided: MessagesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagesPageModule", function() { return MessagesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _messages_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./messages.page */ "./src/app/messages/messages.page.ts");







var routes = [
    {
        path: '',
        component: _messages_page__WEBPACK_IMPORTED_MODULE_6__["MessagesPage"]
    }
];
var MessagesPageModule = /** @class */ (function () {
    function MessagesPageModule() {
    }
    MessagesPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_messages_page__WEBPACK_IMPORTED_MODULE_6__["MessagesPage"]]
        })
    ], MessagesPageModule);
    return MessagesPageModule;
}());



/***/ }),

/***/ "./src/app/messages/messages.page.scss":
/*!*********************************************!*\
  !*** ./src/app/messages/messages.page.scss ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "p.strong, h2.strong {\n  font-weight: bold;\n}\n\n.message-index-item {\n  width: 100%;\n  padding-bottom: 15px;\n  padding-top: 15px;\n}\n\n.message-index-item-row {\n  display: -webkit-box;\n  display: flex;\n}\n\n.message-index-item-row-request-items {\n  padding-top: 16px;\n}\n\n.message-index-item-button {\n  display: inline-block;\n  text-align: center;\n  border-radius: 20px;\n  font-size: 13px;\n  padding: 11px;\n  -webkit-transition: width 0.2s, margin-left 0.2s;\n  transition: width 0.2s, margin-left 0.2s;\n}\n\n.message-index-item-button.is-clicked {\n  width: calc(100% - 102px - 32px);\n  margin-left: 24px;\n}\n\n.message-index-item-button-delete {\n  background: rgba(208, 2, 27, 0.12);\n  color: #c66363;\n  width: 102px;\n}\n\n.message-index-item-button-view {\n  background: #9a46bb;\n  color: white;\n  width: calc(100% - 102px - 16px);\n  margin-left: 16px;\n}\n\n.message-index-item-badge {\n  display: inline-block;\n  background: rgba(154, 70, 187, 0.15);\n  color: #9a46bb;\n  padding: 4px 7px;\n  font-weight: bold;\n  text-transform: uppercase;\n  font-variant: small-caps;\n  font-size: 11px;\n}\n\n.message-index-item-image {\n  display: inline-block;\n  width: 64px;\n}\n\n.message-index-item-content {\n  display: inline-block;\n  width: calc(100% - 64px - 13px);\n  margin-left: 13px;\n}\n\n.message-index-item-content h2 {\n  margin-top: 0px;\n  margin-bottom: 4px;\n  padding-top: 8px;\n  font-size: 14px;\n}\n\n.message-index-item-content p {\n  margin-top: 0px;\n  margin-bottom: 0px;\n  font-size: 14px;\n  opacity: 0.57;\n}\n\n.message-index-item-content p.strong {\n  opacity: 1;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zaGFudGFtc2hhcm1hL0Rvd25sb2Fkcy93aG95b3Uvc3JjL2FwcC9tZXNzYWdlcy9tZXNzYWdlcy5wYWdlLnNjc3MiLCJzcmMvYXBwL21lc3NhZ2VzL21lc3NhZ2VzLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQTtFQUFzQixpQkFBQTtBQ0V0Qjs7QURDQztFQUVDLFdBQUE7RUFDQSxvQkFBQTtFQUNBLGlCQUFBO0FDQ0Y7O0FEQ0U7RUFDQyxvQkFBQTtFQUFBLGFBQUE7QUNDSDs7QURDRztFQUNDLGlCQUFBO0FDQ0o7O0FER0U7RUFDQyxxQkFBQTtFQUNBLGtCQUFBO0VBQ0EsbUJBQUE7RUFDQSxlQUFBO0VBQ0EsYUFBQTtFQUVBLGdEQUFBO0VBQUEsd0NBQUE7QUNGSDs7QURJRztFQUNDLGdDQUFBO0VBQ0csaUJBQUE7QUNGUDs7QURLRztFQUNDLGtDQUFBO0VBQ0EsY0FBQTtFQUNBLFlBQUE7QUNISjs7QURNRztFQUNDLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGdDQUFBO0VBQ0EsaUJBQUE7QUNKSjs7QURRRTtFQUNDLHFCQUFBO0VBQ0Esb0NBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxpQkFBQTtFQUNBLHlCQUFBO0VBQ0Esd0JBQUE7RUFDQSxlQUFBO0FDTkg7O0FEU0U7RUFDQyxxQkFBQTtFQUNBLFdBQUE7QUNQSDs7QURVRTtFQUNDLHFCQUFBO0VBQ0EsK0JBQUE7RUFDQSxpQkFBQTtBQ1JIOztBRFVHO0VBQ0MsZUFBQTtFQUNBLGtCQUFBO0VBRUEsZ0JBQUE7RUFFQSxlQUFBO0FDVko7O0FEYUc7RUFDQyxlQUFBO0VBQ0Esa0JBQUE7RUFFQSxlQUFBO0VBRUEsYUFBQTtBQ2JKOztBRGVJO0VBQ0MsVUFBQTtBQ2JMIiwiZmlsZSI6InNyYy9hcHAvbWVzc2FnZXMvbWVzc2FnZXMucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsicC5zdHJvbmcsIGgyLnN0cm9uZyB7IGZvbnQtd2VpZ2h0OiBib2xkOyB9XG5cbi5tZXNzYWdlLWluZGV4IHtcblx0Ji1pdGVtIHtcblxuXHRcdHdpZHRoOiAxMDAlO1xuXHRcdHBhZGRpbmctYm90dG9tOiAxNXB4O1xuXHRcdHBhZGRpbmctdG9wOiAxNXB4O1xuXG5cdFx0Ji1yb3cge1xuXHRcdFx0ZGlzcGxheTogZmxleDtcblxuXHRcdFx0Ji1yZXF1ZXN0LWl0ZW1zIHtcblx0XHRcdFx0cGFkZGluZy10b3A6IDE2cHg7XG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0Ji1idXR0b24ge1xuXHRcdFx0ZGlzcGxheTogaW5saW5lLWJsb2NrO1xuXHRcdFx0dGV4dC1hbGlnbjogY2VudGVyO1xuXHRcdFx0Ym9yZGVyLXJhZGl1czogMjBweDtcblx0XHRcdGZvbnQtc2l6ZTogMTNweDtcblx0XHRcdHBhZGRpbmc6IDExcHg7XG5cblx0XHRcdHRyYW5zaXRpb246IHdpZHRoIDAuMnMsIG1hcmdpbi1sZWZ0IDAuMnM7XG5cblx0XHRcdCYuaXMtY2xpY2tlZCB7XG5cdFx0XHRcdHdpZHRoOiBjYWxjKDEwMCUgLSAxMDJweCAtIDMycHgpO1xuICAgIFx0XHRcdG1hcmdpbi1sZWZ0OiAyNHB4O1xuXHRcdFx0fVxuXG5cdFx0XHQmLWRlbGV0ZSB7XG5cdFx0XHRcdGJhY2tncm91bmQ6IHJnYmEoMjA4LCAyLCAyNywgMC4xMik7XG5cdFx0XHRcdGNvbG9yOiByZ2IoMTk4LCA5OSwgOTkpO1xuXHRcdFx0XHR3aWR0aDogMTAycHg7XG5cdFx0XHR9XG5cblx0XHRcdCYtdmlldyB7XG5cdFx0XHRcdGJhY2tncm91bmQ6IHJnYigxNTQsIDcwLCAxODcpO1xuXHRcdFx0XHRjb2xvcjogd2hpdGU7XG5cdFx0XHRcdHdpZHRoOiBjYWxjKDEwMCUgLSAxMDJweCAtIDE2cHgpO1xuXHRcdFx0XHRtYXJnaW4tbGVmdDogMTZweDtcblx0XHRcdH1cblx0XHR9XG5cblx0XHQmLWJhZGdlIHtcblx0XHRcdGRpc3BsYXk6IGlubGluZS1ibG9jaztcblx0XHRcdGJhY2tncm91bmQ6IHJnYmEoMTU0LCA3MCwgMTg3LCAwLjE1KTtcblx0XHRcdGNvbG9yOiByZ2IoMTU0LCA3MCwgMTg3KTtcblx0XHRcdHBhZGRpbmc6IDRweCA3cHg7XG5cdFx0XHRmb250LXdlaWdodDogYm9sZDtcblx0XHRcdHRleHQtdHJhbnNmb3JtOiB1cHBlcmNhc2U7XG5cdFx0XHRmb250LXZhcmlhbnQ6IHNtYWxsLWNhcHM7XG5cdFx0XHRmb250LXNpemU6IDExcHg7XG5cdFx0fVxuXG5cdFx0Ji1pbWFnZSB7XG5cdFx0XHRkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG5cdFx0XHR3aWR0aDogNjRweDtcblx0XHR9XG5cblx0XHQmLWNvbnRlbnQge1xuXHRcdFx0ZGlzcGxheTogaW5saW5lLWJsb2NrO1xuXHRcdFx0d2lkdGg6IGNhbGMoMTAwJSAtIDY0cHggLSAxM3B4KTtcblx0XHRcdG1hcmdpbi1sZWZ0OiAxM3B4O1xuXG5cdFx0XHRoMiB7XG5cdFx0XHRcdG1hcmdpbi10b3A6IDBweDtcblx0XHRcdFx0bWFyZ2luLWJvdHRvbTogNHB4O1xuXG5cdFx0XHRcdHBhZGRpbmctdG9wOiA4cHg7XG5cblx0XHRcdFx0Zm9udC1zaXplOiAxNHB4O1xuXHRcdFx0fVxuXG5cdFx0XHRwIHtcblx0XHRcdFx0bWFyZ2luLXRvcDogMHB4O1xuXHRcdFx0XHRtYXJnaW4tYm90dG9tOiAwcHg7XG5cblx0XHRcdFx0Zm9udC1zaXplOiAxNHB4O1xuXG5cdFx0XHRcdG9wYWNpdHk6IDAuNTc7XG5cblx0XHRcdFx0Ji5zdHJvbmcge1xuXHRcdFx0XHRcdG9wYWNpdHk6IDE7XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHR9XG5cdH1cbn0iLCJwLnN0cm9uZywgaDIuc3Ryb25nIHtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG59XG5cbi5tZXNzYWdlLWluZGV4LWl0ZW0ge1xuICB3aWR0aDogMTAwJTtcbiAgcGFkZGluZy1ib3R0b206IDE1cHg7XG4gIHBhZGRpbmctdG9wOiAxNXB4O1xufVxuLm1lc3NhZ2UtaW5kZXgtaXRlbS1yb3cge1xuICBkaXNwbGF5OiBmbGV4O1xufVxuLm1lc3NhZ2UtaW5kZXgtaXRlbS1yb3ctcmVxdWVzdC1pdGVtcyB7XG4gIHBhZGRpbmctdG9wOiAxNnB4O1xufVxuLm1lc3NhZ2UtaW5kZXgtaXRlbS1idXR0b24ge1xuICBkaXNwbGF5OiBpbmxpbmUtYmxvY2s7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgYm9yZGVyLXJhZGl1czogMjBweDtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBwYWRkaW5nOiAxMXB4O1xuICB0cmFuc2l0aW9uOiB3aWR0aCAwLjJzLCBtYXJnaW4tbGVmdCAwLjJzO1xufVxuLm1lc3NhZ2UtaW5kZXgtaXRlbS1idXR0b24uaXMtY2xpY2tlZCB7XG4gIHdpZHRoOiBjYWxjKDEwMCUgLSAxMDJweCAtIDMycHgpO1xuICBtYXJnaW4tbGVmdDogMjRweDtcbn1cbi5tZXNzYWdlLWluZGV4LWl0ZW0tYnV0dG9uLWRlbGV0ZSB7XG4gIGJhY2tncm91bmQ6IHJnYmEoMjA4LCAyLCAyNywgMC4xMik7XG4gIGNvbG9yOiAjYzY2MzYzO1xuICB3aWR0aDogMTAycHg7XG59XG4ubWVzc2FnZS1pbmRleC1pdGVtLWJ1dHRvbi12aWV3IHtcbiAgYmFja2dyb3VuZDogIzlhNDZiYjtcbiAgY29sb3I6IHdoaXRlO1xuICB3aWR0aDogY2FsYygxMDAlIC0gMTAycHggLSAxNnB4KTtcbiAgbWFyZ2luLWxlZnQ6IDE2cHg7XG59XG4ubWVzc2FnZS1pbmRleC1pdGVtLWJhZGdlIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICBiYWNrZ3JvdW5kOiByZ2JhKDE1NCwgNzAsIDE4NywgMC4xNSk7XG4gIGNvbG9yOiAjOWE0NmJiO1xuICBwYWRkaW5nOiA0cHggN3B4O1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgdGV4dC10cmFuc2Zvcm06IHVwcGVyY2FzZTtcbiAgZm9udC12YXJpYW50OiBzbWFsbC1jYXBzO1xuICBmb250LXNpemU6IDExcHg7XG59XG4ubWVzc2FnZS1pbmRleC1pdGVtLWltYWdlIHtcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICB3aWR0aDogNjRweDtcbn1cbi5tZXNzYWdlLWluZGV4LWl0ZW0tY29udGVudCB7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgd2lkdGg6IGNhbGMoMTAwJSAtIDY0cHggLSAxM3B4KTtcbiAgbWFyZ2luLWxlZnQ6IDEzcHg7XG59XG4ubWVzc2FnZS1pbmRleC1pdGVtLWNvbnRlbnQgaDIge1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIG1hcmdpbi1ib3R0b206IDRweDtcbiAgcGFkZGluZy10b3A6IDhweDtcbiAgZm9udC1zaXplOiAxNHB4O1xufVxuLm1lc3NhZ2UtaW5kZXgtaXRlbS1jb250ZW50IHAge1xuICBtYXJnaW4tdG9wOiAwcHg7XG4gIG1hcmdpbi1ib3R0b206IDBweDtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBvcGFjaXR5OiAwLjU3O1xufVxuLm1lc3NhZ2UtaW5kZXgtaXRlbS1jb250ZW50IHAuc3Ryb25nIHtcbiAgb3BhY2l0eTogMTtcbn0iXX0= */"

/***/ }),

/***/ "./src/app/messages/messages.page.ts":
/*!*******************************************!*\
  !*** ./src/app/messages/messages.page.ts ***!
  \*******************************************/
/*! exports provided: MessagesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "MessagesPage", function() { return MessagesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/toast.service */ "./src/app/services/toast.service.ts");
/* harmony import */ var _services_navigation_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/navigation.service */ "./src/app/services/navigation.service.ts");
/* harmony import */ var _services_query_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/query.service */ "./src/app/services/query.service.ts");
/* harmony import */ var _services_loading_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/loading.service */ "./src/app/services/loading.service.ts");
/* harmony import */ var _ionic_native_badge_ngx__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @ionic-native/badge/ngx */ "./node_modules/@ionic-native/badge/ngx/index.js");









var MessagesPage = /** @class */ (function () {
    function MessagesPage(route, router, authentication, toast, nav, query, loading_service, badge) {
        var _this = this;
        this.route = route;
        this.router = router;
        this.authentication = authentication;
        this.toast = toast;
        this.nav = nav;
        this.query = query;
        this.loading_service = loading_service;
        this.badge = badge;
        this.thread_data = undefined;
        this.isLoading = true;
        this.image_data = [];
        setTimeout(function () {
            _this.isLoading = false;
        }, 200);
    }
    MessagesPage.prototype.ngOnInit = function () {
    };
    MessagesPage.prototype.ionViewWillEnter = function () {
        console.log(this.badge);
        this.badge.set(0);
        this.badge.clear();
        this.LoadInitialData();
    };
    MessagesPage.prototype.LoadInitialData = function () {
        this.LoadThreadData();
    };
    MessagesPage.prototype.LoadThreadData = function () {
        var _this = this;
        this.loading_service.PresentLoader("Loading...");
        this.query.request('messaging/threads', 'GET', { page_size: 10000 }).subscribe(function (results) {
            _this.loading_service.DismissLoader();
            console.log("load thread data results====>", results);
            _this.thread_data = [];
            results['data'].forEach(function (element) {
                if (element.messages.length > 0) {
                    // this.thread_data.push(element);
                    //element.messages['created_at'] = '';
                    _this.thread_data.push(element);
                }
            });
            //this.thread_data = results['data'];
            //this.thread_data.sort((a, b) => a.new_content ? -1 : 1);
            _this.thread_data.sort(function (a, b) {
                a.tempStamp = new Date(a.messages[a.messages.length - 1].created_at);
                b.tempStamp = new Date(b.messages[b.messages.length - 1].created_at);
                return b.tempStamp.getTime() - a.tempStamp.getTime();
            });
        }, function (error) {
            _this.toast.DisplaySimpleToast("Unable to load message threads.");
        });
    };
    MessagesPage.prototype.DeleteMessage = function (thread) {
        var _this = this;
        this.query.request('messaging/threads/'.concat(thread.id), 'DELETE', {}).subscribe(function (results) {
            _this.LoadThreadData();
        }, function (error) {
            _this.toast.DisplaySimpleToast("Unable to delete message thread.");
        });
    };
    MessagesPage.prototype.GoToMessageView = function (messageObject) {
        var _this = this;
        messageObject['clicked'] = true;
        this.nav.messageRouteFlag.next('view-message');
        setTimeout(function () {
            _this.nav.NavigateForward('message-view/' + messageObject.id, {});
            messageObject['clicked'] = false;
        }, 200);
    };
    MessagesPage.prototype.FlagRoute = function (message_flag) {
        this.router.navigateByUrl('/message-view/' + message_flag.id);
        this.nav.messageRouteFlag.next('view-message');
    };
    MessagesPage.ctorParameters = function () { return [
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
        { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] },
        { type: _services_authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"] },
        { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_4__["ToastService"] },
        { type: _services_navigation_service__WEBPACK_IMPORTED_MODULE_5__["NavigationService"] },
        { type: _services_query_service__WEBPACK_IMPORTED_MODULE_6__["QueryService"] },
        { type: _services_loading_service__WEBPACK_IMPORTED_MODULE_7__["LoadingService"] },
        { type: _ionic_native_badge_ngx__WEBPACK_IMPORTED_MODULE_8__["Badge"] }
    ]; };
    MessagesPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-messages',
            template: __webpack_require__(/*! raw-loader!./messages.page.html */ "./node_modules/raw-loader/index.js!./src/app/messages/messages.page.html"),
            styles: [__webpack_require__(/*! ./messages.page.scss */ "./src/app/messages/messages.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"],
            _services_authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"],
            _services_toast_service__WEBPACK_IMPORTED_MODULE_4__["ToastService"],
            _services_navigation_service__WEBPACK_IMPORTED_MODULE_5__["NavigationService"],
            _services_query_service__WEBPACK_IMPORTED_MODULE_6__["QueryService"],
            _services_loading_service__WEBPACK_IMPORTED_MODULE_7__["LoadingService"],
            _ionic_native_badge_ngx__WEBPACK_IMPORTED_MODULE_8__["Badge"]])
    ], MessagesPage);
    return MessagesPage;
}());



/***/ }),

/***/ "./src/app/services/toast.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/toast.service.ts ***!
  \*******************************************/
/*! exports provided: ToastService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToastService", function() { return ToastService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var ToastService = /** @class */ (function () {
    function ToastService(toast_controller) {
        this.toast_controller = toast_controller;
    }
    ToastService.prototype.DisplaySimpleToast = function (message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toast_controller.create({
                            "message": message, "duration": 2000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    ToastService.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
    ]; };
    ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
    ], ToastService);
    return ToastService;
}());



/***/ })

}]);
//# sourceMappingURL=messages-messages-module-es5.js.map