(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["dashboard-dashboard-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/dashboard/dashboard.page.html":
/*!*************************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/dashboard/dashboard.page.html ***!
  \*************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content scroll-y=\"false\">\n    <div class=\"normal-background\"></div>\n\n    <div class=\"fix-z\">\n        <div class=\"common-header is-dashboard-header\">\n            <ion-avatar slot=\"start\" [routerLink]=\"'/profile'\" routerDirection=\"forward\" class=\"common-header-avatar\">\n                <img [src]=\"image_data ? image_data.media_url : authentication.default_avatar\">\n            </ion-avatar>\n            <div class=\"common-header-title\" [routerLink]=\"'/profile'\" routerDirection=\"forward\">\n                {{authentication.user ? authentication.user.company_name : ''}}\n            </div>\n            <div class=\"common-header-icon\">\n                <ion-icon name=\"md-people\" slot=\"end\" (click)=\"ShareApp();\">\n                </ion-icon>\n            </div>\n        </div>\n\n        <div class=\"flag-image\">\n            <img src=\"/assets/whoyou-logo.png\" alt=\"\" style=\"margin-top: 10px; max-height: 85px;\" />\n        </div>\n        <div class=\"whoyou-search whoyou-background-above\">\n            <ion-searchbar placeholder=\"Search for anything\" (click)=\"OpenAdvancedSearch();\" autocomplete=\"off\" #myInput></ion-searchbar>\n        </div>\n        <!-- <div class=\"whoyou-search whoyou-background-above\">\n            <ion-searchbar debounce=\"1500\" placeholder=\"Search for anything\" (click)=\"OpenAdvancedSearch();\" autocomplete=\"off\" #myInput></ion-searchbar>\n        </div> -->\n\n        <div class=\"padding-normal\" style=\"padding-top: 0px;\">\n            <div class=\"whoyou-row\">\n                <h2 class=\"generic-h2\">Your Past Searches</h2>\n                <a class=\"whoyou-row-button\" [routerLink]=\"'/search-history'\" routerDirection=\"forward\">\n                    Manage\n                </a>\n            </div>\n\n            <div class=\"whoyou-past-search-scroller\">\n                <div class=\"whoyou-past-search-scroller-item\n                            {{ thisSearch.clicked ? 'is-clicked' : '' }}\" *ngFor=\"let thisSearch of past_searches\" (click)=\"PerformSearchOfPhrase(thisSearch.phrase, thisSearch);\">\n                    {{ thisSearch.phrase }}\n                </div>\n            </div>\n        </div>\n    </div>\n</ion-content>\n<ion-content scroll-y=\"true\">\n    <div style=\"padding: 0 24px;\">\n        <h2 class=\"generic-h2\">Trending Searches In Your Area</h2>\n        <div class=\"whoyou-phrase-grid\">\n            <div class=\"whoyou-phrase-grid-item\n                {{ this_result.clicked ? 'is-clicked' : '' }}\" *ngFor=\"let this_result of local_searches\" (click)=\"PerformSearchOfPhrase(this_result.phrase, this_result);\">\n                {{this_result.phrase}}\n            </div>\n            <div class=\"whoyou-phrase-grid-item\" *ngIf=\"!local_searches.length\" (click)=\"PerformSearchOfPhrase('sports');\">\n                Sports\n            </div>\n        </div>\n    </div>\n</ion-content>\n\n<ion-footer>\n    <ion-toolbar>\n        <ion-tabs>\n            <ion-tab-bar slot=\"bottom\" class=\"whoyou-tabs\">\n                <ion-tab-button [routerLink]=\"'/profile'\" routerDirection=\"root\" class=\"whoyou-tabs-item\">\n                    <ion-icon name=\"md-person\"></ion-icon>\n                </ion-tab-button>\n                <ion-tab-button [routerLink]=\"'/dashboard'\" routerDirection=\"root\" class=\"whoyou-tabs-item is-active\n                                       {{ isLoading ? 'is-big' : '' }}\">\n                    <ion-icon name=\"md-search\"></ion-icon>\n                </ion-tab-button>\n                <ion-tab-button [routerLink]=\"'/messages'\" routerDirection=\"root\" class=\"whoyou-tabs-item\">\n                    <ion-icon name=\"md-chatbubbles\"></ion-icon>\n                </ion-tab-button>\n            </ion-tab-bar>\n        </ion-tabs>\n    </ion-toolbar>\n</ion-footer>"

/***/ }),

/***/ "./src/app/dashboard/dashboard.module.ts":
/*!***********************************************!*\
  !*** ./src/app/dashboard/dashboard.module.ts ***!
  \***********************************************/
/*! exports provided: DashboardPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardPageModule", function() { return DashboardPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm5/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm5/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm5/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _dashboard_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./dashboard.page */ "./src/app/dashboard/dashboard.page.ts");







var routes = [
    {
        path: '',
        component: _dashboard_page__WEBPACK_IMPORTED_MODULE_6__["DashboardPage"]
    }
];
var DashboardPageModule = /** @class */ (function () {
    function DashboardPageModule() {
    }
    DashboardPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
            imports: [
                _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
                _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
                _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
            ],
            declarations: [_dashboard_page__WEBPACK_IMPORTED_MODULE_6__["DashboardPage"]]
        })
    ], DashboardPageModule);
    return DashboardPageModule;
}());



/***/ }),

/***/ "./src/app/dashboard/dashboard.page.scss":
/*!***********************************************!*\
  !*** ./src/app/dashboard/dashboard.page.scss ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = ".dashboard-background {\n  --background: -webkit-linear-gradient(top, #a740c2 0%,#a740c2 50%,#ffffff 52%,#ffffff 100%) !important;\n}\n\n.whoyou-fancy-header img {\n  height: 45px;\n}\n\n.whoyou-fancy-header span {\n  position: relative;\n  top: -12px;\n  display: inline-block;\n  padding-left: 5px;\n  font-weight: bold;\n}\n\n.user-profile-avatar {\n  height: 200px !important;\n  width: 200px !important;\n}\n\n.user-profile-card {\n  margin-top: -70px !important;\n  padding-top: 70px !important;\n}\n\n.dash-button {\n  margin-left: 16px;\n  margin-right: 16px;\n  margin-bottom: 8px;\n}\n\n.transparent-card {\n  background: transparent !important;\n  box-shadow: none !important;\n}\n\n.transparent-card:before, .transparent-card:after {\n  background: transparent !important;\n}\n\n.visible-title {\n  font-size: 32px !important;\n}\n\n.visible-title, .visible-action {\n  color: #FFFFFF !important;\n  font-weight: bold;\n  text-shadow: rgba(0, 0, 0, 0.6) 2px 2px 2px;\n}\n\n.message-pip {\n  width: 12px;\n  background: red;\n  height: 12px;\n  border-radius: 50%;\n  position: absolute;\n  left: 3px;\n  top: 3px;\n  box-shadow: 0px 0px 2px rgba(0, 0, 1, 0.6);\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9zaGFudGFtc2hhcm1hL0Rvd25sb2Fkcy93aG95b3Uvc3JjL2FwcC9kYXNoYm9hcmQvZGFzaGJvYXJkLnBhZ2Uuc2NzcyIsInNyYy9hcHAvZGFzaGJvYXJkL2Rhc2hib2FyZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDQyxzR0FBQTtBQ0NEOztBREdDO0VBQ0MsWUFBQTtBQ0FGOztBREVDO0VBQ0Msa0JBQUE7RUFDQSxVQUFBO0VBQ0EscUJBQUE7RUFDRyxpQkFBQTtFQUNBLGlCQUFBO0FDQUw7O0FESUE7RUFDQyx3QkFBQTtFQUNBLHVCQUFBO0FDREQ7O0FER0E7RUFDQyw0QkFBQTtFQUNBLDRCQUFBO0FDQUQ7O0FER0E7RUFDQyxpQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUNBRDs7QURHQTtFQUNDLGtDQUFBO0VBQ0EsMkJBQUE7QUNBRDs7QURDQztFQUNDLGtDQUFBO0FDQ0Y7O0FER0E7RUFDQywwQkFBQTtBQ0FEOztBREVBO0VBQ0MseUJBQUE7RUFDQSxpQkFBQTtFQUNBLDJDQUFBO0FDQ0Q7O0FERUE7RUFDQyxXQUFBO0VBQ0csZUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLFFBQUE7RUFDQSwwQ0FBQTtBQ0NKIiwiZmlsZSI6InNyYy9hcHAvZGFzaGJvYXJkL2Rhc2hib2FyZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuZGFzaGJvYXJkLWJhY2tncm91bmQge1xuXHQtLWJhY2tncm91bmQ6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KHRvcCwgI2E3NDBjMiAwJSwjYTc0MGMyIDUwJSwjZmZmZmZmIDUyJSwjZmZmZmZmIDEwMCUpICFpbXBvcnRhbnQ7XG59XG5cbi53aG95b3UtZmFuY3ktaGVhZGVyIHtcblx0aW1nIHtcblx0XHRoZWlnaHQ6IDQ1cHg7XG5cdH1cblx0c3BhbiB7XG5cdFx0cG9zaXRpb246IHJlbGF0aXZlO1xuXHRcdHRvcDogLTEycHg7XG5cdFx0ZGlzcGxheTogaW5saW5lLWJsb2NrO1xuICAgIFx0cGFkZGluZy1sZWZ0OiA1cHg7XG4gICAgXHRmb250LXdlaWdodDogYm9sZDtcblx0fVxufVxuXG4udXNlci1wcm9maWxlLWF2YXRhciB7XG5cdGhlaWdodDogMjAwcHggIWltcG9ydGFudDtcblx0d2lkdGg6IDIwMHB4ICFpbXBvcnRhbnQ7XG59XG4udXNlci1wcm9maWxlLWNhcmQge1xuXHRtYXJnaW4tdG9wOiAtNzBweCAhaW1wb3J0YW50O1xuXHRwYWRkaW5nLXRvcDogNzBweCAhaW1wb3J0YW50O1xufVxuXG4uZGFzaC1idXR0b24ge1xuXHRtYXJnaW4tbGVmdDogMTZweDtcblx0bWFyZ2luLXJpZ2h0OiAxNnB4O1xuXHRtYXJnaW4tYm90dG9tOiA4cHg7XG59XG5cbi50cmFuc3BhcmVudC1jYXJkIHtcblx0YmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcblx0Ym94LXNoYWRvdzogbm9uZSAhaW1wb3J0YW50O1xuXHQmOmJlZm9yZSwgJjphZnRlciB7XG5cdFx0YmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcblx0fVxufVxuXG4udmlzaWJsZS10aXRsZSB7XG5cdGZvbnQtc2l6ZTogMzJweCAhaW1wb3J0YW50O1xufVxuLnZpc2libGUtdGl0bGUsIC52aXNpYmxlLWFjdGlvbiB7XG5cdGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XG5cdGZvbnQtd2VpZ2h0OiBib2xkO1xuXHR0ZXh0LXNoYWRvdzogcmdiYSgwLDAsMCwwLjYpIDJweCAycHggMnB4O1xufVxuXG4ubWVzc2FnZS1waXAge1xuXHR3aWR0aDogMTJweDtcbiAgICBiYWNrZ3JvdW5kOiByZWQ7XG4gICAgaGVpZ2h0OiAxMnB4O1xuICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gICAgbGVmdDogM3B4O1xuICAgIHRvcDogM3B4O1xuICAgIGJveC1zaGFkb3c6IDBweCAwcHggMnB4IHJnYmEoMCwwLDEsMC42KTtcbn0iLCIuZGFzaGJvYXJkLWJhY2tncm91bmQge1xuICAtLWJhY2tncm91bmQ6IC13ZWJraXQtbGluZWFyLWdyYWRpZW50KHRvcCwgI2E3NDBjMiAwJSwjYTc0MGMyIDUwJSwjZmZmZmZmIDUyJSwjZmZmZmZmIDEwMCUpICFpbXBvcnRhbnQ7XG59XG5cbi53aG95b3UtZmFuY3ktaGVhZGVyIGltZyB7XG4gIGhlaWdodDogNDVweDtcbn1cbi53aG95b3UtZmFuY3ktaGVhZGVyIHNwYW4ge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHRvcDogLTEycHg7XG4gIGRpc3BsYXk6IGlubGluZS1ibG9jaztcbiAgcGFkZGluZy1sZWZ0OiA1cHg7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xufVxuXG4udXNlci1wcm9maWxlLWF2YXRhciB7XG4gIGhlaWdodDogMjAwcHggIWltcG9ydGFudDtcbiAgd2lkdGg6IDIwMHB4ICFpbXBvcnRhbnQ7XG59XG5cbi51c2VyLXByb2ZpbGUtY2FyZCB7XG4gIG1hcmdpbi10b3A6IC03MHB4ICFpbXBvcnRhbnQ7XG4gIHBhZGRpbmctdG9wOiA3MHB4ICFpbXBvcnRhbnQ7XG59XG5cbi5kYXNoLWJ1dHRvbiB7XG4gIG1hcmdpbi1sZWZ0OiAxNnB4O1xuICBtYXJnaW4tcmlnaHQ6IDE2cHg7XG4gIG1hcmdpbi1ib3R0b206IDhweDtcbn1cblxuLnRyYW5zcGFyZW50LWNhcmQge1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xuICBib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XG59XG4udHJhbnNwYXJlbnQtY2FyZDpiZWZvcmUsIC50cmFuc3BhcmVudC1jYXJkOmFmdGVyIHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbn1cblxuLnZpc2libGUtdGl0bGUge1xuICBmb250LXNpemU6IDMycHggIWltcG9ydGFudDtcbn1cblxuLnZpc2libGUtdGl0bGUsIC52aXNpYmxlLWFjdGlvbiB7XG4gIGNvbG9yOiAjRkZGRkZGICFpbXBvcnRhbnQ7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB0ZXh0LXNoYWRvdzogcmdiYSgwLCAwLCAwLCAwLjYpIDJweCAycHggMnB4O1xufVxuXG4ubWVzc2FnZS1waXAge1xuICB3aWR0aDogMTJweDtcbiAgYmFja2dyb3VuZDogcmVkO1xuICBoZWlnaHQ6IDEycHg7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBsZWZ0OiAzcHg7XG4gIHRvcDogM3B4O1xuICBib3gtc2hhZG93OiAwcHggMHB4IDJweCByZ2JhKDAsIDAsIDEsIDAuNik7XG59Il19 */"

/***/ }),

/***/ "./src/app/dashboard/dashboard.page.ts":
/*!*********************************************!*\
  !*** ./src/app/dashboard/dashboard.page.ts ***!
  \*********************************************/
/*! exports provided: DashboardPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DashboardPage", function() { return DashboardPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/toast.service */ "./src/app/services/toast.service.ts");
/* harmony import */ var _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/navigation.service */ "./src/app/services/navigation.service.ts");
/* harmony import */ var _services_query_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/query.service */ "./src/app/services/query.service.ts");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/fesm5/platform-browser.js");
/* harmony import */ var _services_loading_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../services/loading.service */ "./src/app/services/loading.service.ts");
/* harmony import */ var _services_push_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/push.service */ "./src/app/services/push.service.ts");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");










var Geolocation = _capacitor_core__WEBPACK_IMPORTED_MODULE_9__["Plugins"].Geolocation;
var Share = _capacitor_core__WEBPACK_IMPORTED_MODULE_9__["Plugins"].Share;
var DashboardPage = /** @class */ (function () {
    function DashboardPage(authentication, toast, nav, query, sanitization, loading_service, push_service) {
        var _this = this;
        this.authentication = authentication;
        this.toast = toast;
        this.nav = nav;
        this.query = query;
        this.sanitization = sanitization;
        this.loading_service = loading_service;
        this.push_service = push_service;
        this.image_data = undefined;
        this.search_string = "";
        this.count = 0;
        this.recommended_search = "";
        this.local_searches = [];
        this.past_searches = [];
        this.filtered_recommendations = [
            "Ass", "shit", "fuck", "fucker", "faggot", "anal", "vagina", "cunt",
            "pussy", "nigger", "nigga", "queer", "kike", "spic", "wetback",
            "pterolytics", "bitch", "whore", "slut", "penis", "asshole",
            "diarrhea", "vomit", "piss", "puss", "zit", "tits", "boobs", "butt",
            "kinky", "dildo", "scissoring", "blowjob", "handjob", "fingering",
            "rape", "sodomy", "pedophile", "pedophilia", "necrophile", "necrophilia",
            "zoophile", "bestiality", "porn", "pornography", "sex", "fag", "poon",
            "chlamydia", "AIDS", "HIV", "gonorrhea", "syphilis", "genital", "HPV",
            "warts", "herpes", "meth", "methamphetamine", "codeine", "cocaine",
            "heroin", "LSD", "krokodil", "ketamine", "piss", "cocksucker",
            "motherfucker", "anus", "poo", "poop", "pee", "cum", "semen",
            "testicles", "cock", "scrotum", "labia", "feces", "Ku Klux Klan",
            "Al Qaeda", "muhajideen", "jihad", "Nazi", "murder", "killing",
            "prostitute", "prostitution", "stripper", "virgin", "sadism",
            "masochism", "S&M", "ketamine", "weed", "blow", "cocaine",
            "dirty sanchez", "hentai", "tiddies", "titties", "big tiddies",
            "dick", "tentacle porn", "porn"
        ];
        this.isLoading = true;
        this.InitializeRecommendedSearch();
        push_service.RegisterPushNotifications();
        this.CountUnreadThreads();
        this.LoadSearchHistory();
        setTimeout(function () {
            _this.isLoading = false;
        }, 200);
    }
    DashboardPage.prototype.ngOnInit = function () { };
    DashboardPage.prototype.ionViewWillEnter = function () {
        this.LoadImageList();
        this.CountUnreadThreads();
        this.UpdateForbiddenWords();
    };
    DashboardPage.prototype.OpenAdvancedSearch = function () {
        this.myInput.getInputElement().then(function (data) {
            data.disabled = true;
        });
        this.nav.NavigateForward('advanced-search', {});
        // setTimeout(() => {
        //     this.myInput.value = "";
        // }, 500);
    };
    DashboardPage.prototype.CountUnreadThreads = function () {
        var _this = this;
        this.query.request('messaging/actions/count-threads', 'POST', {}, {}).subscribe(function (results) {
            _this.count = results['data']['count'];
            console.log('this.count', _this.count);
        }, function (error) { });
    };
    DashboardPage.prototype.LoadSearchHistory = function () {
        var _this = this;
        this.query.request('discovery/searches', 'GET', {
            user: this.authentication.user['id'],
            page_size: 10000
        }).subscribe(function (searches) {
            _this.past_searches = searches['data'];
        }, function (error) {
            _this.toast.DisplaySimpleToast("Unable to load search history.");
        });
    };
    DashboardPage.prototype.PerformSearch = function ($event) {
        this.search_string = $event.target.value;
        this.search_string = this.search_string.replace(/[^\w\s\'\"\-]/gi, '');
        // this.loading_service.PresentLoader("Searching...");
        this.nav.NavigateForward('search/' + this.search_string, { "search_string": this.search_string });
    };
    DashboardPage.prototype.PerformSearchOfPhrase = function (phrase, searchItem) {
        var _this = this;
        searchItem['clicked'] = true;
        setTimeout(function () {
            _this.nav.NavigateForward('search/' + phrase, { "search_string": phrase });
            searchItem['clicked'] = false;
        }, 200);
    };
    DashboardPage.prototype.PerformRecommendedSearch = function () {
        this.search_string = this.recommended_search;
        // this.loading_service.PresentLoader("Searching...");
        this.nav.NavigateForward('search/' + this.search_string, { "search_string": this.search_string });
    };
    DashboardPage.prototype.MoveToBlankSearch = function () {
        this.search_string = "";
        // this.loading_service.PresentLoader("Searching...");
        this.nav.NavigateForward('search/' + this.search_string, { "search_string": this.search_string });
    };
    DashboardPage.prototype.LoadImageList = function () {
        var _this = this;
        this.query.request('profile/photos', 'GET', {
            "user": this.authentication.user.id,
            "is_featured": true
        }).subscribe(function (results) {
            var image_list = results['data'];
            _this.image_data = undefined;
            image_list.forEach(function (item) {
                if (item.is_featured)
                    _this.image_data = item;
            });
            // TODO - Remove this console statement.
            console.log('this.image_data', _this.image_data);
        }, function (error) {
            _this.toast.DisplaySimpleToast("Unable to load photos.");
        });
    };
    DashboardPage.prototype.InitializeRecommendedSearch = function () {
        this.UpdateForbiddenWords();
    };
    //'https://api.jsonbin.io/b/5f43d7244d8ce411137fc20f/latest',
    DashboardPage.prototype.UpdateForbiddenWords = function () {
        var _this = this;
        this.query.request('discovery/bad-words', 'GET', {}).subscribe(function (results) {
            console.log('results', results);
            _this.filtered_recommendations = _this.filtered_recommendations.concat(results['words']);
            //console.log('this.filtered_recommendations', this.filtered_recommendations);
            _this.CreateSearchAndGetResults();
        }, function (error) {
            _this.toast.DisplaySimpleToast("Unable to update forbidden words.");
            _this.CreateSearchAndGetResults();
        });
    };
    DashboardPage.prototype.CreateSearchAndGetResults = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var coordinates;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, Geolocation.getCurrentPosition()];
                    case 1:
                        coordinates = _a.sent();
                        //const coordinates = {coords:{latitude:24.204100,longitude:83.024300}};
                        this.GetNearbySearches(coordinates);
                        return [2 /*return*/];
                }
            });
        });
    };
    DashboardPage.prototype.GetNearbySearches = function (coordinates) {
        var _this = this;
        this.recommended_search = undefined;
        var query_params = {
            "latitude": coordinates.coords.latitude,
            "longitude": coordinates.coords.longitude
        };
        var deletedWord = [];
        this.query.request('discovery/bad-words', 'GET', {}).subscribe(function (results) {
            console.log("results@@@@@@@@", results);
            deletedWord = results['words'];
            for (var i = 0; i < deletedWord.length; i++) {
                deletedWord[i] = deletedWord[i].toLowerCase();
            }
            _this.query.request('discovery/nearby-searches', 'GET', query_params).subscribe(function (results) {
                console.log("&&&&&&&&&&", results);
                _this.local_searches = [];
                if (results['data'] && results['data'].length) {
                    for (var i = 0; i < results['data'].length; i++) {
                        if (deletedWord.indexOf(results['data'][i].phrase.toLowerCase()) === -1) {
                            _this.local_searches.push(results['data'][i]);
                        }
                    }
                    _this.recommended_search = _this.local_searches[0]['phrase'];
                }
                console.log('recommended_search', _this.recommended_search);
            }, function (error) {
                _this.toast.DisplaySimpleToast("Unable to load nearby results.");
            });
        });
    };
    DashboardPage.prototype.ShareApp = function () {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var shareRet;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, Share.share({
                            title: 'Share WhoYou',
                            text: 'WhoYou is best experienced with friends. Share the app now!',
                            url: 'https://www.whoyouapp.com/',
                            dialogTitle: 'Share WhoYou'
                        })];
                    case 1:
                        shareRet = _a.sent();
                        return [2 /*return*/];
                }
            });
        });
    };
    DashboardPage.ctorParameters = function () { return [
        { type: _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] },
        { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"] },
        { type: _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"] },
        { type: _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"] },
        { type: _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"] },
        { type: _services_loading_service__WEBPACK_IMPORTED_MODULE_7__["LoadingService"] },
        { type: _services_push_service__WEBPACK_IMPORTED_MODULE_8__["PushService"] }
    ]; };
    tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])('myInput', { static: false }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", Object)
    ], DashboardPage.prototype, "myInput", void 0);
    DashboardPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
            selector: 'app-dashboard',
            template: __webpack_require__(/*! raw-loader!./dashboard.page.html */ "./node_modules/raw-loader/index.js!./src/app/dashboard/dashboard.page.html"),
            styles: [__webpack_require__(/*! ./dashboard.page.scss */ "./src/app/dashboard/dashboard.page.scss")]
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"],
            _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"],
            _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"],
            _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"],
            _angular_platform_browser__WEBPACK_IMPORTED_MODULE_6__["DomSanitizer"],
            _services_loading_service__WEBPACK_IMPORTED_MODULE_7__["LoadingService"],
            _services_push_service__WEBPACK_IMPORTED_MODULE_8__["PushService"]])
    ], DashboardPage);
    return DashboardPage;
}());



/***/ }),

/***/ "./src/app/services/push.service.ts":
/*!******************************************!*\
  !*** ./src/app/services/push.service.ts ***!
  \******************************************/
/*! exports provided: PushService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PushService", function() { return PushService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _capacitor_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @capacitor/core */ "./node_modules/@capacitor/core/dist/esm/index.js");
/* harmony import */ var _authentication_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./authentication.service */ "./src/app/services/authentication.service.ts");




var PushNotifications = _capacitor_core__WEBPACK_IMPORTED_MODULE_2__["Plugins"].PushNotifications;
var PushService = /** @class */ (function () {
    function PushService(authentication) {
        this.authentication = authentication;
        this.registered = false;
    }
    PushService.prototype.RegisterPushNotifications = function () {
        var _this = this;
        if (this.registered) {
            console.log('Push Notifications already registered!');
            return;
        }
        console.log('Registering Push Notifications');
        // Register with Apple / Google to receive push via APNS/FCM
        PushNotifications.register();
        // On success, we should be able to receive notifications
        PushNotifications.addListener('registration', function (token) {
            console.log('Push registration success, token: ' + token.value);
            _this.UpdateUserToken(token.value);
        });
        // Some issue with our setup and push will not work
        PushNotifications.addListener('registrationError', function (error) {
            console.log('Error on registration: ' + JSON.stringify(error));
        });
        // Show us the notification payload if the app is open on our device
        PushNotifications.addListener('pushNotificationReceived', function (notification) {
            console.log('Push received: ' + JSON.stringify(notification));
        });
        // Method called when tapping on a notification
        PushNotifications.addListener('pushNotificationActionPerformed', function (notification) {
            console.log('Push action performed: ' + JSON.stringify(notification));
        });
        this.registered = true;
    };
    PushService.prototype.UpdateUserToken = function (token) {
        console.log("test token", token);
        this.authentication.UpdateSetting('fcm_token', token);
    };
    PushService.ctorParameters = function () { return [
        { type: _authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"] }
    ]; };
    PushService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_authentication_service__WEBPACK_IMPORTED_MODULE_3__["AuthenticationService"]])
    ], PushService);
    return PushService;
}());



/***/ }),

/***/ "./src/app/services/toast.service.ts":
/*!*******************************************!*\
  !*** ./src/app/services/toast.service.ts ***!
  \*******************************************/
/*! exports provided: ToastService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ToastService", function() { return ToastService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm5/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");



var ToastService = /** @class */ (function () {
    function ToastService(toast_controller) {
        this.toast_controller = toast_controller;
    }
    ToastService.prototype.DisplaySimpleToast = function (message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function () {
            var toast;
            return tslib__WEBPACK_IMPORTED_MODULE_0__["__generator"](this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.toast_controller.create({
                            "message": message, "duration": 2000
                        })];
                    case 1:
                        toast = _a.sent();
                        toast.present();
                        return [2 /*return*/];
                }
            });
        });
    };
    ToastService.ctorParameters = function () { return [
        { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] }
    ]; };
    ToastService = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
        Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
            providedIn: 'root'
        }),
        tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]])
    ], ToastService);
    return ToastService;
}());



/***/ })

}]);
//# sourceMappingURL=dashboard-dashboard-module-es5.js.map