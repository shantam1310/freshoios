(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["signup-signup-module"],{

/***/ "./node_modules/raw-loader/index.js!./src/app/signup/signup.page.html":
/*!*******************************************************************!*\
  !*** ./node_modules/raw-loader!./src/app/signup/signup.page.html ***!
  \*******************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "<ion-content>\n    <div class=\"auth-background\">\n        <div class=\"flag-image\">\n            <img src=\"/assets/whoyou-logo.png\" alt=\"\" style=\"max-height: 92px\" />\n            <h2 style=\"font-size: 19px; color: white;\">whoyou</h2>\n        </div>\n        <div class=\"auth-form put-padding\" style=\"position: relative; z-index: 10; padding-bottom: 0px;\">\n            <div class=\"form-control-holder\">\n                <input type=\"text\" [(ngModel)]=\"form.display\" placeholder=\"your name\" autocomplete=\"off\" />\n            </div>\n            <div class=\"form-control-holder\">\n                <input type=\"text\" [(ngModel)]=\"form.username\" placeholder=\"email address\" autocomplete=\"off\" />\n            </div>\n            <div class=\"form-control-holder\">\n                <input type=\"password\" [(ngModel)]=\"form.password\" placeholder=\"password\" autocomplete=\"off\" />\n            </div>\n            <div class=\"form-control-holder\">\n                <input type=\"password\" [(ngModel)]=\"form.confirm\" placeholder=\"confirm password\" autocomplete=\"off\" />\n            </div>\n\n            <!-- Profile Photo Manager -->\n            <div (click)=\"TriggerFileInput();\" class=\"auth-form-profile\">\n                <div>profile picture (optional)</div>\n                <ion-avatar>\n                    <img [src]=\"avatar_url ? avatar_url : authentication.default_avatar\">\n                </ion-avatar>\n            </div>\n            <ion-item style=\"width:1px; height:1px; overflow:hidden; \n                             position:relative; left:-1000px;\">\n                <ion-label id=\"profile_image\" color=\"primary\" stacked>\n                    Add Image\n                </ion-label>\n                <input type=\"file\" accept=\"image/*\" name=\"file\" #file id=\"file\" (change)=\"ChangeListener($event)\" />\n            </ion-item>\n            <!-- End Profile Photo Manager -->\n\n            <div class=\"spacer\" style=\"height: 32px;\"></div>\n\n            <div expand=\"block\" class=\"home-button home-primary\" size=\"large\" class=\"whoyou-round-button button-white\" (click)=\"Submit();\">\n                <span>Create Account</span>\n            </div>\n\n            <p class=\"away-from-border generic-paragraph\" style=\"color: white !important;\">By clicking create account you agree to the <a href=\"https://bluezephyrapps-hosted-app-pages.s3.amazonaws.com/whoyou/eula.html\" target=\"_blank\">EULA terms and conditions</a>, our <a href=\"https://bluezephyrapps-hosted-app-pages.s3.amazonaws.com/whoyou/privacy_policy.html\"\n                    target=\"_blank\">Privacy Policy</a>, and our <a href=\"https://bluezephyrapps-hosted-app-pages.s3.amazonaws.com/whoyou/offensive_content.html\" target=\"_blank\">zero tolerance content policy</a>.</p>\n        </div>\n\n        <div class=\"fix-z center-contents put-padding\" style=\"padding-bottom: 0px;\">\n            <div expand=\"block\" size=\"large\" class=\"whoyou-round-button button-white-border\" [routerLink]=\"'/login'\" routerDirection=\"forward\">\n                <span>I Have an Existing Account</span>\n            </div>\n            <div class=\"art-line\"></div>\n        </div>\n    </div>\n</ion-content>"

/***/ }),

/***/ "./src/app/signup/signup.module.ts":
/*!*****************************************!*\
  !*** ./src/app/signup/signup.module.ts ***!
  \*****************************************/
/*! exports provided: SignupPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupPageModule", function() { return SignupPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/dist/fesm5.js");
/* harmony import */ var _signup_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./signup.page */ "./src/app/signup/signup.page.ts");







const routes = [
    {
        path: '',
        component: _signup_page__WEBPACK_IMPORTED_MODULE_6__["SignupPage"]
    }
];
let SignupPageModule = class SignupPageModule {
};
SignupPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_4__["RouterModule"].forChild(routes)
        ],
        declarations: [_signup_page__WEBPACK_IMPORTED_MODULE_6__["SignupPage"]]
    })
], SignupPageModule);



/***/ }),

/***/ "./src/app/signup/signup.page.scss":
/*!*****************************************!*\
  !*** ./src/app/signup/signup.page.scss ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3NpZ251cC9zaWdudXAucGFnZS5zY3NzIn0= */"

/***/ }),

/***/ "./src/app/signup/signup.page.ts":
/*!***************************************!*\
  !*** ./src/app/signup/signup.page.ts ***!
  \***************************************/
/*! exports provided: SignupPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SignupPage", function() { return SignupPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../services/authentication.service */ "./src/app/services/authentication.service.ts");
/* harmony import */ var _services_toast_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../services/toast.service */ "./src/app/services/toast.service.ts");
/* harmony import */ var _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../services/navigation.service */ "./src/app/services/navigation.service.ts");
/* harmony import */ var _services_query_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/query.service */ "./src/app/services/query.service.ts");
/* harmony import */ var _services_bucket_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../services/bucket.service */ "./src/app/services/bucket.service.ts");







let SignupPage = class SignupPage {
    constructor(authentication, toast, nav, query, bucket) {
        this.authentication = authentication;
        this.toast = toast;
        this.nav = nav;
        this.query = query;
        this.bucket = bucket;
        this.image_data = [];
        this.form = { settings: {} };
        this.avatar_url = undefined;
        this.acknowledged_age = true;
    }
    ngOnInit() {
    }
    TriggerFileInput() {
        this.file_input.nativeElement.click();
    }
    ChangeListener($event) {
        this.files = $event.target.files[0];
        this.UploadFiles();
    }
    UploadFiles() {
        this.bucket.UploadAndGetRemoteFileURL(this.files, 'profiles').then(image_url => {
            this.avatar_url = image_url;
        });
    }
    Submit() {
        if (!this.acknowledged_age) {
            this.toast.DisplaySimpleToast("Please confirm your age.");
            return;
        }
        if (this.form.password != this.form.confirm) {
            this.toast.DisplaySimpleToast("The entered passwords don't match.");
            return;
        }
        if (this.form.password.length < 8) {
            this.toast.DisplaySimpleToast("Your password must be at least 8 characters.");
            return;
        }
        this.authentication.CreateAndGetUser(this.form.username, this.form.password, this.form.display, this.form.ambassador).subscribe(user => {
            var user_data = user['data'];
            this.authentication.SetUser(user_data);
            if (this.avatar_url)
                this.SubmitProfilePhoto(this.avatar_url);
            else
                this.nav.NavigateRoot('dashboard', {});
        }, error => {
            var error_message = "Unable to sign up with given credentials.";
            console.log(error);
            if (error.error.data && error.error.data['message'])
                error_message = error.error.data['message'];
            this.toast.DisplaySimpleToast(error_message);
        });
    }
    SubmitProfilePhoto(image_url) {
        var body = {
            "media_url": image_url,
            "user": this.authentication.user.id,
            "is_featured": true
        };
        this.query.request('profile/photos', 'POST', {}, body).subscribe(results => {
            this.nav.NavigateRoot('dashboard', {});
        }, error => {
            this.toast.DisplaySimpleToast("Unable to upload photo.");
            this.nav.NavigateRoot('dashboard', {});
        });
    }
};
SignupPage.ctorParameters = () => [
    { type: _services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"] },
    { type: _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"] },
    { type: _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"] },
    { type: _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"] },
    { type: _services_bucket_service__WEBPACK_IMPORTED_MODULE_6__["BucketService"] }
];
tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["ViewChild"])("file", { static: false }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:type", _angular_core__WEBPACK_IMPORTED_MODULE_1__["ElementRef"])
], SignupPage.prototype, "file_input", void 0);
SignupPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-signup',
        template: __webpack_require__(/*! raw-loader!./signup.page.html */ "./node_modules/raw-loader/index.js!./src/app/signup/signup.page.html"),
        styles: [__webpack_require__(/*! ./signup.page.scss */ "./src/app/signup/signup.page.scss")]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_services_authentication_service__WEBPACK_IMPORTED_MODULE_2__["AuthenticationService"],
        _services_toast_service__WEBPACK_IMPORTED_MODULE_3__["ToastService"],
        _services_navigation_service__WEBPACK_IMPORTED_MODULE_4__["NavigationService"],
        _services_query_service__WEBPACK_IMPORTED_MODULE_5__["QueryService"],
        _services_bucket_service__WEBPACK_IMPORTED_MODULE_6__["BucketService"]])
], SignupPage);



/***/ })

}]);
//# sourceMappingURL=signup-signup-module-es2015.js.map